"use client";

import { useState, useEffect } from "react";
import { 
  BlockedApp, 
  FocusPet, 
  DailyMission, 
  Achievement, 
  SkillNode, 
  QuizResult, 
  PetType 
} from "@/types";
import { 
  INITIAL_PET, 
  BLOCKED_APPS_DEFAULT, 
  INITIAL_DAILY_MISSIONS, 
  INITIAL_ACHIEVEMENTS, 
  INITIAL_SKILL_NODES 
} from "./mockData";
import { sounds } from "./soundEffects";

export interface AppState {
  coins: number;
  xp: number;
  streak: number;
  emergencyPasses: number;
  pet: FocusPet;
  blockedApps: BlockedApp[];
  dailyMissions: DailyMission[];
  achievements: Achievement[];
  skillNodes: SkillNode[];
  completedLessons: string[];
  quizHistory: QuizResult[];
  soundEnabled: boolean;
  activeInterceptApp: BlockedApp | null; // When non-null, shows the intercept block modal!
  lastSavedAt: string;
}

const STORAGE_KEY = "learn2unlock_state_v1";

const DEFAULT_STATE: AppState = {
  coins: 480,
  xp: 3150,
  streak: 7,
  emergencyPasses: 3,
  pet: INITIAL_PET,
  blockedApps: BLOCKED_APPS_DEFAULT,
  dailyMissions: INITIAL_DAILY_MISSIONS,
  achievements: INITIAL_ACHIEVEMENTS,
  skillNodes: INITIAL_SKILL_NODES,
  completedLessons: ["ai-1", "ai-2", "prod-1", "prod-2", "prog-1"],
  quizHistory: [],
  soundEnabled: true,
  activeInterceptApp: null,
  lastSavedAt: new Date().toISOString(),
};

// Simple reactive store with window event dispatching for cross-component sync
let memoryState: AppState = DEFAULT_STATE;
const listeners = new Set<(state: AppState) => void>();

function notifyListeners() {
  if (typeof window !== "undefined") {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(memoryState));
  }
  listeners.forEach((listener) => listener({ ...memoryState }));
}

export function getAppState(): AppState {
  if (typeof window !== "undefined" && memoryState === DEFAULT_STATE) {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        memoryState = { ...DEFAULT_STATE, ...JSON.parse(saved) };
      }
    } catch {
      // fallback
    }
  }
  return memoryState;
}

export function useAppState() {
  const [state, setState] = useState<AppState>(getAppState);

  useEffect(() => {
    // Sync on mount
    setState(getAppState());

    const handleUpdate = (updatedState: AppState) => {
      setState(updatedState);
    };

    listeners.add(handleUpdate);
    return () => {
      listeners.delete(handleUpdate);
    };
  }, []);

  return state;
}

// Actions
export const appActions = {
  addCoins: (amount: number) => {
    memoryState = {
      ...memoryState,
      coins: memoryState.coins + amount,
    };
    sounds.playCoin();
    notifyListeners();
  },

  addXp: (amount: number) => {
    let newXp = memoryState.xp + amount;
    const pet = { ...memoryState.pet };
    pet.currentXp += amount;

    // Check pet level up
    if (pet.currentXp >= pet.nextLevelXp) {
      pet.level += 1;
      pet.currentXp -= pet.nextLevelXp;
      pet.nextLevelXp = Math.floor(pet.nextLevelXp * 1.35);
      pet.happiness = Math.min(100, pet.happiness + 20);
      pet.energy = Math.min(100, pet.energy + 20);

      // Check evolution stage
      if (pet.level >= 10 && pet.stage < 4) pet.stage = 4;
      else if (pet.level >= 7 && pet.stage < 3) pet.stage = 3;
      else if (pet.level >= 4 && pet.stage < 2) pet.stage = 2;

      sounds.playLevelUp();
    }

    memoryState = {
      ...memoryState,
      xp: newXp,
      pet,
    };
    notifyListeners();
  },

  unlockApp: (appId: string, durationMinutes: number, coinCost: number = 0) => {
    if (coinCost > 0 && memoryState.coins < coinCost) {
      sounds.playError();
      return false;
    }

    const now = Date.now();
    const unlockExpiration = now + durationMinutes * 60 * 1000;

    const updatedApps = memoryState.blockedApps.map((app) => {
      if (app.id === appId) {
        return {
          ...app,
          unlockedUntil: unlockExpiration,
        };
      }
      return app;
    });

    memoryState = {
      ...memoryState,
      coins: Math.max(0, memoryState.coins - coinCost),
      blockedApps: updatedApps,
      activeInterceptApp: null, // close intercept modal if open
    };

    sounds.playUnlock();
    notifyListeners();
    return true;
  },

  useEmergencyPass: (appId: string) => {
    if (memoryState.emergencyPasses <= 0) {
      sounds.playError();
      return false;
    }

    const now = Date.now();
    const unlockExpiration = now + 15 * 60 * 1000; // 15 minutes pass

    const updatedApps = memoryState.blockedApps.map((app) => {
      if (app.id === appId) {
        return {
          ...app,
          unlockedUntil: unlockExpiration,
        };
      }
      return app;
    });

    memoryState = {
      ...memoryState,
      emergencyPasses: memoryState.emergencyPasses - 1,
      blockedApps: updatedApps,
      activeInterceptApp: null,
    };

    sounds.playUnlock();
    notifyListeners();
    return true;
  },

  relockApp: (appId: string) => {
    const updatedApps = memoryState.blockedApps.map((app) => {
      if (app.id === appId) {
        return {
          ...app,
          unlockedUntil: null,
          totalBlocksCount: app.totalBlocksCount + 1,
        };
      }
      return app;
    });

    memoryState = {
      ...memoryState,
      blockedApps: updatedApps,
    };
    notifyListeners();
  },

  triggerInterceptModal: (app: BlockedApp) => {
    // If already unlocked, allow it
    if (app.unlockedUntil && app.unlockedUntil > Date.now()) {
      return false;
    }

    // Otherwise record block and open modal!
    const updatedApps = memoryState.blockedApps.map((a) => {
      if (a.id === app.id) {
        return { ...a, totalBlocksCount: a.totalBlocksCount + 1 };
      }
      return a;
    });

    memoryState = {
      ...memoryState,
      blockedApps: updatedApps,
      activeInterceptApp: app,
    };

    // If pet was sleeping or energized, excessive distraction attempts tire it
    if (memoryState.pet.energy > 30) {
      memoryState.pet.energy -= 4;
    }

    sounds.playError();
    notifyListeners();
    return true;
  },

  closeInterceptModal: () => {
    memoryState = {
      ...memoryState,
      activeInterceptApp: null,
    };
    notifyListeners();
  },

  completeLesson: (lessonId: string, xpReward: number, coinsReward: number) => {
    const newCompleted = Array.from(new Set([...memoryState.completedLessons, lessonId]));
    
    // Update daily missions
    const missions = memoryState.dailyMissions.map((m) => {
      if (m.id === "mission-1") {
        const nextCurrent = m.current + 1;
        return { ...m, current: nextCurrent, completed: nextCurrent >= m.target };
      }
      return m;
    });

    memoryState = {
      ...memoryState,
      completedLessons: newCompleted,
      dailyMissions: missions,
    };

    appActions.addCoins(coinsReward);
    appActions.addXp(xpReward);
  },

  recordQuizResult: (result: QuizResult) => {
    const history = [result, ...memoryState.quizHistory];
    
    // Update missions
    const missions = memoryState.dailyMissions.map((m) => {
      if (m.id === "mission-2" && result.scorePercentage >= 85) {
        return { ...m, current: 1, completed: true };
      }
      return m;
    });

    memoryState = {
      ...memoryState,
      quizHistory: history,
      dailyMissions: missions,
    };

    if (result.passed) {
      appActions.addCoins(result.coinsEarned);
      appActions.addXp(result.xpEarned);
    }

    notifyListeners();
  },

  feedPet: () => {
    const pet = { ...memoryState.pet };
    if (pet.energy >= 100 && pet.happiness >= 100) return;

    pet.energy = Math.min(100, pet.energy + 25);
    pet.happiness = Math.min(100, pet.happiness + 20);
    pet.mood = pet.energy > 80 ? "Ecstatic" : "Energized";
    pet.lastFedTimestamp = new Date().toISOString();

    memoryState = {
      ...memoryState,
      pet,
    };

    sounds.playCoin();
    notifyListeners();
  },

  changePetType: (type: PetType, name: string) => {
    const pet = {
      ...memoryState.pet,
      type,
      name,
    };
    memoryState = { ...memoryState, pet };
    notifyListeners();
  },

  claimMissionReward: (missionId: string) => {
    const mission = memoryState.dailyMissions.find((m) => m.id === missionId);
    if (!mission || !mission.completed || mission.claimed) return;

    const updatedMissions = memoryState.dailyMissions.map((m) => 
      m.id === missionId ? { ...m, claimed: true } : m
    );

    memoryState = {
      ...memoryState,
      dailyMissions: updatedMissions,
    };

    appActions.addCoins(mission.rewardCoins);
    appActions.addXp(mission.rewardXp);
  },

  toggleSound: () => {
    const newSoundState = !memoryState.soundEnabled;
    sounds.setEnabled(newSoundState);
    memoryState = {
      ...memoryState,
      soundEnabled: newSoundState,
    };
    notifyListeners();
  },

  toggleAppBlocked: (appId: string) => {
    const updated = memoryState.blockedApps.map((a) => 
      a.id === appId ? { ...a, isBlocked: !a.isBlocked } : a
    );
    memoryState = { ...memoryState, blockedApps: updated };
    sounds.playClick();
    notifyListeners();
  },

  addCustomApp: (name: string, category: "Social" | "Entertainment" | "Gaming" | "Shorts", color: string = "#6366F1") => {
    const id = name.toLowerCase().replace(/[^a-z0-9]/g, "-");
    const newApp: BlockedApp = {
      id,
      name,
      icon: "ShieldAlert",
      color,
      category,
      isBlocked: true,
      unlockedUntil: null,
      totalBlocksCount: 0,
      timeSavedMinutes: 0,
    };

    memoryState = {
      ...memoryState,
      blockedApps: [...memoryState.blockedApps, newApp],
    };
    sounds.playCorrect();
    notifyListeners();
  },

  resetDemoData: () => {
    memoryState = { ...DEFAULT_STATE, lastSavedAt: new Date().toISOString() };
    sounds.playLevelUp();
    notifyListeners();
  }
};
