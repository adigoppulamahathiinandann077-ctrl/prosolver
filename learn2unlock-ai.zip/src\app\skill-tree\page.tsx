"use client";

import { useAppState, appActions } from "@/lib/store";
import { sounds } from "@/lib/soundEffects";
import { 
  GitFork, 
  Brain, 
  Terminal, 
  Database, 
  Bot, 
  Zap, 
  Clock, 
  Sliders, 
  TrendingUp, 
  PieChart, 
  Lock, 
  CheckCircle2, 
  Star,
  Sparkles
} from "lucide-react";
import Link from "next/link";

export default function SkillTreePage() {
  const state = useAppState();

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case "Brain": return <Brain className="h-6 w-6" />;
      case "Terminal": return <Terminal className="h-6 w-6" />;
      case "Database": return <Database className="h-6 w-6" />;
      case "Bot": return <Bot className="h-6 w-6" />;
      case "Zap": return <Zap className="h-6 w-6" />;
      case "Clock": return <Clock className="h-6 w-6" />;
      case "Sliders": return <Sliders className="h-6 w-6" />;
      case "TrendingUp": return <TrendingUp className="h-6 w-6" />;
      default: return <PieChart className="h-6 w-6" />;
    }
  };

  const handleNodeClick = (node: typeof state.skillNodes[0]) => {
    if (node.status === "locked") {
      sounds.playError();
      alert(`This node is locked! Complete preceding prerequisite nodes to unlock "${node.title}".`);
    } else {
      sounds.playClick();
    }
  };

  // Group nodes by branch/track
  const aiNodes = state.skillNodes.filter((n) => n.trackId === "track-ai");
  const prodNodes = state.skillNodes.filter((n) => n.trackId === "track-prod");
  const finNodes = state.skillNodes.filter((n) => n.trackId === "track-fin");

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 text-indigo-400 text-xs font-bold uppercase tracking-wider mb-1">
          <GitFork className="h-4 w-4" />
          <span>Core Feature 6: Duolingo-Inspired Skill Tree</span>
        </div>
        <h1 className="text-3xl font-black text-white tracking-tight">Interactive Skill Tree</h1>
        <p className="text-sm text-slate-400 mt-1">
          Progress along branching roadmaps. Unlock foundational tiers to access autonomous AI, deep work, and financial wealth engineering.
        </p>
      </div>

      {/* 3 Skill Branches */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {/* Branch 1: AI & LLMs */}
        <div className="glass-card rounded-3xl p-6 border border-indigo-500/30 flex flex-col items-center">
          <div className="flex items-center gap-2 mb-6">
            <span className="flex h-8 w-8 items-center justify-center rounded-xl bg-indigo-500/20 text-indigo-400">
              <Brain className="h-4 w-4" />
            </span>
            <h2 className="text-base font-bold text-white">AI & Machine Learning</h2>
          </div>

          <div className="flex flex-col items-center space-y-6 w-full">
            {aiNodes.map((node, index) => {
              const isLocked = node.status === "locked";
              const isDone = node.status === "completed";

              return (
                <div key={node.id} className="flex flex-col items-center w-full">
                  <div
                    onClick={() => handleNodeClick(node)}
                    className={`relative flex h-20 w-20 cursor-pointer items-center justify-center rounded-3xl border-2 transition-all duration-300 hover:scale-110 ${
                      isDone
                        ? "border-emerald-400 bg-emerald-500/20 text-emerald-300 shadow-lg shadow-emerald-500/20"
                        : !isLocked
                        ? "border-indigo-400 bg-indigo-500/20 text-indigo-200 animate-pulse shadow-lg shadow-indigo-500/20"
                        : "border-slate-700 bg-slate-900/60 text-slate-600 cursor-not-allowed"
                    }`}
                  >
                    {isLocked ? <Lock className="h-6 w-6" /> : getIcon(node.icon)}

                    {/* Star badge */}
                    {isDone && (
                      <div className="absolute -bottom-2 flex items-center gap-0.5 rounded-full bg-slate-950 px-2 py-0.5 border border-emerald-500/50 text-[10px] text-amber-400">
                        <Star className="h-2.5 w-2.5 fill-amber-400" />
                        <span>3</span>
                      </div>
                    )}
                  </div>

                  <div className="text-center mt-2">
                    <div className="text-xs font-bold text-white">{node.title}</div>
                    <div className="text-[10px] text-slate-400 max-w-[180px]">{node.description}</div>
                  </div>

                  {index < aiNodes.length - 1 && (
                    <div className="h-8 w-0.5 bg-gradient-to-b from-indigo-500 to-indigo-800 my-1" />
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Branch 2: Deep Work & Dopamine Mastery */}
        <div className="glass-card rounded-3xl p-6 border border-emerald-500/30 flex flex-col items-center">
          <div className="flex items-center gap-2 mb-6">
            <span className="flex h-8 w-8 items-center justify-center rounded-xl bg-emerald-500/20 text-emerald-400">
              <Zap className="h-4 w-4" />
            </span>
            <h2 className="text-base font-bold text-white">Productivity & Dopamine</h2>
          </div>

          <div className="flex flex-col items-center space-y-6 w-full">
            {prodNodes.map((node, index) => {
              const isLocked = node.status === "locked";
              const isDone = node.status === "completed";

              return (
                <div key={node.id} className="flex flex-col items-center w-full">
                  <div
                    onClick={() => handleNodeClick(node)}
                    className={`relative flex h-20 w-20 cursor-pointer items-center justify-center rounded-3xl border-2 transition-all duration-300 hover:scale-110 ${
                      isDone
                        ? "border-emerald-400 bg-emerald-500/20 text-emerald-300 shadow-lg shadow-emerald-500/20"
                        : !isLocked
                        ? "border-emerald-400 bg-emerald-500/20 text-emerald-200 animate-pulse shadow-lg shadow-emerald-500/20"
                        : "border-slate-700 bg-slate-900/60 text-slate-600 cursor-not-allowed"
                    }`}
                  >
                    {isLocked ? <Lock className="h-6 w-6" /> : getIcon(node.icon)}

                    {isDone && (
                      <div className="absolute -bottom-2 flex items-center gap-0.5 rounded-full bg-slate-950 px-2 py-0.5 border border-emerald-500/50 text-[10px] text-amber-400">
                        <Star className="h-2.5 w-2.5 fill-amber-400" />
                        <span>{node.starsEarned || 2}</span>
                      </div>
                    )}
                  </div>

                  <div className="text-center mt-2">
                    <div className="text-xs font-bold text-white">{node.title}</div>
                    <div className="text-[10px] text-slate-400 max-w-[180px]">{node.description}</div>
                  </div>

                  {index < prodNodes.length - 1 && (
                    <div className="h-8 w-0.5 bg-gradient-to-b from-emerald-500 to-teal-800 my-1" />
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Branch 3: Financial Wealth Engineering */}
        <div className="glass-card rounded-3xl p-6 border border-amber-500/30 flex flex-col items-center">
          <div className="flex items-center gap-2 mb-6">
            <span className="flex h-8 w-8 items-center justify-center rounded-xl bg-amber-500/20 text-amber-400">
              <TrendingUp className="h-4 w-4" />
            </span>
            <h2 className="text-base font-bold text-white">Finance & Unit Economics</h2>
          </div>

          <div className="flex flex-col items-center space-y-6 w-full">
            {finNodes.map((node, index) => {
              const isLocked = node.status === "locked";
              const isDone = node.status === "completed";

              return (
                <div key={node.id} className="flex flex-col items-center w-full">
                  <div
                    onClick={() => handleNodeClick(node)}
                    className={`relative flex h-20 w-20 cursor-pointer items-center justify-center rounded-3xl border-2 transition-all duration-300 hover:scale-110 ${
                      isDone
                        ? "border-emerald-400 bg-emerald-500/20 text-emerald-300 shadow-lg shadow-emerald-500/20"
                        : !isLocked
                        ? "border-amber-400 bg-amber-500/20 text-amber-200 animate-pulse shadow-lg shadow-amber-500/20"
                        : "border-slate-700 bg-slate-900/60 text-slate-600 cursor-not-allowed"
                    }`}
                  >
                    {isLocked ? <Lock className="h-6 w-6" /> : getIcon(node.icon)}
                  </div>

                  <div className="text-center mt-2">
                    <div className="text-xs font-bold text-white">{node.title}</div>
                    <div className="text-[10px] text-slate-400 max-w-[180px]">{node.description}</div>
                  </div>

                  {index < finNodes.length - 1 && (
                    <div className="h-8 w-0.5 bg-gradient-to-b from-amber-500 to-orange-800 my-1" />
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
