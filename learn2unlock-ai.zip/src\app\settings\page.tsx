"use client";

import { useState } from "react";
import { useAppState, appActions } from "@/lib/store";
import { aiEngine } from "@/lib/aiEngine";
import { sounds } from "@/lib/soundEffects";
import { 
  Settings, 
  ShieldAlert, 
  AlertTriangle, 
  Volume2, 
  VolumeX, 
  Key, 
  RotateCcw, 
  Plus, 
  Check, 
  Trash2,
  Lock
} from "lucide-react";

export default function SettingsPage() {
  const state = useAppState();

  const [newAppName, setNewAppName] = useState("");
  const [newAppCat, setNewAppCat] = useState<"Social" | "Entertainment" | "Gaming" | "Shorts">("Social");
  const [apiKeyInput, setApiKeyInput] = useState(aiEngine.getApiKey() || "");
  const [keySaved, setKeySaved] = useState(false);

  const handleSaveApiKey = () => {
    aiEngine.setApiKey(apiKeyInput.trim());
    setKeySaved(true);
    sounds.playCorrect();
    setTimeout(() => setKeySaved(false), 2500);
  };

  const handleAddApp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAppName.trim()) return;
    appActions.addCustomApp(newAppName.trim(), newAppCat);
    setNewAppName("");
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-300 max-w-4xl">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 text-indigo-400 text-xs font-bold uppercase tracking-wider mb-1">
          <Settings className="h-4 w-4" />
          <span>Platform Preferences & Gateways</span>
        </div>
        <h1 className="text-3xl font-black text-white tracking-tight">App Blocker Rules & Settings</h1>
        <p className="text-sm text-slate-400 mt-1">
          Configure which applications are intercepted, adjust emergency access, and calibrate the AI assessment engine.
        </p>
      </div>

      {/* Section 1: Blocked Applications Management */}
      <div className="glass-card rounded-3xl p-6 border border-white/10 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-white/10">
          <div>
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <ShieldAlert className="h-5 w-5 text-red-400" />
              <span>Distraction App Shields</span>
            </h2>
            <p className="text-xs text-slate-400">
              Toggle which applications are intercepted by Learn2Unlock AI.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {state.blockedApps.map((app) => (
            <div
              key={app.id}
              className="flex items-center justify-between rounded-2xl border border-white/5 bg-white/5 p-4"
            >
              <div className="flex items-center gap-3">
                <div
                  className="flex h-10 w-10 items-center justify-center rounded-xl font-bold text-white shadow"
                  style={{ backgroundColor: app.color }}
                >
                  {app.name.charAt(0)}
                </div>
                <div>
                  <div className="font-bold text-white text-xs">{app.name}</div>
                  <div className="text-[11px] text-slate-400">
                    Category: {app.category} • {app.totalBlocksCount} Blocks
                  </div>
                </div>
              </div>

              {/* Toggle switch */}
              <button
                onClick={() => appActions.toggleAppBlocked(app.id)}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  app.isBlocked ? "bg-indigo-600" : "bg-slate-700"
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    app.isBlocked ? "translate-x-6" : "translate-x-1"
                  }`}
                />
              </button>
            </div>
          ))}
        </div>

        {/* Add custom app form */}
        <form onSubmit={handleAddApp} className="pt-4 border-t border-white/10 flex flex-col sm:flex-row gap-3">
          <input
            type="text"
            value={newAppName}
            onChange={(e) => setNewAppName(e.target.value)}
            placeholder="Add new app or domain (e.g. reddit.com)..."
            className="flex-1 rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-indigo-500"
          />
          <select
            value={newAppCat}
            onChange={(e) => setNewAppCat(e.target.value as any)}
            className="rounded-xl border border-white/10 bg-slate-900 px-3 py-2.5 text-xs text-white focus:outline-none"
          >
            <option value="Social">Social</option>
            <option value="Shorts">Shorts</option>
            <option value="Entertainment">Entertainment</option>
            <option value="Gaming">Gaming</option>
          </select>
          <button
            type="submit"
            className="flex items-center justify-center gap-1.5 rounded-xl bg-indigo-600 px-5 py-2.5 text-xs font-bold text-white hover:bg-indigo-500 transition-all"
          >
            <Plus className="h-4 w-4" />
            <span>Add Shield</span>
          </button>
        </form>
      </div>

      {/* Section 2: Emergency Unlock Allocation */}
      <div className="glass-card rounded-3xl p-6 border border-white/10 space-y-3">
        <h2 className="text-lg font-bold text-white flex items-center gap-2">
          <AlertTriangle className="h-5 w-5 text-rose-400" />
          <span>Core Feature 9: Emergency Unlock Passes</span>
        </h2>
        <p className="text-xs text-slate-300 leading-relaxed">
          To prevent extreme frustration, the platform allows 3 emergency passes per month. Using an emergency pass unlocks an app immediately for 15 minutes without learning, but exhausts your Focus Pet's energy.
        </p>

        <div className="rounded-2xl border border-rose-500/20 bg-rose-500/5 p-4 flex items-center justify-between">
          <div>
            <div className="text-xs font-bold text-white">Remaining Emergency Passes</div>
            <div className="text-[11px] text-slate-400">Resets automatically on the 1st of every month.</div>
          </div>
          <div className="text-2xl font-black text-rose-400">
            {state.emergencyPasses} / 3 Left
          </div>
        </div>
      </div>

      {/* Section 3: AI Engine & Sound Audio Preferences */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Sound FX */}
        <div className="glass-card rounded-3xl p-6 border border-white/10 space-y-4">
          <h3 className="font-bold text-white text-base flex items-center gap-2">
            <Volume2 className="h-5 w-5 text-emerald-400" />
            <span>Web Audio Synthesizer</span>
          </h3>
          <p className="text-xs text-slate-300">
            High-fidelity arcade sound effects for quizzes, coin pick-ups, boss strikes, and unlocks.
          </p>

          <button
            onClick={() => appActions.toggleSound()}
            className={`w-full flex items-center justify-center gap-2 rounded-xl py-3 text-xs font-bold transition-all ${
              state.soundEnabled
                ? "bg-emerald-600 text-white"
                : "bg-white/10 text-slate-400"
            }`}
          >
            {state.soundEnabled ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
            <span>{state.soundEnabled ? "Game Sound FX Enabled" : "Sound Effects Muted"}</span>
          </button>
        </div>

        {/* AI Key Config */}
        <div className="glass-card rounded-3xl p-6 border border-white/10 space-y-3">
          <h3 className="font-bold text-white text-base flex items-center gap-2">
            <Key className="h-5 w-5 text-amber-400" />
            <span>AI Model & API Key (Optional)</span>
          </h3>
          <p className="text-xs text-slate-300">
            Learn2Unlock AI includes a built-in neural simulation engine. You can also provide an OpenAI API key for live GPT-4o generation.
          </p>

          <div className="flex gap-2">
            <input
              type="password"
              value={apiKeyInput}
              onChange={(e) => setApiKeyInput(e.target.value)}
              placeholder="sk-proj-..."
              className="flex-1 rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
            />
            <button
              onClick={handleSaveApiKey}
              className="rounded-xl bg-indigo-600 px-4 py-2 text-xs font-bold text-white hover:bg-indigo-500 transition-all flex items-center gap-1"
            >
              {keySaved ? <Check className="h-4 w-4 text-emerald-300" /> : <span>Save</span>}
            </button>
          </div>
        </div>
      </div>

      {/* Section 4: Hackathon Data Reset */}
      <div className="glass-card rounded-3xl p-6 border border-white/10 flex items-center justify-between">
        <div>
          <h3 className="font-bold text-white text-sm">Reset Hackathon Demo Data</h3>
          <p className="text-xs text-slate-400">
            Resets all local state, streak, coins, and unlocks to clean factory demo settings.
          </p>
        </div>
        <button
          onClick={() => {
            const confirmed = confirm("Reset all data to default demo state?");
            if (confirmed) appActions.resetDemoData();
          }}
          className="flex items-center gap-2 rounded-xl border border-red-500/40 bg-red-500/10 px-4 py-2 text-xs font-bold text-red-300 hover:bg-red-500/20 transition-all"
        >
          <RotateCcw className="h-4 w-4" />
          <span>Reset Demo</span>
        </button>
      </div>
    </div>
  );
}
