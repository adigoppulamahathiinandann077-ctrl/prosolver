"use client";

import Link from "next/link";
import { QUIZ_QUESTIONS, INITIAL_TRACKS } from "@/lib/mockData";
import { useAppState } from "@/lib/store";
import { HelpCircle, Sparkles, CheckCircle2, ArrowRight, Clock, Zap, Coins } from "lucide-react";

export default function QuizIndexPage() {
  const state = useAppState();

  const quizKeys = Object.keys(QUIZ_QUESTIONS);

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      <div>
        <div className="flex items-center gap-2 text-indigo-400 text-xs font-bold uppercase tracking-wider mb-1">
          <HelpCircle className="h-4 w-4" />
          <span>Step 4: Adaptive AI Assessment Engine</span>
        </div>
        <h1 className="text-3xl font-black text-white tracking-tight">AI Quiz Center</h1>
        <p className="text-sm text-slate-400 mt-1">
          Pass any quiz with 70%+ accuracy to unlock screen time passes, earn Brain Coins, and level up your Focus Pet.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {quizKeys.map((lessonId) => {
          let lessonTitle = "Transformer Neural Networks";
          let category = "Artificial Intelligence";
          let diff = "Beginner";

          for (const track of INITIAL_TRACKS) {
            const found = track.lessons.find((l) => l.id === lessonId);
            if (found) {
              lessonTitle = found.title;
              category = found.category;
              diff = found.difficulty;
              break;
            }
          }

          const qList = QUIZ_QUESTIONS[lessonId];
          const hasPassed = state.quizHistory.some((q) => q.lessonId === lessonId && q.passed);

          return (
            <div key={lessonId} className="glass-card rounded-3xl p-6 border border-white/10 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="rounded-md bg-indigo-500/20 px-2 py-0.5 text-[10px] font-bold text-indigo-300">
                    {category}
                  </span>
                  <span className="text-[11px] text-slate-400 font-semibold">{qList.length} Questions</span>
                </div>

                <h3 className="font-bold text-white text-base mb-2">{lessonTitle}</h3>
                <p className="text-xs text-slate-400 leading-relaxed mb-4">
                  Adaptive formats: Multiple Choice, True/False, Match Pairs, and Fill Blanks.
                </p>
              </div>

              <div className="pt-4 border-t border-white/10 flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs text-amber-400 font-semibold">
                  <Coins className="h-3.5 w-3.5" />
                  <span>+60 to +120 Coins</span>
                </div>

                <Link
                  href={`/quiz/${lessonId}`}
                  className="flex items-center gap-1.5 rounded-xl bg-indigo-600 px-4 py-2 text-xs font-bold text-white hover:bg-indigo-500 transition-all hover:scale-105"
                >
                  <span>{hasPassed ? "Retake" : "Start Quiz"}</span>
                  <ArrowRight className="h-3.5 w-3.5" />
                </Link>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
