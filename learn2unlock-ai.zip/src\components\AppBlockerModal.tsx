"use client";

import { useAppState, appActions } from "@/lib/store";
import { 
  ShieldAlert, 
  Sparkles, 
  Zap, 
  Coins, 
  AlertTriangle, 
  X, 
  ArrowRight, 
  Clock, 
  Flame,
  Lock
} from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";

export function AppBlockerModal() {
  const state = useAppState();
  const router = useRouter();
  const app = state.activeInterceptApp;

  if (!app) return null;

  const handleStartLesson = () => {
    appActions.closeInterceptModal();
    // Route to first uncompleted or first available lesson
    router.push("/learn/track-ai/ai-3");
  };

  const handleUnlockWithCoins = () => {
    if (state.coins >= 50) {
      appActions.unlockApp(app.id, 30, 50);
      alert(`Success! ${app.name} is unlocked for 30 minutes. Timer is ticking!`);
    } else {
      alert("Not enough Brain Coins! Complete a 3-minute lesson & quiz to earn coins.");
    }
  };

  const handleEmergencyPass = () => {
    if (state.emergencyPasses <= 0) {
      alert("You have 0 emergency passes remaining this month!");
      return;
    }
    const confirmed = confirm(
      `Use 1 of your ${state.emergencyPasses} Emergency Passes? This unlocks ${app.name} for 15 minutes, but your Focus Pet will become slightly sad.`
    );
    if (confirmed) {
      appActions.useEmergencyPass(app.id);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg overflow-hidden rounded-3xl border border-red-500/30 bg-[#0F1422] p-6 shadow-2xl shadow-red-950/50 text-center">
        {/* Glow backdrop decoration */}
        <div className="absolute -top-24 left-1/2 h-48 w-48 -translate-x-1/2 rounded-full bg-red-600/20 blur-3xl" />
        <div className="absolute -bottom-24 right-0 h-48 w-48 rounded-full bg-indigo-600/20 blur-3xl" />

        {/* Close Button */}
        <button
          onClick={() => appActions.closeInterceptModal()}
          className="absolute top-4 right-4 rounded-full p-2 text-slate-400 hover:bg-white/10 hover:text-white transition-colors"
        >
          <X className="h-5 w-5" />
        </button>

        {/* Animated Cyber Shield Icon */}
        <div className="relative mx-auto mb-4 flex h-20 w-20 items-center justify-center">
          <div className="absolute inset-0 rounded-full bg-red-500/20 animate-ping opacity-75" />
          <div className="relative flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-red-600 to-rose-700 shadow-lg shadow-red-600/40 border border-red-400/30">
            <ShieldAlert className="h-9 w-9 text-white animate-pulse" />
          </div>
        </div>

        {/* Blocked App Pill */}
        <div className="inline-flex items-center gap-2 rounded-full bg-red-500/10 border border-red-500/30 px-3.5 py-1 text-xs font-semibold text-red-300 mb-2">
          <Lock className="h-3.5 w-3.5" />
          <span>Access Intercepted: {app.name}</span>
        </div>

        {/* Dynamic Punchy Message */}
        <h2 className="text-2xl md:text-3xl font-black tracking-tight text-white mb-2">
          Want to open {app.name}? <br />
          <span className="bg-gradient-to-r from-amber-400 via-rose-400 to-indigo-400 bg-clip-text text-transparent">
            Earn it first.
          </span>
        </h2>

        <p className="text-xs md:text-sm text-slate-300 max-w-md mx-auto mb-6 leading-relaxed">
          Mindless doom-scrolling has been paused. Transform your screen addiction into high-value knowledge. Complete a 3-minute micro-lesson to unlock your screen time!
        </p>

        {/* Stats Pill */}
        <div className="grid grid-cols-2 gap-3 mb-6 bg-white/5 rounded-2xl p-3 border border-white/5 text-left text-xs">
          <div>
            <span className="text-slate-400 block text-[11px]">Saved On {app.name}</span>
            <span className="font-bold text-emerald-400 text-sm">
              {Math.floor(app.timeSavedMinutes / 60)}h {app.timeSavedMinutes % 60}m
            </span>
          </div>
          <div>
            <span className="text-slate-400 block text-[11px]">Impulses Blocked</span>
            <span className="font-bold text-amber-400 text-sm">{app.totalBlocksCount} times</span>
          </div>
        </div>

        {/* Actions Grid */}
        <div className="space-y-2.5">
          {/* Primary Action: Earn with Lesson */}
          <button
            onClick={handleStartLesson}
            className="group flex w-full items-center justify-between rounded-2xl bg-gradient-to-r from-indigo-600 via-indigo-500 to-emerald-500 p-4 font-bold text-white shadow-lg shadow-indigo-600/30 hover:opacity-95 transition-all hover:scale-[1.01]"
          >
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/20">
                <Zap className="h-5 w-5 text-yellow-300" />
              </div>
              <div className="text-left">
                <div className="text-sm">Start 3-Minute Micro-Lesson</div>
                <div className="text-[11px] font-normal text-indigo-100">
                  Pass the 70% quiz to unlock {app.name} for 30m (+50 XP, +35 Coins)
                </div>
              </div>
            </div>
            <ArrowRight className="h-5 w-5 transition-transform group-hover:translate-x-1" />
          </button>

          {/* Secondary Action: Pay with Brain Coins */}
          <button
            onClick={handleUnlockWithCoins}
            className="flex w-full items-center justify-between rounded-xl border border-amber-500/30 bg-amber-500/10 p-3 text-xs font-semibold text-amber-200 hover:bg-amber-500/20 transition-colors"
          >
            <div className="flex items-center gap-2">
              <Coins className="h-4 w-4 text-amber-400" />
              <span>Spend 50 Brain Coins for 30m Instant Unlock</span>
            </div>
            <span className="font-mono font-bold text-amber-300">
              Bal: {state.coins} 🪙
            </span>
          </button>

          {/* Emergency Pass */}
          <div className="flex items-center justify-between pt-1 text-[11px] text-slate-400">
            <button
              onClick={handleEmergencyPass}
              className="flex items-center gap-1.5 text-rose-400 hover:text-rose-300 transition-colors hover:underline"
            >
              <AlertTriangle className="h-3.5 w-3.5" />
              <span>Use Emergency Pass ({state.emergencyPasses}/3 left this month)</span>
            </button>
            <button
              onClick={() => appActions.closeInterceptModal()}
              className="text-slate-400 hover:text-white transition-colors"
            >
              Back to Deep Work
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
