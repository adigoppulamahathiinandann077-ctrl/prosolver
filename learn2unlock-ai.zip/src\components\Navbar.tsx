"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useAppState, appActions } from "@/lib/store";
import { 
  Flame, 
  Coins, 
  Volume2, 
  VolumeX, 
  Sparkles, 
  ShieldAlert, 
  Clock, 
  LockOpen,
  Menu,
  X
} from "lucide-react";
import { useState, useEffect } from "react";

export function Navbar({ onToggleSidebar }: { onToggleSidebar?: () => void }) {
  const state = useAppState();
  const pathname = usePathname();
  const [now, setNow] = useState(Date.now());

  // Update timer every second for live unlocked countdowns
  useEffect(() => {
    const timer = setInterval(() => {
      setNow(Date.now());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Find any active unlocked apps
  const activeUnlockedApps = state.blockedApps.filter(
    (app) => app.unlockedUntil && app.unlockedUntil > now
  );

  const petEmoji = 
    state.pet.type === "owl" ? "🦉" :
    state.pet.type === "fox" ? "🦊" : "🤖";

  return (
    <header className="sticky top-0 z-40 w-full border-b border-white/10 bg-[#090D16]/85 backdrop-blur-xl">
      <div className="flex h-16 items-center justify-between px-4 md:px-6">
        {/* Left: Brand & Mobile Menu */}
        <div className="flex items-center gap-3">
          {onToggleSidebar && (
            <button
              onClick={onToggleSidebar}
              className="rounded-lg p-2 text-slate-400 hover:bg-white/5 hover:text-white lg:hidden"
            >
              <Menu className="h-5 w-5" />
            </button>
          )}

          <Link href="/" className="flex items-center gap-2.5 group">
            <div className="relative flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-tr from-indigo-600 via-indigo-500 to-emerald-400 p-0.5 shadow-lg shadow-indigo-500/25 transition-transform group-hover:scale-105">
              <div className="flex h-full w-full items-center justify-center rounded-[10px] bg-[#090D16]">
                <Sparkles className="h-5 w-5 text-indigo-400" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-black tracking-tight text-white text-base md:text-lg">
                  Learn<span className="text-emerald-400">2</span>Unlock
                </span>
                <span className="rounded bg-indigo-500/20 px-1.5 py-0.5 text-[10px] font-bold text-indigo-300 border border-indigo-500/30">
                  AI
                </span>
              </div>
              <p className="hidden text-[10px] text-slate-400 font-medium sm:block">
                Earn your screen time through learning
              </p>
            </div>
          </Link>
        </div>

        {/* Center: Live Unlocked Badges (if any) */}
        <div className="hidden md:flex items-center gap-2">
          {activeUnlockedApps.length > 0 ? (
            activeUnlockedApps.map((app) => {
              const remainingMs = Math.max(0, (app.unlockedUntil || 0) - now);
              const remainingMin = Math.floor(remainingMs / 60000);
              const remainingSec = Math.floor((remainingMs % 60000) / 1000);
              return (
                <div
                  key={app.id}
                  className="flex items-center gap-2 rounded-full border border-emerald-500/40 bg-emerald-950/40 px-3 py-1 text-xs text-emerald-300 shadow-sm animate-pulse"
                >
                  <LockOpen className="h-3.5 w-3.5 text-emerald-400" />
                  <span className="font-semibold">{app.name} Unlocked:</span>
                  <span className="font-mono font-bold text-white">
                    {remainingMin}:{remainingSec.toString().padStart(2, "0")}
                  </span>
                </div>
              );
            })
          ) : (
            <div className="flex items-center gap-1.5 text-xs text-slate-400 bg-white/5 px-3 py-1 rounded-full border border-white/5">
              <ShieldAlert className="h-3.5 w-3.5 text-amber-400" />
              <span>Shield Active: Distractions Intercepted</span>
            </div>
          )}
        </div>

        {/* Right: Gamification Badges & Pet Widget */}
        <div className="flex items-center gap-2 md:gap-3">
          {/* Quick Intercept Simulator Button */}
          <button
            onClick={() => {
              const instagram = state.blockedApps.find((a) => a.id === "instagram") || state.blockedApps[0];
              appActions.triggerInterceptModal(instagram);
            }}
            className="hidden sm:flex items-center gap-1.5 rounded-lg border border-red-500/40 bg-red-500/10 px-3 py-1.5 text-xs font-semibold text-red-300 hover:bg-red-500/20 transition-colors shadow-sm"
            title="Simulate opening a distracting app to test the interception block screen"
          >
            <ShieldAlert className="h-3.5 w-3.5 text-red-400" />
            <span>Simulate App Block</span>
          </button>

          {/* Brain Coins */}
          <div 
            onClick={() => appActions.addCoins(10)}
            className="flex items-center gap-1.5 rounded-xl border border-amber-500/30 bg-amber-500/10 px-3 py-1.5 text-xs font-bold text-amber-300 shadow-sm cursor-pointer hover:bg-amber-500/20 transition-all active:scale-95"
            title="Brain Coins: Click to collect test coins!"
          >
            <Coins className="h-3.5 w-3.5 text-amber-400" />
            <span>{state.coins}</span>
          </div>

          {/* Learning Streak */}
          <div 
            className="flex items-center gap-1.5 rounded-xl border border-orange-500/30 bg-orange-500/10 px-3 py-1.5 text-xs font-bold text-orange-300 shadow-sm"
            title="Daily Learning Streak"
          >
            <Flame className="h-3.5 w-3.5 text-orange-400 fill-orange-400 animate-pulse" />
            <span>{state.streak}d</span>
          </div>

          {/* Focus Pet Compact Widget */}
          <Link
            href="/pet"
            className="flex items-center gap-2 rounded-xl border border-indigo-500/30 bg-indigo-500/10 px-2.5 py-1 text-xs text-slate-200 hover:border-indigo-500/60 transition-all hover:scale-105"
            title={`Focus Pet: ${state.pet.name} (Lvl ${state.pet.level})`}
          >
            <span className="text-base">{petEmoji}</span>
            <div className="hidden sm:block text-left">
              <div className="flex items-center gap-1 font-semibold text-[11px] text-white">
                <span>Lv.{state.pet.level}</span>
                <span className="text-[10px] text-indigo-300">{state.pet.mood}</span>
              </div>
              <div className="h-1.5 w-12 rounded-full bg-slate-800 overflow-hidden">
                <div 
                  className="h-full bg-indigo-400 transition-all"
                  style={{ width: `${(state.pet.currentXp / state.pet.nextLevelXp) * 100}%` }}
                />
              </div>
            </div>
          </Link>

          {/* Sound toggle */}
          <button
            onClick={() => appActions.toggleSound()}
            className="flex h-8 w-8 items-center justify-center rounded-lg border border-white/10 text-slate-300 hover:bg-white/5 hover:text-white transition-colors"
            title={state.soundEnabled ? "Mute Game Sound Effects" : "Enable Game Sound Effects"}
          >
            {state.soundEnabled ? (
              <Volume2 className="h-4 w-4 text-emerald-400" />
            ) : (
              <VolumeX className="h-4 w-4 text-slate-500" />
            )}
          </button>
        </div>
      </div>
    </header>
  );
}
