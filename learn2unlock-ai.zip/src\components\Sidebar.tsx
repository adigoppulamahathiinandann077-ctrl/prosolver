"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { 
  LayoutDashboard, 
  BookOpen, 
  HelpCircle, 
  Gamepad2, 
  GitFork, 
  Sparkles, 
  Gift, 
  Trophy, 
  BarChart3, 
  Award, 
  Settings, 
  ShieldCheck, 
  X,
  Compass
} from "lucide-react";

interface SidebarProps {
  isOpen?: boolean;
  onClose?: () => void;
}

const navItems = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/learn", label: "Learning Portal", icon: BookOpen, badge: "10 Tracks" },
  { href: "/quiz", label: "AI Adaptive Quiz", icon: HelpCircle },
  { href: "/games", label: "Gamified Arcade", icon: Gamepad2, badge: "4 Games" },
  { href: "/pet", label: "Focus Pet Evolution", icon: Sparkles },
  { href: "/skill-tree", label: "Skill Tree Roadmap", icon: GitFork },
  { href: "/rewards", label: "App Unlock Shop", icon: Gift },
  { href: "/leaderboard", label: "Leaderboards", icon: Trophy },
  { href: "/analytics", label: "Productivity Insights", icon: BarChart3 },
  { href: "/achievements", label: "Achievements", icon: Award },
  { href: "/settings", label: "App Blocker Rules", icon: Settings },
  { href: "/admin", label: "Admin Telemetry", icon: ShieldCheck },
];

export function Sidebar({ isOpen, onClose }: SidebarProps) {
  const pathname = usePathname();

  return (
    <>
      {/* Mobile backdrop */}
      {isOpen && (
        <div 
          onClick={onClose}
          className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm lg:hidden"
        />
      )}

      <aside
        className={`fixed top-16 bottom-0 left-0 z-40 w-64 border-r border-white/10 bg-[#0B0F1B]/95 p-4 backdrop-blur-xl transition-transform duration-300 ease-in-out lg:translate-x-0 ${
          isOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="flex h-full flex-col justify-between">
          <div className="space-y-1">
            <div className="flex items-center justify-between px-3 py-2 text-xs font-semibold uppercase tracking-wider text-slate-400">
              <span>Main Navigation</span>
              {onClose && (
                <button
                  onClick={onClose}
                  className="rounded-lg p-1 text-slate-400 hover:bg-white/5 hover:text-white lg:hidden"
                >
                  <X className="h-4 w-4" />
                </button>
              )}
            </div>

            <nav className="space-y-1">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = pathname === item.href || (item.href !== "/" && pathname.startsWith(item.href));

                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    onClick={onClose}
                    className={`group flex items-center justify-between rounded-xl px-3 py-2.5 text-xs font-medium transition-all ${
                      isActive
                        ? "bg-indigo-600/20 text-indigo-300 border border-indigo-500/30 shadow-sm"
                        : "text-slate-300 hover:bg-white/5 hover:text-white"
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <Icon
                        className={`h-4 w-4 transition-transform group-hover:scale-110 ${
                          isActive ? "text-indigo-400" : "text-slate-400"
                        }`}
                      />
                      <span>{item.label}</span>
                    </div>

                    {item.badge && (
                      <span className="rounded-full bg-indigo-500/20 px-2 py-0.5 text-[10px] font-semibold text-indigo-300">
                        {item.badge}
                      </span>
                    )}
                  </Link>
                );
              })}
            </nav>
          </div>

          {/* Quick Info Box in Sidebar */}
          <div className="rounded-2xl border border-white/5 bg-gradient-to-br from-indigo-950/40 to-slate-900/60 p-3 text-xs text-slate-300">
            <div className="flex items-center gap-2 font-bold text-white mb-1">
              <Compass className="h-4 w-4 text-emerald-400" />
              <span>Session Goal</span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Complete 1 micro-lesson (3 min) + pass the 70% quiz to unlock Instagram for 30 minutes.
            </p>
            <div className="mt-2.5 flex items-center justify-between text-[10px] text-indigo-300 font-semibold">
              <span>Goal: 1 / 2 Lessons</span>
              <span className="text-emerald-400">50%</span>
            </div>
            <div className="mt-1 h-1.5 w-full rounded-full bg-slate-800 overflow-hidden">
              <div className="h-full bg-gradient-to-r from-indigo-500 to-emerald-400 w-1/2" />
            </div>
          </div>
        </div>
      </aside>
    </>
  );
}
