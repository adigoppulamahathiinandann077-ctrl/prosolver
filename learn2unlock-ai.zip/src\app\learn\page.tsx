"use client";

import { useState } from "react";
import Link from "next/link";
import { INITIAL_TRACKS } from "@/lib/mockData";
import { useAppState } from "@/lib/store";
import { 
  BookOpen, 
  Search, 
  Clock, 
  Zap, 
  Coins, 
  CheckCircle2, 
  Sparkles, 
  ChevronRight,
  Filter,
  GraduationCap
} from "lucide-react";
import { Category } from "@/types";

const ALL_CATEGORIES: Category[] = [
  "Artificial Intelligence",
  "Technology",
  "Programming",
  "Productivity",
  "Finance",
  "Business",
  "Language Learning",
  "Science",
  "Engineering",
  "Career Development"
];

export default function LearnPortalPage() {
  const state = useAppState();
  const [selectedCategory, setSelectedCategory] = useState<string>("All");
  const [searchQuery, setSearchQuery] = useState("");

  const filteredTracks = INITIAL_TRACKS.filter((track) => {
    const matchesCategory = selectedCategory === "All" || track.category === selectedCategory;
    const matchesSearch = track.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      track.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      track.lessons.some((l) => l.title.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-indigo-400 text-xs font-bold uppercase tracking-wider mb-1">
            <GraduationCap className="h-4 w-4" />
            <span>2 to 5 Minute Micro-Curriculum</span>
          </div>
          <h1 className="text-3xl font-black text-white tracking-tight">
            Learning Portal & Tracks
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Select a learning track. Complete any lesson to earn Brain Coins and unlock your apps.
          </p>
        </div>

        {/* Search Input */}
        <div className="relative w-full md:w-72">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search topics or concepts..."
            className="w-full rounded-xl border border-white/10 bg-white/5 py-2 pl-10 pr-4 text-xs text-white placeholder-slate-400 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
          />
        </div>
      </div>

      {/* Category Pills Slider */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
        <button
          onClick={() => setSelectedCategory("All")}
          className={`rounded-xl px-4 py-2 text-xs font-bold whitespace-nowrap transition-all ${
            selectedCategory === "All"
              ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/30"
              : "border border-white/10 bg-white/5 text-slate-300 hover:bg-white/10"
          }`}
        >
          All Tracks
        </button>
        {ALL_CATEGORIES.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`rounded-xl px-4 py-2 text-xs font-semibold whitespace-nowrap transition-all ${
              selectedCategory === cat
                ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/30"
                : "border border-white/10 bg-white/5 text-slate-300 hover:bg-white/10"
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Tracks Grid */}
      <div className="space-y-8">
        {filteredTracks.map((track) => {
          const completedCount = track.lessons.filter((l) => 
            state.completedLessons.includes(l.id)
          ).length;
          const progressPercent = Math.round((completedCount / track.lessons.length) * 100);

          return (
            <div key={track.id} className="glass-card rounded-3xl p-6 border border-white/10">
              {/* Track Title Bar */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-white/10">
                <div className="flex items-center gap-3">
                  <div className={`flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-tr ${track.gradient} text-white shadow-md`}>
                    <BookOpen className="h-6 w-6" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-indigo-400 uppercase tracking-wider">
                        {track.category}
                      </span>
                      <span className="text-slate-500">•</span>
                      <span className="text-xs text-slate-400">{track.lessons.length} Micro-Lessons</span>
                    </div>
                    <h2 className="text-xl font-bold text-white">{track.title}</h2>
                  </div>
                </div>

                {/* Progress bar */}
                <div className="w-full sm:w-48 text-right">
                  <div className="flex justify-between text-xs text-slate-400 mb-1">
                    <span>Progress</span>
                    <span className="font-bold text-white">{completedCount} / {track.lessons.length} ({progressPercent}%)</span>
                  </div>
                  <div className="h-2 w-full rounded-full bg-slate-800 overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-indigo-500 to-emerald-400 transition-all duration-500"
                      style={{ width: `${progressPercent}%` }}
                    />
                  </div>
                </div>
              </div>

              {/* Lessons inside track */}
              <div className="mt-5 grid grid-cols-1 md:grid-cols-2 gap-4">
                {track.lessons.map((lesson) => {
                  const isDone = state.completedLessons.includes(lesson.id);

                  return (
                    <Link
                      key={lesson.id}
                      href={`/learn/${track.id}/${lesson.id}`}
                      className="group relative flex flex-col justify-between rounded-2xl border border-white/5 bg-white/5 p-4 transition-all hover:border-indigo-500/40 hover:bg-white/10 hover:scale-[1.01]"
                    >
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className={`rounded-md px-2 py-0.5 text-[10px] font-bold ${
                            lesson.difficulty === "Beginner" ? "bg-emerald-500/20 text-emerald-300" :
                            lesson.difficulty === "Intermediate" ? "bg-indigo-500/20 text-indigo-300" :
                            "bg-amber-500/20 text-amber-300"
                          }`}>
                            {lesson.difficulty}
                          </span>

                          <div className="flex items-center gap-1 text-[11px] text-slate-400 font-medium">
                            <Clock className="h-3 w-3 text-slate-400" />
                            <span>{lesson.durationMinutes} min</span>
                          </div>
                        </div>

                        <h3 className="font-bold text-white text-sm group-hover:text-indigo-300 transition-colors mb-1.5">
                          {lesson.title}
                        </h3>

                        <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">
                          {lesson.description}
                        </p>
                      </div>

                      {/* Lesson Footer */}
                      <div className="mt-4 pt-3 border-t border-white/5 flex items-center justify-between text-xs">
                        <div className="flex items-center gap-3 font-semibold text-[11px]">
                          <span className="text-amber-400 flex items-center gap-1">
                            <Coins className="h-3 w-3" />
                            +{lesson.coinsReward}
                          </span>
                          <span className="text-indigo-400 flex items-center gap-1">
                            <Zap className="h-3 w-3" />
                            +{lesson.xpReward} XP
                          </span>
                        </div>

                        {isDone ? (
                          <div className="flex items-center gap-1 font-bold text-emerald-400 text-xs">
                            <CheckCircle2 className="h-4 w-4" />
                            <span>Completed</span>
                          </div>
                        ) : (
                          <div className="flex items-center gap-1 font-bold text-slate-400 group-hover:text-white transition-colors text-xs">
                            <span>Start Lesson</span>
                            <ChevronRight className="h-3.5 w-3.5" />
                          </div>
                        )}
                      </div>
                    </Link>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
