"use client";

import { useState } from "react";
import { INITIAL_LEADERBOARD } from "@/lib/mockData";
import { useAppState } from "@/lib/store";
import { 
  Trophy, 
  Crown, 
  Flame, 
  Coins, 
  Zap, 
  BookOpen, 
  Users, 
  Globe, 
  Calendar 
} from "lucide-react";

export default function LeaderboardsPage() {
  const state = useAppState();
  const [filter, setFilter] = useState<"global" | "friends" | "weekly" | "monthly">("weekly");

  const top3 = INITIAL_LEADERBOARD.slice(0, 3);
  const remaining = INITIAL_LEADERBOARD.slice(3);

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-yellow-400 text-xs font-bold uppercase tracking-wider mb-1">
            <Trophy className="h-4 w-4" />
            <span>Core Feature 7: Global Competition</span>
          </div>
          <h1 className="text-3xl font-black text-white tracking-tight">Leaderboards</h1>
          <p className="text-sm text-slate-400 mt-1">
            Compete with scholars worldwide. Top ranks earn double Brain Coins and exclusive Pet halos!
          </p>
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-1 rounded-2xl border border-white/10 bg-white/5 p-1">
          <button
            onClick={() => setFilter("weekly")}
            className={`rounded-xl px-4 py-2 text-xs font-bold transition-all ${
              filter === "weekly" ? "bg-indigo-600 text-white shadow" : "text-slate-400 hover:text-white"
            }`}
          >
            Weekly Cup
          </button>
          <button
            onClick={() => setFilter("monthly")}
            className={`rounded-xl px-4 py-2 text-xs font-bold transition-all ${
              filter === "monthly" ? "bg-indigo-600 text-white shadow" : "text-slate-400 hover:text-white"
            }`}
          >
            Monthly Masters
          </button>
          <button
            onClick={() => setFilter("friends")}
            className={`rounded-xl px-4 py-2 text-xs font-bold transition-all ${
              filter === "friends" ? "bg-indigo-600 text-white shadow" : "text-slate-400 hover:text-white"
            }`}
          >
            Friends
          </button>
          <button
            onClick={() => setFilter("global")}
            className={`rounded-xl px-4 py-2 text-xs font-bold transition-all ${
              filter === "global" ? "bg-indigo-600 text-white shadow" : "text-slate-400 hover:text-white"
            }`}
          >
            All-Time Global
          </button>
        </div>
      </div>

      {/* Top 3 Podium Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-6">
        {/* Rank 2 (Silver) */}
        <div className="glass-card rounded-3xl p-6 border border-slate-400/30 flex flex-col items-center text-center order-2 md:order-1 relative mt-4">
          <div className="absolute -top-4 rounded-full bg-slate-300 px-3 py-0.5 text-xs font-black text-black shadow-md">
            #2 SILVER
          </div>
          <img
            src={top3[1].avatar}
            alt={top3[1].name}
            className="h-20 w-20 rounded-full border-2 border-slate-300 object-cover shadow-lg mb-3 mt-2"
          />
          <h3 className="font-bold text-white text-base">{top3[1].name}</h3>
          <div className="text-xs text-slate-400 mt-1">Stage {top3[1].petStage} Fox Companion</div>
          <div className="mt-4 flex items-center gap-3 text-xs font-bold">
            <span className="text-indigo-400 flex items-center gap-1">
              <Zap className="h-3.5 w-3.5" />
              {top3[1].xp} XP
            </span>
            <span className="text-orange-400 flex items-center gap-1">
              <Flame className="h-3.5 w-3.5 fill-orange-400" />
              {top3[1].streak}d
            </span>
          </div>
        </div>

        {/* Rank 1 (Gold) */}
        <div className="glass-card rounded-3xl p-8 border border-yellow-500/50 flex flex-col items-center text-center order-1 md:order-2 relative bg-gradient-to-b from-yellow-950/20 via-slate-900 to-[#0B0F1B] shadow-2xl shadow-yellow-950/40">
          <Crown className="h-8 w-8 text-yellow-400 mb-1 animate-bounce" />
          <div className="rounded-full bg-gradient-to-r from-yellow-400 to-amber-500 px-4 py-1 text-xs font-black text-black shadow-lg mb-2">
            #1 CHAMPION
          </div>
          <img
            src={top3[0].avatar}
            alt={top3[0].name}
            className="h-24 w-24 rounded-full border-4 border-yellow-400 object-cover shadow-xl mb-3"
          />
          <h3 className="text-lg font-black text-white">{top3[0].name}</h3>
          <div className="text-xs text-amber-300 font-semibold">Stage {top3[0].petStage} Ascended Owl</div>
          <div className="mt-4 flex items-center gap-4 text-xs font-bold">
            <span className="text-indigo-300 flex items-center gap-1">
              <Zap className="h-4 w-4" />
              {top3[0].xp} XP
            </span>
            <span className="text-amber-400 flex items-center gap-1">
              <Coins className="h-4 w-4" />
              {top3[0].coins}
            </span>
            <span className="text-orange-400 flex items-center gap-1">
              <Flame className="h-4 w-4 fill-orange-400" />
              {top3[0].streak}d
            </span>
          </div>
        </div>

        {/* Rank 3 (Bronze) */}
        <div className="glass-card rounded-3xl p-6 border border-amber-700/30 flex flex-col items-center text-center order-3 md:order-3 relative mt-6">
          <div className="absolute -top-4 rounded-full bg-amber-700 px-3 py-0.5 text-xs font-black text-white shadow-md">
            #3 BRONZE
          </div>
          <img
            src={top3[2].avatar}
            alt={top3[2].name}
            className="h-20 w-20 rounded-full border-2 border-amber-600 object-cover shadow-lg mb-3 mt-2"
          />
          <h3 className="font-bold text-white text-base">{top3[2].name}</h3>
          <div className="text-xs text-slate-400 mt-1">Stage {top3[2].petStage} Robot Companion</div>
          <div className="mt-4 flex items-center gap-3 text-xs font-bold">
            <span className="text-indigo-400 flex items-center gap-1">
              <Zap className="h-3.5 w-3.5" />
              {top3[2].xp} XP
            </span>
            <span className="text-orange-400 flex items-center gap-1">
              <Flame className="h-3.5 w-3.5 fill-orange-400" />
              {top3[2].streak}d
            </span>
          </div>
        </div>
      </div>

      {/* Leaderboard Table */}
      <div className="glass-card rounded-3xl p-6 border border-white/10 overflow-hidden">
        <h3 className="text-base font-bold text-white mb-4">Rankings Table</h3>
        <div className="space-y-2">
          {remaining.map((user) => {
            const isUser = user.isCurrentUser;

            return (
              <div
                key={user.id}
                className={`flex items-center justify-between rounded-2xl p-4 transition-all ${
                  isUser
                    ? "border border-emerald-500/50 bg-emerald-950/30 text-white font-bold shadow-md"
                    : "border border-white/5 bg-white/5 text-slate-300 hover:bg-white/10"
                }`}
              >
                <div className="flex items-center gap-4">
                  <span className="w-6 text-center font-black text-sm text-slate-400">
                    #{user.rank}
                  </span>
                  <img
                    src={user.avatar}
                    alt={user.name}
                    className="h-10 w-10 rounded-full object-cover border border-white/10"
                  />
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold text-white">{user.name}</span>
                      {isUser && (
                        <span className="rounded bg-emerald-500/20 px-1.5 py-0.5 text-[10px] font-bold text-emerald-300">
                          YOU
                        </span>
                      )}
                    </div>
                    <div className="text-[11px] text-slate-400">
                      {user.lessonsCompleted} Lessons Completed
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-4 md:gap-6 text-xs font-mono font-semibold">
                  <span className="text-orange-400 hidden sm:flex items-center gap-1">
                    <Flame className="h-3.5 w-3.5 fill-orange-400" />
                    {user.streak}d
                  </span>
                  <span className="text-amber-400 hidden md:flex items-center gap-1">
                    <Coins className="h-3.5 w-3.5" />
                    {user.coins}
                  </span>
                  <span className="text-indigo-300 flex items-center gap-1 font-bold">
                    <Zap className="h-3.5 w-3.5" />
                    {user.xp} XP
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
