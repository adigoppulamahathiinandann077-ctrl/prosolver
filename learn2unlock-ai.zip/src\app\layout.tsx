import type { Metadata } from "next";
import "./globals.css";
import { AppBlockerModal } from "@/components/AppBlockerModal";
import { FloatingAppSimulator } from "@/components/FloatingAppSimulator";
import { LayoutShell } from "@/components/LayoutShell";

export const metadata: Metadata = {
  title: "Learn2Unlock AI — Earn your screen time through learning",
  description: "A productivity and digital wellbeing platform that replaces screen addiction with AI-powered micro-learning, gamification, and learning-based app unlocking.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark">
      <body className="bg-[#090D16] text-slate-100 antialiased selection:bg-indigo-500 selection:text-white">
        <LayoutShell>{children}</LayoutShell>
        <AppBlockerModal />
        <FloatingAppSimulator />
      </body>
    </html>
  );
}
