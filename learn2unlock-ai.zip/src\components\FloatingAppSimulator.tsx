"use client";

import { useState } from "react";
import { useAppState, appActions } from "@/lib/store";
import { 
  ShieldAlert, 
  ChevronUp, 
  ChevronDown, 
  Instagram, 
  Video, 
  Youtube, 
  Film, 
  Gamepad2, 
  LockOpen, 
  Lock 
} from "lucide-react";

export function FloatingAppSimulator() {
  const [collapsed, setCollapsed] = useState(false);
  const state = useAppState();

  const getIcon = (id: string) => {
    switch (id) {
      case "instagram": return <Instagram className="h-4 w-4" />;
      case "tiktok": return <Video className="h-4 w-4" />;
      case "youtube-shorts": return <Youtube className="h-4 w-4" />;
      case "netflix": return <Film className="h-4 w-4" />;
      default: return <Gamepad2 className="h-4 w-4" />;
    }
  };

  const handleAppClick = (app: typeof state.blockedApps[0]) => {
    const isUnlocked = app.unlockedUntil && app.unlockedUntil > Date.now();
    if (isUnlocked) {
      const remainingSec = Math.round((app.unlockedUntil! - Date.now()) / 1000);
      alert(`🎉 ${app.name} is currently UNLOCKED! You have ${Math.floor(remainingSec / 60)}m ${remainingSec % 60}s of earned screen time remaining.`);
    } else {
      appActions.triggerInterceptModal(app);
    }
  };

  return (
    <div className="fixed bottom-4 right-4 z-40 max-w-md">
      <div className="overflow-hidden rounded-2xl border border-indigo-500/30 bg-[#0B0F1B]/95 p-3 shadow-2xl backdrop-blur-xl transition-all">
        {/* Header / Toggle */}
        <div 
          onClick={() => setCollapsed(!collapsed)}
          className="flex cursor-pointer items-center justify-between gap-3 text-xs font-bold text-slate-200 select-none"
        >
          <div className="flex items-center gap-2">
            <span className="relative flex h-2.5 w-2.5">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
              <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-emerald-500" />
            </span>
            <span className="text-white">Distraction Interceptor Simulator</span>
          </div>

          <div className="flex items-center gap-1 text-[11px] text-slate-400">
            <span>{collapsed ? "Expand" : "Minimize"}</span>
            {collapsed ? <ChevronUp className="h-3.5 w-3.5" /> : <ChevronDown className="h-3.5 w-3.5" />}
          </div>
        </div>

        {/* Apps grid */}
        {!collapsed && (
          <div className="mt-2.5">
            <p className="text-[11px] text-slate-400 mb-2 leading-tight">
              Click an app to simulate opening it on your device:
            </p>
            <div className="flex flex-wrap gap-1.5">
              {state.blockedApps.map((app) => {
                const isUnlocked = app.unlockedUntil && app.unlockedUntil > Date.now();
                return (
                  <button
                    key={app.id}
                    onClick={() => handleAppClick(app)}
                    className={`flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-semibold transition-all ${
                      isUnlocked
                        ? "border border-emerald-500/50 bg-emerald-950/40 text-emerald-300 hover:bg-emerald-900/50"
                        : "border border-white/10 bg-white/5 text-slate-200 hover:border-red-500/40 hover:bg-red-500/10 hover:text-red-300"
                    }`}
                  >
                    {getIcon(app.id)}
                    <span>{app.name}</span>
                    {isUnlocked ? (
                      <LockOpen className="h-3 w-3 text-emerald-400" />
                    ) : (
                      <Lock className="h-3 w-3 text-red-400" />
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
