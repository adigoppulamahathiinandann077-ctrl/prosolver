"use client";

import { useAppState } from "@/lib/store";
import { aiEngine } from "@/lib/aiEngine";
import { PRODUCTIVITY_WEEK_STATS } from "@/lib/mockData";
import { 
  BarChart3, 
  Clock, 
  ShieldAlert, 
  Award, 
  Sparkles, 
  CheckCircle2, 
  Coins, 
  Flame, 
  Zap,
  TrendingUp,
  Brain,
  Lightbulb
} from "lucide-react";

export default function AnalyticsDashboardPage() {
  const state = useAppState();

  const totalBlocked = state.blockedApps.reduce((acc, a) => acc + a.totalBlocksCount, 0);
  const totalSavedMinutes = state.blockedApps.reduce((acc, a) => acc + a.timeSavedMinutes, 0);
  const totalHours = (totalSavedMinutes / 60).toFixed(1);

  const report = aiEngine.generateAnalyticsReport(PRODUCTIVITY_WEEK_STATS, totalBlocked);

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 text-indigo-400 text-xs font-bold uppercase tracking-wider mb-1">
          <BarChart3 className="h-4 w-4" />
          <span>Core Features 8 & 10: Smart Analytics & Habit Telemetry</span>
        </div>
        <h1 className="text-3xl font-black text-white tracking-tight">Productivity Dashboard</h1>
        <p className="text-sm text-slate-400 mt-1">
          Real-time metrics on screen time saved, impulses blocked, neural growth, and AI behavioral diagnostics.
        </p>
      </div>

      {/* Top 4 KPI Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="glass-card rounded-3xl p-5 border border-white/10">
          <div className="flex items-center gap-2 text-indigo-400 text-xs font-bold mb-2">
            <Clock className="h-4 w-4" />
            <span>Screen Time Saved</span>
          </div>
          <div className="text-2xl md:text-3xl font-black text-white">{totalHours} hrs</div>
          <p className="text-[11px] text-emerald-400 mt-1">↑ +2.4h vs last week</p>
        </div>

        <div className="glass-card rounded-3xl p-5 border border-white/10">
          <div className="flex items-center gap-2 text-red-400 text-xs font-bold mb-2">
            <ShieldAlert className="h-4 w-4" />
            <span>Impulses Intercepted</span>
          </div>
          <div className="text-2xl md:text-3xl font-black text-white">{totalBlocked} blocks</div>
          <p className="text-[11px] text-slate-400 mt-1">Social media paused</p>
        </div>

        <div className="glass-card rounded-3xl p-5 border border-white/10">
          <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold mb-2">
            <Award className="h-4 w-4" />
            <span>Quiz Success Rate</span>
          </div>
          <div className="text-2xl md:text-3xl font-black text-white">88.5%</div>
          <p className="text-[11px] text-emerald-400 mt-1">Above 70% threshold</p>
        </div>

        <div className="glass-card rounded-3xl p-5 border border-white/10">
          <div className="flex items-center gap-2 text-amber-400 text-xs font-bold mb-2">
            <Brain className="h-4 w-4" />
            <span>Focus Score</span>
          </div>
          <div className="text-2xl md:text-3xl font-black text-white">92 / 100</div>
          <p className="text-[11px] text-amber-400 mt-1">Optimal Deep Work Tier</p>
        </div>
      </div>

      {/* Visual Chart: Daily Hours Saved Bar Chart */}
      <div className="glass-card rounded-3xl p-6 border border-white/10">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="font-bold text-white text-base">Weekly Screen Time Saved (Hours)</h3>
            <p className="text-xs text-slate-400">Hours reclaimed from Instagram, TikTok, and YouTube Shorts.</p>
          </div>
          <span className="text-xs font-bold text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-3 py-1 rounded-full">
            Total: 14.5 Hours Saved
          </span>
        </div>

        <div className="flex items-end justify-between gap-2 md:gap-6 h-48 pt-6 px-4">
          {PRODUCTIVITY_WEEK_STATS.map((d) => {
            const heightPct = Math.round((d.hoursSaved / 3.5) * 100);

            return (
              <div key={d.day} className="flex-1 flex flex-col items-center gap-2 h-full justify-end group">
                <div className="text-[10px] font-mono font-bold text-indigo-300 opacity-0 group-hover:opacity-100 transition-opacity">
                  {d.hoursSaved}h
                </div>
                <div 
                  className="w-full max-w-[48px] rounded-t-xl bg-gradient-to-t from-indigo-600 via-indigo-500 to-emerald-400 transition-all duration-500 group-hover:brightness-125"
                  style={{ height: `${heightPct}%` }}
                />
                <span className="text-xs font-bold text-slate-400 group-hover:text-white transition-colors">
                  {d.day}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* AI Smart Analytics & Diagnostic Report */}
      <div className="glass-card rounded-3xl p-6 md:p-8 border border-indigo-500/30 bg-gradient-to-br from-indigo-950/30 via-slate-900 to-[#0B0F1B] space-y-6">
        <div className="flex items-center gap-2">
          <span className="flex h-8 w-8 items-center justify-center rounded-xl bg-indigo-500/20 text-indigo-400">
            <Sparkles className="h-5 w-5" />
          </span>
          <div>
            <h3 className="font-black text-white text-lg">AI Behavior Diagnostic & Weekly Briefing</h3>
            <p className="text-xs text-indigo-300">Generated dynamically by Learn2Unlock AI Analysis Engine</p>
          </div>
        </div>

        <p className="text-xs md:text-sm text-slate-200 leading-relaxed bg-white/5 p-4 rounded-2xl border border-white/5">
          {report.aiDiagnostic}
        </p>

        {/* Diagnostic Metadata Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="rounded-2xl border border-white/5 bg-white/5 p-4 text-xs">
            <span className="text-slate-400 block text-[11px] mb-1">Peak Cognitive Stamina</span>
            <span className="font-bold text-white text-sm">{report.peakFocusHour}</span>
          </div>

          <div className="rounded-2xl border border-white/5 bg-white/5 p-4 text-xs">
            <span className="text-slate-400 block text-[11px] mb-1">Top Subject Domain</span>
            <span className="font-bold text-emerald-400 text-sm">{report.topSubject}</span>
          </div>

          <div className="rounded-2xl border border-white/5 bg-white/5 p-4 text-xs">
            <span className="text-slate-400 block text-[11px] mb-1">Recommended Growth Area</span>
            <span className="font-bold text-amber-400 text-sm">{report.weakestSubject}</span>
          </div>
        </div>

        {/* Recommended Action Items */}
        <div className="space-y-2 pt-2">
          <div className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
            <Lightbulb className="h-4 w-4 text-yellow-400" />
            <span>AI Prescribed Actions For Tomorrow:</span>
          </div>
          <div className="space-y-2">
            {report.recommendedNextActions.map((action, i) => (
              <div key={i} className="flex items-start gap-2.5 text-xs text-slate-300 bg-black/30 p-3 rounded-xl border border-white/5">
                <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-indigo-500/20 text-indigo-300 font-bold text-[10px]">
                  {i + 1}
                </span>
                <p className="leading-relaxed">{action}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
