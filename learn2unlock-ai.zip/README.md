# Learn2Unlock AI 🚀
> *"Earn your screen time through learning."*

Learn2Unlock AI is a production-grade digital wellbeing and productivity platform that halts mindless screen addiction and transforms impulsive scrolling loops into world-class learning habits.

---

## 🌟 The Core Behavioral Loop

```
┌─────────────────────────┐
│ 1. Intercept Distraction│  Attempt to open Instagram / TikTok / Shorts / Netflix
└────────────┬────────────┘
             │
             ▼
┌─────────────────────────┐
│ 2. 3-Min AI Micro-Lesson│  Engage with interactive video, AI syntheses, and key takeaways
└────────────┬────────────┘
             │
             ▼
┌─────────────────────────┐
│ 3. Adaptive AI Quiz     │  Pass 70%+ threshold (MCQ, True/False, Match Pairs, Fill Blanks)
└────────────┬────────────┘
             │
             ▼
┌─────────────────────────┐
│ 4. Gamified Mini-Game   │  Knowledge Runner, Flash Battle Blitz, Memory Flip, AI Boss Battle
└────────────┬────────────┘
             │
             ▼
┌─────────────────────────┐
│ 5. Earned Screen Time   │  30m or 60m live countdown timer. Automatically relocks upon expiry!
└─────────────────────────┘
```

---

## ✨ Features & Hackathon WOW Factors

1. **Active Distraction App Interceptor**:
   - Blocks Instagram, TikTok, YouTube Shorts, Netflix, Facebook, Gaming, and custom domains.
   - Animated Cyber Shield: *"Want to open Instagram? Earn it first."*
   - Includes 3 monthly **Emergency Passes** with consequence tracking to prevent rage-quits.
   - Built-in floating simulation dock to test interception at any time.

2. **AI Personalization Engine**:
   - Dynamic Daily Recommendations based on historical mastery and domain weaknesses.
   - Adaptive difficulty rating (Novice → Intermediate → Advanced).
   - Generative lesson summaries and key takeaway extractions.

3. **4 Fully Playable Mini-Games**:
   - **Knowledge Runner**: Jump hurdles by picking correct answers in 3 seconds.
   - **Flash Battle Blitz**: 30-second rapid-fire combo multiplier blitz.
   - **Memory Concept Flip**: Flip-card matching of concepts to formulas and definitions.
   - **AI Boss Battle**: Turn-based combat against the "Dopamine Glitch Lord" with custom focus spells.

4. **Focus Pet Companion System**:
   - Choose between **Archie the Cyber Owl**, **Byte the Quantum Fox**, or **Aegis the Iron Bot**.
   - 4 Evolution Stages (Hatchling → Cyber Apprentice → Focus Guardian → Ascended Sage).
   - Dynamic mood & stamina: excessive distraction attempts tire your pet; lessons grant XP and evolution perks.

5. **Brain Coins & Dual-Currency Economy**:
   - Earn Brain Coins and Pet XP for completing lessons, passing quizzes, and winning arcade games.
   - Spend coins to unlock 30-minute / 60-minute passes or buy Streak Freeze Shields.

6. **Interactive Duolingo-Style Skill Tree**:
   - Branching roadmaps across AI & LLMs, Deep Work & Dopamine Rewiring, and Compound Wealth.

7. **Productivity & Telemetry Dashboard**:
   - Live visual charts: Screen Time Saved, Impulses Blocked, Focus Score, Weekly Hours Chart.
   - AI-Generated Behavioral Diagnostic Briefing with prescribed action items.

8. **Zero-Latency Web Audio Synthesizer**:
   - In-browser synthesized sound effects for coin pickups, laser jumps, boss hits, and level-up fanfares without external audio dependencies.

---

## 🛠️ Tech Stack

- **Framework**: Next.js 14+ (App Router)
- **Language**: TypeScript
- **Styling**: Tailwind CSS, Glassmorphism, Futuristic Cyber Theme
- **State & Persistence**: Reactive Store with automatic `localStorage` synchronization
- **Audio Engine**: Web Audio API Sound Synthesizer
- **Icons**: Lucide React

---

## 🚀 Getting Started

### 1. Set Workspace
Open this directory in your terminal or IDE:
```bash
cd C:\Users\adigo\.gemini\antigravity\scratch\learn2unlock-ai
```

### 2. Run the Development Server
```bash
npm run dev
```
Open [http://localhost:3000](http://localhost:3000) with your browser.

### 3. Production Build
```bash
npm run build
npm start
```
All 18 routes are pre-rendered and statically optimized for blazing-fast 60fps performance!
