"use client";

import Link from "next/link";
import { 
  Sparkles, 
  ShieldAlert, 
  Zap, 
  Gamepad2, 
  Flame, 
  ArrowRight, 
  CheckCircle2, 
  BarChart3, 
  Clock, 
  LockOpen, 
  Trophy, 
  Bot, 
  Play,
  Instagram,
  Video,
  Youtube
} from "lucide-react";
import { useAppState, appActions } from "@/lib/store";

export default function LandingPage() {
  const state = useAppState();

  const handleSimulateBlock = () => {
    const instagram = state.blockedApps.find((a) => a.id === "instagram") || state.blockedApps[0];
    appActions.triggerInterceptModal(instagram);
  };

  return (
    <div className="relative overflow-hidden bg-[#090D16]">
      {/* Background Decorative Gradient Orbs */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[450px] bg-gradient-to-b from-indigo-600/20 via-emerald-600/10 to-transparent blur-3xl pointer-events-none" />
      <div className="absolute top-1/3 -left-48 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-2/3 -right-48 w-96 h-96 bg-emerald-600/10 rounded-full blur-3xl pointer-events-none" />

      {/* Hero Section */}
      <section className="relative px-4 pt-16 pb-20 md:px-8 md:pt-24 md:pb-28 max-w-6xl mx-auto text-center">
        {/* Top Tagline Badge */}
        <div className="inline-flex items-center gap-2 rounded-full border border-indigo-500/30 bg-indigo-500/10 px-4 py-1.5 text-xs font-semibold text-indigo-300 mb-6 backdrop-blur-md">
          <Sparkles className="h-4 w-4 text-emerald-400" />
          <span>Transform Screen Addiction Into A World-Class Learning Habit</span>
        </div>

        {/* Main Headline */}
        <h1 className="text-4xl md:text-6xl lg:text-7xl font-black tracking-tight text-white max-w-4xl mx-auto leading-[1.1] mb-6">
          Earn your screen time <br />
          <span className="bg-gradient-to-r from-indigo-400 via-emerald-400 to-amber-300 bg-clip-text text-transparent">
            through learning.
          </span>
        </h1>

        {/* Subhead */}
        <p className="text-base md:text-xl text-slate-300 max-w-2xl mx-auto mb-10 leading-relaxed">
          Learn2Unlock AI intercepts distracting apps like Instagram, TikTok, and YouTube Shorts.
          Complete a quick 3-minute interactive lesson and quiz to unlock your screen time.
        </p>

        {/* CTAs */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16">
          <Link
            href="/dashboard"
            className="flex w-full sm:w-auto items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-indigo-600 to-emerald-500 px-8 py-4 font-bold text-white shadow-xl shadow-indigo-600/25 hover:opacity-95 transition-all hover:scale-105"
          >
            <span>Launch Learning Dashboard</span>
            <ArrowRight className="h-5 w-5" />
          </Link>

          <button
            onClick={handleSimulateBlock}
            className="flex w-full sm:w-auto items-center justify-center gap-2.5 rounded-2xl border border-red-500/30 bg-red-500/10 px-8 py-4 font-bold text-red-300 hover:bg-red-500/20 transition-all hover:scale-105"
          >
            <ShieldAlert className="h-5 w-5 text-red-400" />
            <span>Simulate App Interception</span>
          </button>
        </div>

        {/* Live Interactive Flow Preview Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-left">
          <div className="glass-card rounded-2xl p-5 border border-white/10 hover:border-red-500/40 transition-all">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-red-500/20 text-red-400 mb-3">
              <ShieldAlert className="h-5 w-5" />
            </div>
            <div className="text-xs font-bold text-red-400 uppercase tracking-wider mb-1">Step 1</div>
            <h3 className="font-bold text-white text-base mb-1">App Intercepted</h3>
            <p className="text-xs text-slate-400">
              User attempts opening Instagram. System instantly blocks access with animated shield.
            </p>
          </div>

          <div className="glass-card rounded-2xl p-5 border border-white/10 hover:border-indigo-500/40 transition-all">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-indigo-500/20 text-indigo-400 mb-3">
              <Play className="h-5 w-5" />
            </div>
            <div className="text-xs font-bold text-indigo-400 uppercase tracking-wider mb-1">Step 2 & 3</div>
            <h3 className="font-bold text-white text-base mb-1">3-Min AI Lesson</h3>
            <p className="text-xs text-slate-400">
              Interactive educational player with video, AI-generated notes, and key takeaways.
            </p>
          </div>

          <div className="glass-card rounded-2xl p-5 border border-white/10 hover:border-amber-500/40 transition-all">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-500/20 text-amber-400 mb-3">
              <Zap className="h-5 w-5" />
            </div>
            <div className="text-xs font-bold text-amber-400 uppercase tracking-wider mb-1">Step 4 & 5</div>
            <h3 className="font-bold text-white text-base mb-1">Adaptive Quiz & Games</h3>
            <p className="text-xs text-slate-400">
              Pass the 70% adaptive quiz and play 4 mini-games (Knowledge Runner, AI Boss Battle).
            </p>
          </div>

          <div className="glass-card rounded-2xl p-5 border border-white/10 hover:border-emerald-500/40 transition-all">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-500/20 text-emerald-400 mb-3">
              <LockOpen className="h-5 w-5" />
            </div>
            <div className="text-xs font-bold text-emerald-400 uppercase tracking-wider mb-1">Step 6 & 7</div>
            <h3 className="font-bold text-white text-base mb-1">Earned Access</h3>
            <p className="text-xs text-slate-400">
              Instagram unlocks for 30 or 60 minutes with a live countdown timer. Automatically relocks!
            </p>
          </div>
        </div>
      </section>

      {/* Feature Highlights Grid */}
      <section className="px-4 py-16 md:px-8 max-w-6xl mx-auto border-t border-white/10">
        <div className="text-center mb-12">
          <h2 className="text-2xl md:text-4xl font-extrabold text-white mb-3">
            Engineered For True Behavioral Transformation
          </h2>
          <p className="text-sm md:text-base text-slate-400 max-w-xl mx-auto">
            Combining behavioral psychology, Duolingo-style gamification, and modern AI.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Card 1: Focus Pet */}
          <div className="glass-card rounded-3xl p-6 border border-white/10 hover:border-indigo-500/40 transition-all">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-indigo-500/20 text-indigo-400 mb-4 text-2xl">
              🦉
            </div>
            <h3 className="text-lg font-bold text-white mb-2">Focus Pet System</h3>
            <p className="text-xs text-slate-300 leading-relaxed mb-4">
              Your virtual companion (Owl, Fox, or Robot) grows stronger as you learn. Excessive doom-scrolling exhausts your pet; daily streaks trigger multi-stage evolutions!
            </p>
            <div className="flex items-center gap-2 text-xs font-semibold text-indigo-400">
              <span>Explore Evolution Stages</span>
              <ArrowRight className="h-4 w-4" />
            </div>
          </div>

          {/* Card 2: 4 Gamified Mini-Games */}
          <div className="glass-card rounded-3xl p-6 border border-white/10 hover:border-emerald-500/40 transition-all">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-emerald-500/20 text-emerald-400 mb-4">
              <Gamepad2 className="h-6 w-6" />
            </div>
            <h3 className="text-lg font-bold text-white mb-2">4 Gamified Mini-Games</h3>
            <p className="text-xs text-slate-300 leading-relaxed mb-4">
              Reinforce knowledge through playable challenges: Knowledge Runner, Flash Battle Blitz, Memory Flip Challenge, and the epic AI Boss Battle!
            </p>
            <div className="flex items-center gap-2 text-xs font-semibold text-emerald-400">
              <span>Play Arcade Games</span>
              <ArrowRight className="h-4 w-4" />
            </div>
          </div>

          {/* Card 3: Adaptive AI Quiz */}
          <div className="glass-card rounded-3xl p-6 border border-white/10 hover:border-amber-500/40 transition-all">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-amber-500/20 text-amber-400 mb-4">
              <Zap className="h-6 w-6" />
            </div>
            <h3 className="text-lg font-bold text-white mb-2">Adaptive AI Quiz Engine</h3>
            <p className="text-xs text-slate-300 leading-relaxed mb-4">
              4 question formats: Multiple Choice, True/False, Match Pairs, and Fill Blanks. Difficulty automatically recalibrates based on your historical mastery.
            </p>
            <div className="flex items-center gap-2 text-xs font-semibold text-amber-400">
              <span>Test Knowledge Engine</span>
              <ArrowRight className="h-4 w-4" />
            </div>
          </div>
        </div>
      </section>

      {/* Social Proof / Stats Strip */}
      <section className="px-4 py-12 md:px-8 max-w-6xl mx-auto border-t border-white/10">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
          <div>
            <div className="text-3xl md:text-4xl font-black text-white mb-1">14.5 hrs</div>
            <div className="text-xs text-slate-400 font-medium">Average Time Saved / Week</div>
          </div>
          <div>
            <div className="text-3xl md:text-4xl font-black text-emerald-400 mb-1">94%</div>
            <div className="text-xs text-slate-400 font-medium">Habit Replacement Rate</div>
          </div>
          <div>
            <div className="text-3xl md:text-4xl font-black text-indigo-400 mb-1">10 Tracks</div>
            <div className="text-xs text-slate-400 font-medium">AI, Coding, Finance, Science</div>
          </div>
          <div>
            <div className="text-3xl md:text-4xl font-black text-amber-400 mb-1">3 Mins</div>
            <div className="text-xs text-slate-400 font-medium">Micro-Lesson Duration</div>
          </div>
        </div>
      </section>
    </div>
  );
}
