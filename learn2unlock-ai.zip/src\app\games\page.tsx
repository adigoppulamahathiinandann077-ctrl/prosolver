"use client";

import { useState, useEffect, useRef } from "react";
import { useAppState, appActions } from "@/lib/store";
import { sounds } from "@/lib/soundEffects";
import { 
  Gamepad2, 
  Zap, 
  Sword, 
  Layers, 
  Trophy, 
  Heart, 
  RotateCcw, 
  Coins, 
  Sparkles, 
  ShieldAlert, 
  Flame, 
  Play, 
  CheckCircle2, 
  XCircle,
  Clock,
  ArrowRight
} from "lucide-react";

type GameType = "runner" | "flash" | "memory" | "boss";

export default function GamesArcadePage() {
  const [activeGame, setActiveGame] = useState<GameType>("runner");

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold uppercase tracking-wider mb-1">
          <Gamepad2 className="h-4 w-4" />
          <span>Step 5: Gamified Knowledge Arcade</span>
        </div>
        <h1 className="text-3xl font-black text-white tracking-tight">Mini-Games Arcade</h1>
        <p className="text-sm text-slate-400 mt-1">
          Play these 4 gamified challenges to reinforce lesson concepts, earn bonus Brain Coins, and upgrade your Focus Pet.
        </p>
      </div>

      {/* Game Selector Tabs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <button
          onClick={() => { sounds.playClick(); setActiveGame("runner"); }}
          className={`flex items-center gap-3 rounded-2xl p-4 border transition-all text-left ${
            activeGame === "runner"
              ? "border-emerald-500 bg-emerald-950/40 text-emerald-300 shadow-lg shadow-emerald-950/50"
              : "border-white/10 bg-white/5 text-slate-400 hover:bg-white/10 hover:text-white"
          }`}
        >
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-emerald-500/20 text-emerald-400">
            🏃
          </div>
          <div>
            <div className="text-xs font-bold text-white">1. Knowledge Runner</div>
            <div className="text-[10px] text-slate-400">Jump hurdles with answers</div>
          </div>
        </button>

        <button
          onClick={() => { sounds.playClick(); setActiveGame("flash"); }}
          className={`flex items-center gap-3 rounded-2xl p-4 border transition-all text-left ${
            activeGame === "flash"
              ? "border-amber-500 bg-amber-950/40 text-amber-300 shadow-lg shadow-amber-950/50"
              : "border-white/10 bg-white/5 text-slate-400 hover:bg-white/10 hover:text-white"
          }`}
        >
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-amber-500/20 text-amber-400">
            ⚡
          </div>
          <div>
            <div className="text-xs font-bold text-white">2. Flash Battle</div>
            <div className="text-[10px] text-slate-400">Rapid combo blitz</div>
          </div>
        </button>

        <button
          onClick={() => { sounds.playClick(); setActiveGame("memory"); }}
          className={`flex items-center gap-3 rounded-2xl p-4 border transition-all text-left ${
            activeGame === "memory"
              ? "border-indigo-500 bg-indigo-950/40 text-indigo-300 shadow-lg shadow-indigo-950/50"
              : "border-white/10 bg-white/5 text-slate-400 hover:bg-white/10 hover:text-white"
          }`}
        >
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-indigo-500/20 text-indigo-400">
            🎴
          </div>
          <div>
            <div className="text-xs font-bold text-white">3. Memory Flip</div>
            <div className="text-[10px] text-slate-400">Match concept cards</div>
          </div>
        </button>

        <button
          onClick={() => { sounds.playClick(); setActiveGame("boss"); }}
          className={`flex items-center gap-3 rounded-2xl p-4 border transition-all text-left ${
            activeGame === "boss"
              ? "border-rose-500 bg-rose-950/40 text-rose-300 shadow-lg shadow-rose-950/50"
              : "border-white/10 bg-white/5 text-slate-400 hover:bg-white/10 hover:text-white"
          }`}
        >
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-rose-500/20 text-rose-400">
            👾
          </div>
          <div>
            <div className="text-xs font-bold text-white">4. AI Boss Battle</div>
            <div className="text-[10px] text-slate-400">Defeat Glitch Lord</div>
          </div>
        </button>
      </div>

      {/* Render Active Game Container */}
      <div className="glass-card rounded-3xl p-6 md:p-8 border border-white/10">
        {activeGame === "runner" && <KnowledgeRunnerGame />}
        {activeGame === "flash" && <FlashBattleGame />}
        {activeGame === "memory" && <MemoryChallengeGame />}
        {activeGame === "boss" && <AIBossBattleGame />}
      </div>
    </div>
  );
}

// -------------------------------------------------------------
// GAME 1: KNOWLEDGE RUNNER
// -------------------------------------------------------------
function KnowledgeRunnerGame() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [score, setScore] = useState(0);
  const [health, setHealth] = useState(100);
  const [hurdlePromptIndex, setHurdlePromptIndex] = useState(0);
  const [isJumping, setIsJumping] = useState(false);
  const [gameOver, setGameOver] = useState(false);

  const prompts = [
    {
      q: "Transformers replace sequential processing with:",
      options: ["Self-Attention Matrix", "Linear For-Loops", "Random Token Dropout"],
      correct: 0,
    },
    {
      q: "Which schedule makes TikTok and Reels compulsive?",
      options: ["Variable Ratio Schedule", "Fixed Hourly Wage", "Deterministic Step"],
      correct: 0,
    },
    {
      q: "What does RAG stand for in modern AI architecture?",
      options: ["Retrieval-Augmented Generation", "Random Attention Gate", "Recursive Array Grid"],
      correct: 0,
    },
    {
      q: "In the Rule of 72, 72 divided by 8% equals:",
      options: ["9 Years to Double", "18 Years to Double", "4 Years to Double"],
      correct: 0,
    },
  ];

  const currentPrompt = prompts[hurdlePromptIndex % prompts.length];

  const startGame = () => {
    setIsPlaying(true);
    setScore(0);
    setHealth(100);
    setHurdlePromptIndex(0);
    setGameOver(false);
    sounds.playLevelUp();
  };

  const handleAnswer = (index: number) => {
    if (gameOver) return;

    if (index === currentPrompt.correct) {
      // Jump hurdle & collect points
      setIsJumping(true);
      sounds.playJump();
      sounds.playCoin();
      setScore((prev) => prev + 150);
      setTimeout(() => setIsJumping(false), 500);
      setHurdlePromptIndex((prev) => prev + 1);

      // Add actual Brain Coins
      appActions.addCoins(10);
      appActions.addXp(20);
    } else {
      // Tripped
      sounds.playError();
      const newHealth = Math.max(0, health - 40);
      setHealth(newHealth);
      if (newHealth <= 0) {
        setGameOver(true);
        setIsPlaying(false);
      }
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between border-b border-white/10 pb-4">
        <div>
          <h2 className="text-2xl font-black text-white flex items-center gap-2">
            <span>Knowledge Runner</span>
            <span className="text-xs bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-full border border-emerald-500/30">
              Endless Concept Sprint
            </span>
          </h2>
          <p className="text-xs text-slate-400">
            Pick the right answer before the hurdle hits to jump and gather Brain Coins!
          </p>
        </div>

        <div className="flex items-center gap-4 text-xs font-mono">
          <div className="flex items-center gap-1.5 text-rose-400">
            <Heart className="h-4 w-4 fill-rose-500" />
            <span className="font-bold">{health} HP</span>
          </div>
          <div className="flex items-center gap-1.5 text-amber-400">
            <Coins className="h-4 w-4" />
            <span className="font-bold">{score} Pts</span>
          </div>
        </div>
      </div>

      {/* Runner Arena */}
      <div className="relative h-64 w-full overflow-hidden rounded-2xl border border-emerald-500/30 bg-gradient-to-b from-[#080D18] via-slate-950 to-emerald-950/20 p-6 flex flex-col justify-between">
        {/* Sky / Grid lines */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b15_1px,transparent_1px),linear-gradient(to_bottom,#1e293b15_1px,transparent_1px)] bg-[size:32px_32px]" />

        {/* Runner Character & Hurdle Canvas Track */}
        <div className="relative z-10 flex items-center justify-between h-28 my-auto">
          {/* Player avatar */}
          <div className={`transition-all duration-300 transform ${
            isJumping ? "-translate-y-16 scale-110" : "translate-y-0"
          }`}>
            <div className="flex flex-col items-center">
              <span className="text-4xl filter drop-shadow-[0_0_12px_rgba(34,197,94,0.6)]">
                🦉
              </span>
              <div className="h-1.5 w-8 rounded-full bg-emerald-500/30 blur-xs mt-1" />
            </div>
          </div>

          {/* Hurdle Obstacle approaching */}
          <div className="flex flex-col items-center">
            <div className="rounded-xl border border-rose-500/50 bg-rose-950/60 p-2 text-center text-xs font-bold text-rose-300 shadow-lg shadow-rose-950/60 animate-pulse">
              ⚡ DISTRACTION BARRIER ⚡
            </div>
            <div className="h-8 w-12 rounded-t-lg bg-gradient-to-t from-rose-600 to-rose-400 mt-1 shadow-md shadow-rose-600/40" />
          </div>
        </div>

        {/* Floor Line */}
        <div className="relative z-10 h-1.5 w-full rounded-full bg-gradient-to-r from-emerald-500 via-teal-400 to-indigo-500 shadow-md shadow-emerald-500/30" />
      </div>

      {/* Controls / Question Deck */}
      {isPlaying && !gameOver ? (
        <div className="space-y-3">
          <div className="text-center font-bold text-white text-sm md:text-base">
            Jump Query: <span className="text-emerald-400">{currentPrompt.q}</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {currentPrompt.options.map((opt, i) => (
              <button
                key={i}
                onClick={() => handleAnswer(i)}
                className="rounded-2xl border border-white/10 bg-white/5 p-4 text-xs font-bold text-white hover:border-emerald-500 hover:bg-emerald-500/20 transition-all hover:scale-105 active:scale-95"
              >
                {opt}
              </button>
            ))}
          </div>
        </div>
      ) : gameOver ? (
        <div className="text-center space-y-4 py-6">
          <h3 className="text-2xl font-black text-rose-400">Run Ended!</h3>
          <p className="text-xs text-slate-300">
            Final Score: <span className="font-bold text-white">{score} Pts</span>. Earned +{Math.floor(score / 15)} Brain Coins.
          </p>
          <button
            onClick={startGame}
            className="rounded-xl bg-emerald-600 px-6 py-2.5 text-xs font-bold text-white hover:bg-emerald-500 transition-all"
          >
            Play Again
          </button>
        </div>
      ) : (
        <div className="text-center py-6">
          <button
            onClick={startGame}
            className="inline-flex items-center gap-2 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-500 px-8 py-3.5 text-sm font-bold text-white shadow-xl shadow-emerald-600/30 hover:opacity-95 transition-all hover:scale-105"
          >
            <Play className="h-4 w-4 fill-white" />
            <span>Launch Knowledge Runner</span>
          </button>
        </div>
      )}
    </div>
  );
}

// -------------------------------------------------------------
// GAME 2: FLASH BATTLE
// -------------------------------------------------------------
function FlashBattleGame() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [timer, setTimer] = useState(30);
  const [score, setScore] = useState(0);
  const [combo, setCombo] = useState(1);
  const [qIndex, setQIndex] = useState(0);
  const [gameOver, setGameOver] = useState(false);

  const rapidQuestions = [
    { prompt: "Self-attention runs in parallel across all tokens.", answer: true },
    { prompt: "Dopamine is released strictly after a goal is accomplished.", answer: false },
    { prompt: "RAG injects dynamic external documents into the prompt.", answer: true },
    { prompt: "Index funds have higher expense ratios than hedge funds.", answer: false },
    { prompt: "BJ Fogg model states Behavior = Motivation + Ability + Prompt.", answer: true },
    { prompt: "Ultradian focus cycles last approximately 90 minutes.", answer: true },
  ];

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isPlaying && timer > 0) {
      interval = setInterval(() => setTimer((t) => t - 1), 1000);
    } else if (timer === 0 && isPlaying) {
      setIsPlaying(false);
      setGameOver(true);
      sounds.playLevelUp();
    }
    return () => clearInterval(interval);
  }, [isPlaying, timer]);

  const handleChoice = (choice: boolean) => {
    const curr = rapidQuestions[qIndex % rapidQuestions.length];
    if (choice === curr.answer) {
      sounds.playCorrect();
      setScore((s) => s + 100 * combo);
      setCombo((c) => Math.min(4, c + 1));
      appActions.addCoins(5 * combo);
    } else {
      sounds.playError();
      setCombo(1);
    }
    setQIndex((q) => q + 1);
  };

  const startBattle = () => {
    setIsPlaying(true);
    setTimer(30);
    setScore(0);
    setCombo(1);
    setQIndex(0);
    setGameOver(false);
    sounds.playLevelUp();
  };

  const curr = rapidQuestions[qIndex % rapidQuestions.length];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between border-b border-white/10 pb-4">
        <div>
          <h2 className="text-2xl font-black text-white flex items-center gap-2">
            <span>Flash Battle Blitz</span>
            <span className="text-xs bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded-full border border-amber-500/30">
              30-Second Speed Challenge
            </span>
          </h2>
          <p className="text-xs text-slate-400">
            Answer as fast as possible to build combo multipliers up to 4x!
          </p>
        </div>

        <div className="flex items-center gap-4 text-xs font-mono">
          <div className="flex items-center gap-1.5 text-amber-400">
            <Clock className="h-4 w-4" />
            <span className="font-bold">{timer}s</span>
          </div>
          <div className="flex items-center gap-1.5 text-orange-400">
            <Flame className="h-4 w-4 fill-orange-400 animate-pulse" />
            <span className="font-bold">{combo}x Combo</span>
          </div>
          <div className="flex items-center gap-1.5 text-white">
            <Trophy className="h-4 w-4 text-yellow-400" />
            <span className="font-bold">{score} Pts</span>
          </div>
        </div>
      </div>

      {isPlaying ? (
        <div className="space-y-6 text-center max-w-xl mx-auto py-8">
          <div className="rounded-3xl border border-amber-500/40 bg-amber-950/20 p-8 shadow-xl">
            <div className="text-xs font-bold uppercase tracking-wider text-amber-400 mb-2">
              Rapid Question #{qIndex + 1}
            </div>
            <div className="text-lg md:text-xl font-bold text-white leading-relaxed">
              "{curr.prompt}"
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <button
              onClick={() => handleChoice(true)}
              className="rounded-2xl border border-emerald-500/50 bg-emerald-600/20 p-6 text-lg font-black text-emerald-300 hover:bg-emerald-600 hover:text-white transition-all hover:scale-105 active:scale-95"
            >
              TRUE
            </button>
            <button
              onClick={() => handleChoice(false)}
              className="rounded-2xl border border-rose-500/50 bg-rose-600/20 p-6 text-lg font-black text-rose-300 hover:bg-rose-600 hover:text-white transition-all hover:scale-105 active:scale-95"
            >
              FALSE
            </button>
          </div>
        </div>
      ) : gameOver ? (
        <div className="text-center space-y-4 py-8">
          <h3 className="text-3xl font-black text-amber-400">Time's Up!</h3>
          <p className="text-sm text-slate-300">
            You scored <span className="font-bold text-white text-lg">{score} Points</span> with maximum {combo}x combo.
          </p>
          <button
            onClick={startBattle}
            className="rounded-xl bg-amber-500 px-6 py-2.5 text-xs font-bold text-black hover:bg-amber-400 transition-all font-bold"
          >
            Play Again
          </button>
        </div>
      ) : (
        <div className="text-center py-10">
          <button
            onClick={startBattle}
            className="inline-flex items-center gap-2 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-500 px-8 py-3.5 text-sm font-bold text-black shadow-xl shadow-amber-500/30 hover:opacity-95 transition-all hover:scale-105"
          >
            <Zap className="h-4 w-4 fill-black" />
            <span>Start 30s Flash Battle</span>
          </button>
        </div>
      )}
    </div>
  );
}

// -------------------------------------------------------------
// GAME 3: MEMORY CONCEPT CHALLENGE
// -------------------------------------------------------------
function MemoryChallengeGame() {
  const cardsData = [
    { id: 1, pairId: "rag", label: "RAG" },
    { id: 2, pairId: "rag", label: "Vector Search" },
    { id: 3, pairId: "trans", label: "Transformer" },
    { id: 4, pairId: "trans", label: "Self-Attention" },
    { id: 5, pairId: "fogg", label: "BJ Fogg" },
    { id: 6, pairId: "fogg", label: "B = MAP" },
    { id: 7, pairId: "fin", label: "Rule of 72" },
    { id: 8, pairId: "fin", label: "Compound Years" },
  ];

  const [cards, setCards] = useState(cardsData);
  const [selectedIndices, setSelectedIndices] = useState<number[]>([]);
  const [matchedPairIds, setMatchedPairIds] = useState<string[]>([]);
  const [moves, setMoves] = useState(0);

  const handleCardClick = (index: number) => {
    if (selectedIndices.length === 2 || selectedIndices.includes(index)) return;
    const currentCard = cards[index];
    if (matchedPairIds.includes(currentCard.pairId)) return;

    sounds.playClick();
    const newSelected = [...selectedIndices, index];
    setSelectedIndices(newSelected);

    if (newSelected.length === 2) {
      setMoves((m) => m + 1);
      const cardA = cards[newSelected[0]];
      const cardB = cards[newSelected[1]];

      if (cardA.pairId === cardB.pairId) {
        // Matched!
        sounds.playCorrect();
        setMatchedPairIds((prev) => [...prev, cardA.pairId]);
        setSelectedIndices([]);
        appActions.addCoins(15);
        appActions.addXp(30);
      } else {
        // No match
        sounds.playError();
        setTimeout(() => setSelectedIndices([]), 900);
      }
    }
  };

  const resetGame = () => {
    setMatchedPairIds([]);
    setSelectedIndices([]);
    setMoves(0);
    // Shuffle
    setCards([...cardsData].sort(() => Math.random() - 0.5));
  };

  const isAllMatched = matchedPairIds.length === 4;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between border-b border-white/10 pb-4">
        <div>
          <h2 className="text-2xl font-black text-white flex items-center gap-2">
            <span>Memory Concept Flip</span>
            <span className="text-xs bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded-full border border-indigo-500/30">
              Synaptic Retention
            </span>
          </h2>
          <p className="text-xs text-slate-400">
            Flip and match concepts to their definitions or formulas!
          </p>
        </div>

        <div className="flex items-center gap-4 text-xs font-mono">
          <span className="text-slate-400">Moves: <span className="font-bold text-white">{moves}</span></span>
          <button
            onClick={resetGame}
            className="flex items-center gap-1 text-indigo-400 hover:text-indigo-300"
          >
            <RotateCcw className="h-3.5 w-3.5" />
            <span>Reset</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-2xl mx-auto py-4">
        {cards.map((c, i) => {
          const isFlipped = selectedIndices.includes(i) || matchedPairIds.includes(c.pairId);
          const isMatched = matchedPairIds.includes(c.pairId);

          return (
            <div
              key={c.id}
              onClick={() => handleCardClick(i)}
              className={`h-28 rounded-2xl border p-3 flex items-center justify-center text-center cursor-pointer select-none transition-all duration-300 ${
                isMatched
                  ? "border-emerald-500/60 bg-emerald-950/40 text-emerald-300 font-bold scale-[0.98]"
                  : isFlipped
                  ? "border-indigo-500 bg-indigo-600/30 text-white font-bold"
                  : "border-white/10 bg-white/5 hover:border-white/20 text-transparent"
              }`}
            >
              {isFlipped ? (
                <span className="text-sm">{c.label}</span>
              ) : (
                <Sparkles className="h-5 w-5 text-indigo-400/50" />
              )}
            </div>
          );
        })}
      </div>

      {isAllMatched && (
        <div className="text-center space-y-2 py-4 animate-in fade-in">
          <h3 className="text-2xl font-black text-emerald-400">Grid Cleared! 🎉</h3>
          <p className="text-xs text-slate-300">
            You matched all concepts in {moves} moves. +60 Brain Coins awarded!
          </p>
        </div>
      )}
    </div>
  );
}

// -------------------------------------------------------------
// GAME 4: AI BOSS BATTLE
// -------------------------------------------------------------
function AIBossBattleGame() {
  const [bossHp, setBossHp] = useState(400);
  const [playerHp, setPlayerHp] = useState(200);
  const [activeQuestion, setActiveQuestion] = useState<{
    prompt: string;
    options: string[];
    correct: number;
    moveType: "beam" | "logic" | "heal";
  } | null>(null);
  const [combatLog, setCombatLog] = useState<string[]>([
    "The Dopamine Glitch Lord has emerged from the Doom-Scroll Abyss!",
    "Prepare your knowledge arsenal to shatter the distraction shield."
  ]);
  const [battleFinished, setBattleFinished] = useState(false);

  const startMove = (type: "beam" | "logic" | "heal") => {
    if (type === "beam") {
      setActiveQuestion({
        prompt: "What mathematical dot-product scales Transformer attention?",
        options: ["Q * K^T / sqrt(d_k)", "Random seed shuffle", "Batch normalization scalar"],
        correct: 0,
        moveType: "beam"
      });
    } else if (type === "logic") {
      setActiveQuestion({
        prompt: "Why does RAG cost dramatically less than fine-tuning?",
        options: ["No weight gradient backpropagation required", "It uses no compute", "It requires 100x more GPUs"],
        correct: 0,
        moveType: "logic"
      });
    } else {
      setActiveQuestion({
        prompt: "BJ Fogg: To make a habit happen easily, you should:",
        options: ["Decrease friction / increase ability", "Wait for high motivation only", "Double the steps required"],
        correct: 0,
        moveType: "heal"
      });
    }
  };

  const handleAnswerBossQ = (index: number) => {
    if (!activeQuestion) return;

    if (index === activeQuestion.correct) {
      sounds.playBossHit();
      if (activeQuestion.moveType === "beam") {
        const nextBoss = Math.max(0, bossHp - 150);
        setBossHp(nextBoss);
        setCombatLog((prev) => [
          "💥 Hyper Focus Beam hits the Boss for 150 Damage!",
          ...prev.slice(0, 4)
        ]);
        if (nextBoss <= 0) handleBossDefeated();
      } else if (activeQuestion.moveType === "logic") {
        const nextBoss = Math.max(0, bossHp - 200);
        setBossHp(nextBoss);
        setCombatLog((prev) => [
          "⚡ Logic Overdrive Strike crits the Boss for 200 Damage!",
          ...prev.slice(0, 4)
        ]);
        if (nextBoss <= 0) handleBossDefeated();
      } else {
        const nextHp = Math.min(200, playerHp + 60);
        setPlayerHp(nextHp);
        setCombatLog((prev) => [
          "🛡️ Mind Shield restored 60 Player HP!",
          ...prev.slice(0, 4)
        ]);
      }
    } else {
      // Boss counter-attacks
      sounds.playError();
      const nextHp = Math.max(0, playerHp - 60);
      setPlayerHp(nextHp);
      setCombatLog((prev) => [
        "❌ Wrong answer! Boss casts 'Doom Scroll Storm' for 60 Damage!",
        ...prev.slice(0, 4)
      ]);
      if (nextHp <= 0) {
        setBattleFinished(true);
      }
    }

    setActiveQuestion(null);
  };

  const handleBossDefeated = () => {
    sounds.playLevelUp();
    sounds.playCoin();
    setBattleFinished(true);
    appActions.addCoins(100);
    appActions.addXp(250);
  };

  const restartBattle = () => {
    setBossHp(400);
    setPlayerHp(200);
    setActiveQuestion(null);
    setBattleFinished(false);
    setCombatLog(["A new incarnation of the Glitch Lord challenges your focus!"]);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between border-b border-white/10 pb-4">
        <div>
          <h2 className="text-2xl font-black text-white flex items-center gap-2">
            <span>AI Boss Battle</span>
            <span className="text-xs bg-rose-500/20 text-rose-300 px-2 py-0.5 rounded-full border border-rose-500/30">
              Turn-Based Concept Combat
            </span>
          </h2>
          <p className="text-xs text-slate-400">
            Answer questions to execute high-impact focus attacks and defeat the Dopamine Glitch Lord!
          </p>
        </div>
      </div>

      {/* Boss vs Player Arena */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
        {/* Player Stats */}
        <div className="rounded-2xl border border-indigo-500/30 bg-indigo-950/20 p-5">
          <div className="flex items-center justify-between mb-2">
            <span className="font-bold text-white text-sm flex items-center gap-2">
              <span className="text-2xl">🦉</span>
              <span>Scholar Guardian</span>
            </span>
            <span className="text-xs font-mono font-bold text-emerald-400">{playerHp} / 200 HP</span>
          </div>
          <div className="h-2 w-full rounded-full bg-slate-800 overflow-hidden">
            <div 
              className="h-full bg-emerald-500 transition-all duration-300"
              style={{ width: `${(playerHp / 200) * 100}%` }}
            />
          </div>
        </div>

        {/* Boss Stats */}
        <div className="rounded-2xl border border-rose-500/30 bg-rose-950/20 p-5">
          <div className="flex items-center justify-between mb-2">
            <span className="font-bold text-white text-sm flex items-center gap-2">
              <span className="text-2xl">👾</span>
              <span className="text-rose-300">Dopamine Glitch Lord</span>
            </span>
            <span className="text-xs font-mono font-bold text-rose-400">{bossHp} / 400 HP</span>
          </div>
          <div className="h-2 w-full rounded-full bg-slate-800 overflow-hidden">
            <div 
              className="h-full bg-rose-500 transition-all duration-300"
              style={{ width: `${(bossHp / 400) * 100}%` }}
            />
          </div>
        </div>
      </div>

      {/* Question or Attack Buttons */}
      {!battleFinished && !activeQuestion && (
        <div className="space-y-3">
          <div className="text-xs font-bold uppercase tracking-wider text-slate-400">
            Choose Your Knowledge Attack:
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <button
              onClick={() => startMove("beam")}
              className="rounded-2xl border border-indigo-500/40 bg-indigo-600/20 p-4 text-left hover:bg-indigo-600/40 transition-all hover:scale-105"
            >
              <div className="font-bold text-white text-xs mb-1">⚡ Hyper Focus Beam</div>
              <div className="text-[11px] text-indigo-200">Deals 150 Damage (Intermediate AI question)</div>
            </button>

            <button
              onClick={() => startMove("logic")}
              className="rounded-2xl border border-rose-500/40 bg-rose-600/20 p-4 text-left hover:bg-rose-600/40 transition-all hover:scale-105"
            >
              <div className="font-bold text-white text-xs mb-1">💥 Logic Overdrive</div>
              <div className="text-[11px] text-rose-200">Deals 200 Damage (Advanced RAG question)</div>
            </button>

            <button
              onClick={() => startMove("heal")}
              className="rounded-2xl border border-emerald-500/40 bg-emerald-600/20 p-4 text-left hover:bg-emerald-600/40 transition-all hover:scale-105"
            >
              <div className="font-bold text-white text-xs mb-1">🛡️ Mind Shield Restorative</div>
              <div className="text-[11px] text-emerald-200">Heals +60 HP (Behavioral Psychology question)</div>
            </button>
          </div>
        </div>
      )}

      {/* Active Boss Battle Question Modal */}
      {activeQuestion && (
        <div className="rounded-2xl border border-white/20 bg-black/60 p-6 space-y-4 animate-in fade-in">
          <div className="text-xs font-bold uppercase tracking-wider text-indigo-400">
            Solve To Cast Spell:
          </div>
          <div className="text-sm font-bold text-white">{activeQuestion.prompt}</div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
            {activeQuestion.options.map((opt, idx) => (
              <button
                key={idx}
                onClick={() => handleAnswerBossQ(idx)}
                className="rounded-xl border border-white/10 bg-white/5 p-3 text-xs font-semibold text-slate-200 hover:border-indigo-400 hover:bg-indigo-500/20 transition-all text-left"
              >
                {opt}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Battle Finished */}
      {battleFinished && (
        <div className="text-center space-y-3 py-6">
          {bossHp <= 0 ? (
            <>
              <h3 className="text-3xl font-black text-yellow-400">VICTORY! The Glitch Lord is Slain! 🏆</h3>
              <p className="text-xs text-slate-300">
                You earned +100 Brain Coins and +250 XP for your Focus Pet!
              </p>
            </>
          ) : (
            <>
              <h3 className="text-3xl font-black text-rose-400">Defeated! 💀</h3>
              <p className="text-xs text-slate-300">
                The dopamine fog overwhelmed your focus. Rest your pet and try again!
              </p>
            </>
          )}

          <button
            onClick={restartBattle}
            className="rounded-xl bg-indigo-600 px-6 py-2.5 text-xs font-bold text-white hover:bg-indigo-500 transition-all"
          >
            Play Battle Again
          </button>
        </div>
      )}

      {/* Combat Log */}
      <div className="rounded-2xl border border-white/5 bg-white/5 p-4 text-xs font-mono text-slate-400 space-y-1">
        <div className="text-[10px] uppercase font-bold text-slate-500 mb-1">Combat Terminal:</div>
        {combatLog.map((log, idx) => (
          <div key={idx} className="truncate">{log}</div>
        ))}
      </div>
    </div>
  );
}
