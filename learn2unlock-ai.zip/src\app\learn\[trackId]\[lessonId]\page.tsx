"use client";

import { useState, useEffect } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { INITIAL_TRACKS } from "@/lib/mockData";
import { useAppState, appActions } from "@/lib/store";
import { sounds } from "@/lib/soundEffects";
import { 
  ArrowLeft, 
  Play, 
  Pause, 
  RotateCcw, 
  Volume2, 
  CheckCircle2, 
  Sparkles, 
  Clock, 
  Coins, 
  Zap, 
  HelpCircle, 
  BookMarked,
  Layers,
  ArrowRight
} from "lucide-react";

export default function LessonViewerPage() {
  const params = useParams();
  const router = useRouter();
  const state = useAppState();

  const trackId = params.trackId as string;
  const lessonId = params.lessonId as string;

  const track = INITIAL_TRACKS.find((t) => t.id === trackId) || INITIAL_TRACKS[0];
  const lesson = track?.lessons.find((l) => l.id === lessonId) || track.lessons[0];

  // Video player simulated states
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const totalDuration = lesson.durationMinutes * 60; // in seconds
  const [playbackSpeed, setPlaybackSpeed] = useState(1);
  const [activeTab, setActiveTab] = useState<"summary" | "keypoints" | "ainotes" | "flashcards">("summary");
  const [flippedCards, setFlippedCards] = useState<Record<number, boolean>>({});

  const isCompleted = state.completedLessons.includes(lesson.id);

  // Simulated video playback ticker
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isPlaying) {
      interval = setInterval(() => {
        setCurrentTime((prev) => {
          if (prev >= totalDuration) {
            setIsPlaying(false);
            return totalDuration;
          }
          return prev + 1 * playbackSpeed;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isPlaying, playbackSpeed, totalDuration]);

  const handleCompleteLesson = () => {
    appActions.completeLesson(lesson.id, lesson.xpReward, lesson.coinsReward);
    sounds.playLevelUp();
    // Redirect to Quiz
    router.push(`/quiz/${lesson.id}`);
  };

  const progressPercent = Math.min(100, Math.round((currentTime / totalDuration) * 100));

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  const toggleFlip = (index: number) => {
    sounds.playClick();
    setFlippedCards((prev) => ({ ...prev, [index]: !prev[index] }));
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Top Breadcrumb & Actions */}
      <div className="flex items-center justify-between">
        <Link
          href="/learn"
          className="flex items-center gap-2 text-xs font-semibold text-slate-400 hover:text-white transition-colors"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Back to All Tracks</span>
        </Link>

        <div className="flex items-center gap-2">
          <span className="rounded-lg bg-indigo-500/20 px-3 py-1 text-xs font-bold text-indigo-300 border border-indigo-500/30">
            {lesson.category}
          </span>
          <span className="rounded-lg bg-amber-500/20 px-3 py-1 text-xs font-bold text-amber-300 border border-amber-500/30">
            +{lesson.coinsReward} Coins
          </span>
        </div>
      </div>

      {/* Main Grid: Video Player + Interactive Companion Panels */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Video Lesson & Controls (2 cols) */}
        <div className="lg:col-span-2 space-y-4">
          {/* Simulated Futuristic Educational Player */}
          <div className="relative aspect-video w-full overflow-hidden rounded-3xl border border-indigo-500/30 bg-gradient-to-br from-slate-950 via-[#0B0F1B] to-slate-900 shadow-2xl flex flex-col justify-between p-6">
            {/* Visual Canvas Backdrop Animation */}
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-indigo-900/30 via-slate-950/60 to-black pointer-events-none" />

            {/* Top Bar inside player */}
            <div className="relative z-10 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="flex h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
                <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
                  AI Micro-Lesson Stream
                </span>
              </div>
              <span className="rounded-full bg-black/60 px-2.5 py-1 text-xs font-mono font-bold text-slate-300 border border-white/10">
                {formatTime(currentTime)} / {formatTime(totalDuration)}
              </span>
            </div>

            {/* Center Dynamic Video Visual */}
            <div className="relative z-10 text-center my-auto">
              <div className="mx-auto mb-3 flex h-16 w-16 items-center justify-center rounded-2xl bg-indigo-600/30 border border-indigo-500/50 text-indigo-300 shadow-lg backdrop-blur-md">
                <Sparkles className="h-8 w-8 animate-pulse text-indigo-400" />
              </div>
              <h2 className="text-xl md:text-2xl font-black text-white max-w-lg mx-auto">
                {lesson.title}
              </h2>
              <p className="text-xs text-indigo-200 mt-1">
                {lesson.category} • Concept Masterclass
              </p>
            </div>

            {/* Bottom Controls Bar */}
            <div className="relative z-10 space-y-3 bg-black/40 backdrop-blur-md p-3 rounded-2xl border border-white/10">
              {/* Progress Slider */}
              <div className="relative h-2 w-full rounded-full bg-slate-800 cursor-pointer overflow-hidden"
                onClick={(e) => {
                  const rect = e.currentTarget.getBoundingClientRect();
                  const pos = (e.clientX - rect.left) / rect.width;
                  setCurrentTime(Math.floor(pos * totalDuration));
                }}
              >
                <div 
                  className="h-full bg-gradient-to-r from-indigo-500 to-emerald-400 transition-all"
                  style={{ width: `${progressPercent}%` }}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => {
                      sounds.playClick();
                      setIsPlaying(!isPlaying);
                    }}
                    className="flex h-9 w-9 items-center justify-center rounded-xl bg-white text-black hover:bg-slate-200 transition-colors shadow-md"
                  >
                    {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4 fill-black" />}
                  </button>

                  <button
                    onClick={() => {
                      sounds.playClick();
                      setCurrentTime(0);
                    }}
                    className="rounded-lg p-2 text-slate-400 hover:text-white hover:bg-white/5 transition-colors"
                    title="Restart"
                  >
                    <RotateCcw className="h-4 w-4" />
                  </button>

                  <div className="flex items-center gap-1">
                    {[1, 1.5, 2].map((spd) => (
                      <button
                        key={spd}
                        onClick={() => setPlaybackSpeed(spd)}
                        className={`rounded px-2 py-0.5 text-[11px] font-bold ${
                          playbackSpeed === spd
                            ? "bg-indigo-600 text-white"
                            : "text-slate-400 hover:text-white"
                        }`}
                      >
                        {spd}x
                      </button>
                    ))}
                  </div>
                </div>

                {/* Complete & Quiz Trigger Button */}
                <button
                  onClick={handleCompleteLesson}
                  className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-500 px-4 py-2 text-xs font-bold text-white shadow-lg shadow-emerald-600/30 hover:opacity-95 transition-all hover:scale-105"
                >
                  <CheckCircle2 className="h-4 w-4" />
                  <span>Finish & Take AI Quiz</span>
                </button>
              </div>
            </div>
          </div>

          {/* Lesson Description & Metadata */}
          <div className="glass-card rounded-2xl p-6 border border-white/10">
            <h3 className="font-bold text-white text-lg mb-2">Lesson Overview</h3>
            <p className="text-sm text-slate-300 leading-relaxed mb-4">
              {lesson.description}
            </p>

            <div className="flex flex-wrap items-center gap-4 text-xs text-slate-400 pt-4 border-t border-white/10">
              <span className="flex items-center gap-1.5">
                <Clock className="h-4 w-4 text-indigo-400" />
                <span>{lesson.durationMinutes} Minutes Micro-Learning</span>
              </span>
              <span className="flex items-center gap-1.5">
                <Coins className="h-4 w-4 text-amber-400" />
                <span>Earn {lesson.coinsReward} Brain Coins</span>
              </span>
              <span className="flex items-center gap-1.5">
                <Zap className="h-4 w-4 text-emerald-400" />
                <span>Gain {lesson.xpReward} XP for Pet</span>
              </span>
            </div>
          </div>
        </div>

        {/* Right Column: Interactive Panels (Summary, Key Points, AI Notes, Flashcards) */}
        <div className="space-y-4">
          {/* Navigation Tabs */}
          <div className="grid grid-cols-4 gap-1 rounded-2xl border border-white/10 bg-white/5 p-1">
            <button
              onClick={() => setActiveTab("summary")}
              className={`rounded-xl py-2 text-xs font-bold transition-all ${
                activeTab === "summary"
                  ? "bg-indigo-600 text-white shadow"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              Summary
            </button>
            <button
              onClick={() => setActiveTab("keypoints")}
              className={`rounded-xl py-2 text-xs font-bold transition-all ${
                activeTab === "keypoints"
                  ? "bg-indigo-600 text-white shadow"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              Key Points
            </button>
            <button
              onClick={() => setActiveTab("ainotes")}
              className={`rounded-xl py-2 text-xs font-bold transition-all ${
                activeTab === "ainotes"
                  ? "bg-indigo-600 text-white shadow"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              AI Notes
            </button>
            <button
              onClick={() => setActiveTab("flashcards")}
              className={`rounded-xl py-2 text-xs font-bold transition-all ${
                activeTab === "flashcards"
                  ? "bg-indigo-600 text-white shadow"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              Cards
            </button>
          </div>

          {/* Tab Content 1: Summary */}
          {activeTab === "summary" && (
            <div className="glass-card rounded-2xl p-5 border border-white/10 space-y-4">
              <div className="flex items-center gap-2 text-indigo-400 text-xs font-bold">
                <Sparkles className="h-4 w-4" />
                <span>Executive Summary</span>
              </div>
              <p className="text-xs md:text-sm text-slate-200 leading-relaxed bg-white/5 p-4 rounded-xl border border-white/5">
                {lesson.summary}
              </p>
            </div>
          )}

          {/* Tab Content 2: Key Points */}
          {activeTab === "keypoints" && (
            <div className="glass-card rounded-2xl p-5 border border-white/10 space-y-3">
              <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold mb-1">
                <CheckCircle2 className="h-4 w-4" />
                <span>Critical Takeaways</span>
              </div>
              {lesson.keyPoints.map((pt, i) => (
                <div key={i} className="flex items-start gap-2.5 text-xs text-slate-300">
                  <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-emerald-500/20 text-emerald-300 font-bold text-[10px]">
                    {i + 1}
                  </span>
                  <p className="leading-relaxed">{pt}</p>
                </div>
              ))}
            </div>
          )}

          {/* Tab Content 3: AI Notes */}
          {activeTab === "ainotes" && (
            <div className="glass-card rounded-2xl p-5 border border-white/10 space-y-3">
              <div className="flex items-center gap-2 text-amber-400 text-xs font-bold mb-1">
                <Sparkles className="h-4 w-4" />
                <span>AI-Generated Syntheses</span>
              </div>
              {lesson.aiNotes.map((note, i) => (
                <div key={i} className="rounded-xl border border-amber-500/20 bg-amber-500/5 p-3 text-xs text-amber-200/90 leading-relaxed">
                  💡 {note}
                </div>
              ))}
            </div>
          )}

          {/* Tab Content 4: Revision Flashcards */}
          {activeTab === "flashcards" && (
            <div className="glass-card rounded-2xl p-5 border border-white/10 space-y-3">
              <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                <span className="font-bold text-white flex items-center gap-1.5">
                  <Layers className="h-4 w-4 text-indigo-400" />
                  <span>Revision Cards (Click to Flip)</span>
                </span>
                <span>{lesson.revisionCards.length} Cards</span>
              </div>

              {lesson.revisionCards.map((card, i) => {
                const isFlipped = !!flippedCards[i];
                return (
                  <div
                    key={i}
                    onClick={() => toggleFlip(i)}
                    className="cursor-pointer rounded-2xl border border-white/10 bg-white/5 p-4 text-xs transition-all hover:border-indigo-500/40 select-none min-h-[90px] flex flex-col justify-between"
                  >
                    <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                      {isFlipped ? "Answer" : "Question (Tap to reveal)"}
                    </div>
                    <div className={`font-semibold leading-relaxed ${isFlipped ? "text-emerald-300" : "text-white"}`}>
                      {isFlipped ? card.back : card.front}
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* Ready for Quiz Prompt */}
          <div className="glass-card rounded-2xl p-5 border border-indigo-500/40 bg-indigo-950/30 text-center">
            <h4 className="font-bold text-white text-sm mb-1">Finished watching?</h4>
            <p className="text-xs text-slate-300 mb-3">
              Pass the 70% adaptive quiz to mark this lesson completed and earn your screen time.
            </p>
            <button
              onClick={handleCompleteLesson}
              className="w-full flex items-center justify-center gap-2 rounded-xl bg-indigo-600 py-3 text-xs font-bold text-white shadow-lg shadow-indigo-600/30 hover:bg-indigo-500 transition-all hover:scale-[1.02]"
            >
              <span>Launch Adaptive Quiz</span>
              <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
