"use client";

import { useState } from "react";
import { useAppState, appActions } from "@/lib/store";
import { sounds } from "@/lib/soundEffects";
import { PetType } from "@/types";
import { 
  Sparkles, 
  Flame, 
  Zap, 
  Heart, 
  ShieldCheck, 
  ArrowRight, 
  RotateCcw,
  Bot,
  Crown
} from "lucide-react";

export default function PetEvolutionPage() {
  const state = useAppState();
  const pet = state.pet;

  const [activeTab, setActiveTab] = useState<"status" | "evolution" | "accessories">("status");

  const STAGES = [
    {
      stage: 1,
      title: "Hatchling / Core Seed",
      reqLevel: 1,
      perk: "Base Learning Focus",
      desc: "Young and vulnerable to digital distractions. Needs daily learning nutrients.",
    },
    {
      stage: 2,
      title: "Cyber Apprentice",
      reqLevel: 4,
      perk: "+10% Brain Coin Boost on 100% Quiz Scores",
      desc: "Equipped with digital neural dampeners that reduce craving impulses.",
    },
    {
      stage: 3,
      title: "Focus Guardian",
      reqLevel: 7,
      perk: "+25% XP Boost on all Mini-Games",
      desc: "An armored guardian capable of deflecting dopamine fog and social notifications.",
    },
    {
      stage: 4,
      title: "Ascended Hyper-Sage",
      reqLevel: 10,
      perk: "1 Free Emergency Pass Regeneration / Week",
      desc: "Achieved supreme monk-like digital equanimity. Unlocks legendary neon aura.",
    },
  ];

  const handlePetAction = (action: "feed" | "train" | "cheer") => {
    if (action === "feed") {
      appActions.feedPet();
    } else if (action === "train") {
      sounds.playLevelUp();
      appActions.addXp(40);
      alert(`${pet.name} completed mental agility drills! +40 XP earned.`);
    } else {
      sounds.playCoin();
      alert(`You cheered on ${pet.name}! Happiness increased.`);
    }
  };

  const handleSelectPetType = (type: PetType) => {
    sounds.playLevelUp();
    const nameMap: Record<PetType, string> = {
      owl: "Archie the Cyber Owl",
      fox: "Byte the Quantum Fox",
      robot: "Aegis the Iron Bot",
    };
    appActions.changePetType(type, nameMap[type]);
  };

  const petEmoji = 
    pet.type === "owl" ? "🦉" :
    pet.type === "fox" ? "🦊" : "🤖";

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 text-indigo-400 text-xs font-bold uppercase tracking-wider mb-1">
          <Sparkles className="h-4 w-4" />
          <span>Core Feature 2: Emotional Companion System</span>
        </div>
        <h1 className="text-3xl font-black text-white tracking-tight">Focus Pet Evolution</h1>
        <p className="text-sm text-slate-400 mt-1">
          Every lesson powers your companion. Excessive scrolling tires them; consistent learning evolves them into legendary guardians.
        </p>
      </div>

      {/* Main Grid: Interactive Pet Stage + Details */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Interactive Pet Hero Stage (2 cols) */}
        <div className="lg:col-span-2 glass-card rounded-3xl p-8 border border-indigo-500/30 flex flex-col items-center text-center justify-between relative overflow-hidden bg-gradient-to-b from-[#0F1424] via-slate-950 to-[#0A0E1A]">
          {/* Glowing Aura Ring */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 h-72 w-72 rounded-full bg-gradient-to-tr from-indigo-600/30 via-emerald-500/20 to-purple-600/30 blur-3xl pointer-events-none" />

          {/* Top Stage & Level Pill */}
          <div className="relative z-10 flex items-center justify-between w-full">
            <span className="rounded-full bg-indigo-500/20 border border-indigo-500/40 px-3.5 py-1 text-xs font-bold text-indigo-300">
              Stage {pet.stage}: {STAGES[pet.stage - 1].title}
            </span>
            <span className="flex items-center gap-1.5 rounded-full bg-emerald-500/20 border border-emerald-500/40 px-3 py-1 text-xs font-bold text-emerald-300">
              <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>Mood: {pet.mood}</span>
            </span>
          </div>

          {/* Interactive Pet Visual */}
          <div className="relative z-10 my-8">
            <div className="relative mx-auto flex h-36 w-36 items-center justify-center rounded-full bg-gradient-to-tr from-indigo-600/40 via-purple-600/30 to-emerald-500/30 border-2 border-indigo-400/40 shadow-2xl backdrop-blur-md animate-bounce duration-1000">
              <span className="text-7xl filter drop-shadow-[0_0_20px_rgba(99,102,241,0.7)]">
                {petEmoji}
              </span>
            </div>

            <h2 className="text-2xl font-black text-white mt-4">{pet.name}</h2>
            <p className="text-xs text-indigo-300 font-semibold mt-1">
              Level {pet.level} • {pet.equippedAccessory}
            </p>
          </div>

          {/* Health & XP Progress */}
          <div className="relative z-10 w-full max-w-md space-y-3">
            <div>
              <div className="flex justify-between text-xs text-slate-400 mb-1">
                <span>Experience to Next Evolution</span>
                <span className="font-mono text-white font-bold">{pet.currentXp} / {pet.nextLevelXp} XP</span>
              </div>
              <div className="h-2.5 w-full rounded-full bg-slate-800 overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-indigo-500 to-emerald-400 transition-all duration-500"
                  style={{ width: `${(pet.currentXp / pet.nextLevelXp) * 100}%` }}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2">
              <div className="rounded-xl border border-white/5 bg-white/5 p-2.5 text-left text-xs">
                <span className="text-slate-400 block text-[11px]">Energy</span>
                <span className="font-bold text-emerald-400 text-sm">{pet.energy}%</span>
              </div>
              <div className="rounded-xl border border-white/5 bg-white/5 p-2.5 text-left text-xs">
                <span className="text-slate-400 block text-[11px]">Happiness</span>
                <span className="font-bold text-amber-400 text-sm">{pet.happiness}%</span>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="relative z-10 flex flex-wrap items-center justify-center gap-3 mt-6 pt-4 border-t border-white/10 w-full">
            <button
              onClick={() => handlePetAction("feed")}
              className="flex items-center gap-2 rounded-xl bg-white/10 px-4 py-2 text-xs font-bold text-white hover:bg-white/20 transition-all"
            >
              <span>🍎 Feed Brain Snack</span>
            </button>
            <button
              onClick={() => handlePetAction("train")}
              className="flex items-center gap-2 rounded-xl bg-indigo-600 px-4 py-2 text-xs font-bold text-white hover:bg-indigo-500 transition-all"
            >
              <span>🧠 Train Agility (+XP)</span>
            </button>
            <button
              onClick={() => handlePetAction("cheer")}
              className="flex items-center gap-2 rounded-xl bg-emerald-600/30 px-4 py-2 text-xs font-bold text-emerald-300 hover:bg-emerald-600/50 transition-all border border-emerald-500/40"
            >
              <span>💖 Cheer Companion</span>
            </button>
          </div>
        </div>

        {/* Right Column: Companion Switcher & Evolution Ladder */}
        <div className="space-y-4">
          {/* Switch Pet Type */}
          <div className="glass-card rounded-3xl p-5 border border-white/10 space-y-3">
            <h3 className="font-bold text-white text-sm">Choose Your Companion</h3>
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => handleSelectPetType("owl")}
                className={`rounded-2xl p-3 text-center border transition-all ${
                  pet.type === "owl"
                    ? "border-indigo-500 bg-indigo-600/30 text-white"
                    : "border-white/10 bg-white/5 text-slate-400 hover:text-white"
                }`}
              >
                <div className="text-2xl mb-1">🦉</div>
                <div className="text-xs font-bold">Cyber Owl</div>
                <div className="text-[10px] text-indigo-300">Wisdom</div>
              </button>

              <button
                onClick={() => handleSelectPetType("fox")}
                className={`rounded-2xl p-3 text-center border transition-all ${
                  pet.type === "fox"
                    ? "border-indigo-500 bg-indigo-600/30 text-white"
                    : "border-white/10 bg-white/5 text-slate-400 hover:text-white"
                }`}
              >
                <div className="text-2xl mb-1">🦊</div>
                <div className="text-xs font-bold">Quantum Fox</div>
                <div className="text-[10px] text-amber-300">Speed</div>
              </button>

              <button
                onClick={() => handleSelectPetType("robot")}
                className={`rounded-2xl p-3 text-center border transition-all ${
                  pet.type === "robot"
                    ? "border-indigo-500 bg-indigo-600/30 text-white"
                    : "border-white/10 bg-white/5 text-slate-400 hover:text-white"
                }`}
              >
                <div className="text-2xl mb-1">🤖</div>
                <div className="text-xs font-bold">Iron Bot</div>
                <div className="text-[10px] text-emerald-300">Armor</div>
              </button>
            </div>
          </div>

          {/* Evolution Stages Ladder */}
          <div className="glass-card rounded-3xl p-5 border border-white/10 space-y-3">
            <h3 className="font-bold text-white text-sm">Evolution Road</h3>
            <div className="space-y-2.5">
              {STAGES.map((s) => {
                const isCurrent = pet.stage === s.stage;
                const isUnlocked = pet.level >= s.reqLevel;

                return (
                  <div
                    key={s.stage}
                    className={`rounded-2xl border p-3.5 text-xs transition-all ${
                      isCurrent
                        ? "border-emerald-500/50 bg-emerald-950/20 text-white shadow-md"
                        : isUnlocked
                        ? "border-white/10 bg-white/5 text-slate-300"
                        : "border-white/5 bg-transparent opacity-50 text-slate-500"
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-bold text-sm">
                        Stage {s.stage}: {s.title}
                      </span>
                      <span className="text-[10px] font-mono font-bold">
                        {isUnlocked ? "UNLOCKED" : `Requires Lv.${s.reqLevel}`}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 mb-1.5 leading-relaxed">{s.desc}</p>
                    <div className="text-[10px] font-semibold text-emerald-400">
                      ⚡ Perk: {s.perk}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
