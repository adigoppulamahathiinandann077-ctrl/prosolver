"use client";

import Link from "next/link";
import { useAppState, appActions } from "@/lib/store";
import { aiEngine } from "@/lib/aiEngine";
import { 
  Flame, 
  Coins, 
  Zap, 
  Sparkles, 
  ShieldAlert, 
  BookOpen, 
  Play, 
  ArrowRight, 
  CheckCircle2, 
  Gamepad2, 
  LockOpen, 
  Clock, 
  AlertTriangle,
  Award,
  ChevronRight
} from "lucide-react";
import { useState, useEffect } from "react";

export default function DashboardPage() {
  const state = useAppState();
  const [now, setNow] = useState(Date.now());

  useEffect(() => {
    const timer = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(timer);
  }, []);

  const aiRec = aiEngine.getDailyRecommendation(state.completedLessons);

  const petEmoji = 
    state.pet.type === "owl" ? "🦉" :
    state.pet.type === "fox" ? "🦊" : "🤖";

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Welcome Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-black text-white tracking-tight">
            Welcome Back, Scholar! 👋
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            You are on a <span className="text-orange-400 font-bold">{state.streak}-day learning streak</span>. Ready to earn your screen time today?
          </p>
        </div>

        {/* Quick App Intercept Test */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              const app = state.blockedApps[0];
              appActions.triggerInterceptModal(app);
            }}
            className="flex items-center gap-2 rounded-xl border border-red-500/40 bg-red-500/10 px-4 py-2 text-xs font-bold text-red-300 hover:bg-red-500/20 transition-all hover:scale-105"
          >
            <ShieldAlert className="h-4 w-4 text-red-400" />
            <span>Simulate Instagram Block</span>
          </button>

          <Link
            href="/rewards"
            className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-indigo-600 to-emerald-500 px-4 py-2 text-xs font-bold text-white shadow-lg shadow-indigo-600/25 hover:opacity-95 transition-all"
          >
            <LockOpen className="h-4 w-4" />
            <span>Unlock Shop</span>
          </Link>
        </div>
      </div>

      {/* Grid: AI Recommended Lesson + Focus Pet Card */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* AI Personalized Recommendation Card (2 cols) */}
        <div className="lg:col-span-2 glass-card rounded-3xl p-6 border border-indigo-500/30 relative overflow-hidden bg-gradient-to-br from-indigo-950/40 via-slate-900/80 to-[#0B0F1B]">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-indigo-500/20 text-indigo-400">
                <Sparkles className="h-4 w-4" />
              </span>
              <span className="text-xs font-bold uppercase tracking-wider text-indigo-400">
                Today's AI Recommended Lesson
              </span>
            </div>
            <span className="rounded-full bg-emerald-500/20 border border-emerald-500/30 px-2.5 py-0.5 text-[11px] font-bold text-emerald-300">
              {aiRec.confidenceScore}% Match
            </span>
          </div>

          <h3 className="text-xl md:text-2xl font-black text-white mb-2">
            {aiRec.title}
          </h3>

          <p className="text-xs md:text-sm text-slate-300 mb-4 leading-relaxed">
            <span className="font-semibold text-indigo-300">Why recommended: </span>
            {aiRec.reason}
          </p>

          <div className="flex flex-wrap items-center justify-between gap-4 pt-4 border-t border-white/10">
            <div className="flex items-center gap-4 text-xs text-slate-400">
              <div className="flex items-center gap-1.5">
                <Clock className="h-3.5 w-3.5 text-indigo-400" />
                <span>{aiRec.estimatedMinutes} Mins</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Coins className="h-3.5 w-3.5 text-amber-400" />
                <span>+35 Brain Coins</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Zap className="h-3.5 w-3.5 text-yellow-400" />
                <span>+50 XP</span>
              </div>
            </div>

            <Link
              href={`/learn/${aiRec.trackId}/${aiRec.lessonId}`}
              className="flex items-center gap-2 rounded-xl bg-indigo-600 px-5 py-2.5 text-xs font-bold text-white shadow-lg shadow-indigo-600/30 hover:bg-indigo-500 transition-all hover:scale-105"
            >
              <Play className="h-4 w-4 fill-white" />
              <span>Start Micro-Lesson</span>
            </Link>
          </div>
        </div>

        {/* Focus Pet Companion Card */}
        <div className="glass-card rounded-3xl p-6 border border-white/10 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Focus Companion
              </span>
              <span className="rounded-full bg-indigo-500/20 px-2 py-0.5 text-[10px] font-bold text-indigo-300 border border-indigo-500/30">
                Stage {state.pet.stage}
              </span>
            </div>

            <div className="flex items-center gap-4 my-2">
              <div className="relative flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-tr from-indigo-600/40 to-emerald-500/20 text-3xl border border-indigo-500/30">
                <span>{petEmoji}</span>
              </div>
              <div>
                <h4 className="font-bold text-white text-base">{state.pet.name}</h4>
                <p className="text-xs text-emerald-400 font-semibold flex items-center gap-1">
                  <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span>Mood: {state.pet.mood}</span>
                </p>
                <div className="text-[11px] text-slate-400 mt-1">
                  Level {state.pet.level} • {state.pet.equippedAccessory}
                </div>
              </div>
            </div>

            {/* XP and Energy Bars */}
            <div className="space-y-2 mt-4 text-xs">
              <div>
                <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                  <span>Pet XP</span>
                  <span className="font-mono text-white">
                    {state.pet.currentXp} / {state.pet.nextLevelXp}
                  </span>
                </div>
                <div className="h-1.5 w-full rounded-full bg-slate-800 overflow-hidden">
                  <div 
                    className="h-full bg-indigo-500 transition-all"
                    style={{ width: `${(state.pet.currentXp / state.pet.nextLevelXp) * 100}%` }}
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                  <span>Energy & Stamina</span>
                  <span className="font-mono text-white">{state.pet.energy}%</span>
                </div>
                <div className="h-1.5 w-full rounded-full bg-slate-800 overflow-hidden">
                  <div 
                    className="h-full bg-emerald-500 transition-all"
                    style={{ width: `${state.pet.energy}%` }}
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-white/10 flex items-center gap-2">
            <button
              onClick={() => appActions.feedPet()}
              className="flex-1 rounded-xl bg-white/5 py-2 text-xs font-bold text-slate-200 hover:bg-white/10 transition-colors border border-white/5"
            >
              🍎 Feed Snack (+Energy)
            </button>
            <Link
              href="/pet"
              className="rounded-xl bg-indigo-600/30 px-3 py-2 text-xs font-bold text-indigo-300 hover:bg-indigo-600/50 transition-colors"
            >
              Evolve →
            </Link>
          </div>
        </div>
      </div>

      {/* Blocked Apps Status & Live Unlocks */}
      <div className="glass-card rounded-3xl p-6 border border-white/10">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
          <div>
            <h3 className="font-black text-white text-lg flex items-center gap-2">
              <ShieldAlert className="h-5 w-5 text-red-400" />
              <span>Active Screen Time Gateways</span>
            </h3>
            <p className="text-xs text-slate-400">
              These applications require a completed micro-lesson or Brain Coins to unlock.
            </p>
          </div>

          <Link
            href="/settings"
            className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 flex items-center gap-1"
          >
            <span>Manage Apps</span>
            <ChevronRight className="h-4 w-4" />
          </Link>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {state.blockedApps.map((app) => {
            const isUnlocked = app.unlockedUntil && app.unlockedUntil > now;
            const remainingMs = Math.max(0, (app.unlockedUntil || 0) - now);
            const remainingMin = Math.ceil(remainingMs / 60000);

            return (
              <div
                key={app.id}
                onClick={() => {
                  if (!isUnlocked) appActions.triggerInterceptModal(app);
                }}
                className={`group cursor-pointer rounded-2xl p-4 text-center transition-all border ${
                  isUnlocked
                    ? "border-emerald-500/40 bg-emerald-950/20 hover:bg-emerald-900/30"
                    : "border-white/10 bg-white/5 hover:border-red-500/40 hover:bg-red-500/10"
                }`}
              >
                <div
                  className="mx-auto mb-2 flex h-10 w-10 items-center justify-center rounded-xl font-bold text-white shadow-md text-sm"
                  style={{ backgroundColor: app.color }}
                >
                  {app.name.charAt(0)}
                </div>
                <div className="font-bold text-white text-xs truncate">{app.name}</div>
                
                {isUnlocked ? (
                  <div className="mt-1.5 flex items-center justify-center gap-1 text-[11px] font-bold text-emerald-400">
                    <LockOpen className="h-3 w-3" />
                    <span>{remainingMin}m left</span>
                  </div>
                ) : (
                  <div className="mt-1.5 flex items-center justify-center gap-1 text-[11px] font-semibold text-red-400">
                    <ShieldAlert className="h-3 w-3" />
                    <span>Locked</span>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Daily Missions & Quick Stats Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Daily Missions (2 cols) */}
        <div className="lg:col-span-2 glass-card rounded-3xl p-6 border border-white/10">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-white text-lg flex items-center gap-2">
              <Zap className="h-5 w-5 text-amber-400" />
              <span>Daily Focus Missions</span>
            </h3>
            <span className="text-xs text-slate-400">Resets in 11 hours</span>
          </div>

          <div className="space-y-3">
            {state.dailyMissions.map((mission) => (
              <div
                key={mission.id}
                className="flex items-center justify-between gap-4 rounded-2xl border border-white/5 bg-white/5 p-3.5 transition-all hover:bg-white/10"
              >
                <div className="flex items-center gap-3">
                  <div className={`flex h-9 w-9 items-center justify-center rounded-xl ${
                    mission.completed ? "bg-emerald-500/20 text-emerald-400" : "bg-white/10 text-slate-400"
                  }`}>
                    <CheckCircle2 className="h-5 w-5" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-white">{mission.title}</div>
                    <div className="text-[11px] text-slate-400">
                      Progress: {mission.current} / {mission.target}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="text-right text-[11px]">
                    <span className="font-bold text-amber-300 block">+{mission.rewardCoins} Coins</span>
                    <span className="text-indigo-300">+{mission.rewardXp} XP</span>
                  </div>

                  {mission.completed && !mission.claimed ? (
                    <button
                      onClick={() => appActions.claimMissionReward(mission.id)}
                      className="rounded-xl bg-emerald-500 px-3 py-1.5 text-xs font-bold text-white hover:bg-emerald-400 transition-all shadow-md animate-bounce"
                    >
                      Claim!
                    </button>
                  ) : mission.claimed ? (
                    <span className="text-xs font-semibold text-slate-500">Claimed</span>
                  ) : (
                    <span className="rounded-lg bg-slate-800 px-2 py-1 text-[11px] text-slate-400">In Progress</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Quickplay Arcade Card */}
        <div className="glass-card rounded-3xl p-6 border border-emerald-500/30 flex flex-col justify-between bg-gradient-to-br from-emerald-950/30 via-slate-900 to-[#0B0F1B]">
          <div>
            <div className="flex items-center gap-2 mb-2 text-emerald-400">
              <Gamepad2 className="h-5 w-5" />
              <span className="text-xs font-bold uppercase tracking-wider">Gamified Arcade</span>
            </div>
            <h4 className="text-xl font-black text-white mb-2">Knowledge Runner & AI Bosses</h4>
            <p className="text-xs text-slate-300 leading-relaxed mb-4">
              Solidify concepts in high-speed arcade games. Earn 2x coin multipliers for high scores and defeat the Dopamine Glitch Lord!
            </p>
          </div>

          <Link
            href="/games"
            className="flex items-center justify-center gap-2 rounded-2xl bg-emerald-600 p-3.5 text-xs font-bold text-white shadow-lg shadow-emerald-600/30 hover:bg-emerald-500 transition-all hover:scale-105"
          >
            <span>Play Arcade Games</span>
            <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </div>
    </div>
  );
}
