"use client";

import { useState, useEffect } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { QUIZ_QUESTIONS, INITIAL_TRACKS } from "@/lib/mockData";
import { useAppState, appActions } from "@/lib/store";
import { sounds } from "@/lib/soundEffects";
import { QuizQuestion, QuizGrade, QuizResult, MatchPairsQuestion, FillBlanksQuestion } from "@/types";
import { 
  HelpCircle, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  Zap, 
  Coins, 
  ArrowRight, 
  RotateCcw, 
  Gamepad2, 
  LockOpen,
  Sparkles,
  Trophy
} from "lucide-react";

export default function QuizEnginePage() {
  const params = useParams();
  const router = useRouter();
  const state = useAppState();

  const lessonId = (params.lessonId as string) || "ai-1";

  // Find questions
  const questions: QuizQuestion[] = QUIZ_QUESTIONS[lessonId] || QUIZ_QUESTIONS["ai-1"];

  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [selectedBool, setSelectedBool] = useState<boolean | null>(null);
  const [fillBlankSelectedWord, setFillBlankSelectedWord] = useState<string | null>(null);
  const [matchedPairs, setMatchedPairs] = useState<Record<string, string>>({});
  const [selectedLeftPair, setSelectedLeftPair] = useState<string | null>(null);

  const [isAnswered, setIsAnswered] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const [correctCount, setCorrectCount] = useState(0);
  const [quizFinished, setQuizFinished] = useState(false);
  const [timeRemaining, setTimeRemaining] = useState(25); // 25s per question

  const currentQ = questions[currentIndex];

  // Timer per question
  useEffect(() => {
    if (quizFinished || isAnswered) return;

    const timer = setInterval(() => {
      setTimeRemaining((prev) => {
        if (prev <= 1) {
          handleTimeout();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [currentIndex, isAnswered, quizFinished]);

  const handleTimeout = () => {
    setIsAnswered(true);
    setIsCorrect(false);
    sounds.playError();
  };

  const handleSelectMCQ = (index: number) => {
    if (isAnswered) return;
    setSelectedOption(index);
    setIsAnswered(true);

    if (currentQ.type === "multiple_choice") {
      const correct = index === currentQ.correctIndex;
      setIsCorrect(correct);
      if (correct) {
        sounds.playCorrect();
        setCorrectCount((prev) => prev + 1);
      } else {
        sounds.playError();
      }
    }
  };

  const handleSelectTrueFalse = (val: boolean) => {
    if (isAnswered) return;
    setSelectedBool(val);
    setIsAnswered(true);

    if (currentQ.type === "true_false") {
      const correct = val === currentQ.isTrue;
      setIsCorrect(correct);
      if (correct) {
        sounds.playCorrect();
        setCorrectCount((prev) => prev + 1);
      } else {
        sounds.playError();
      }
    }
  };

  const handleSelectFillBlank = (word: string) => {
    if (isAnswered) return;
    setFillBlankSelectedWord(word);
    setIsAnswered(true);

    if (currentQ.type === "fill_blanks") {
      const correct = word.toLowerCase() === currentQ.correctWord.toLowerCase();
      setIsCorrect(correct);
      if (correct) {
        sounds.playCorrect();
        setCorrectCount((prev) => prev + 1);
      } else {
        sounds.playError();
      }
    }
  };

  const handlePairClick = (side: "left" | "right", item: string) => {
    if (isAnswered || currentQ.type !== "match_pairs") return;
    sounds.playClick();

    if (side === "left") {
      setSelectedLeftPair(item);
    } else if (side === "right" && selectedLeftPair) {
      const updated = { ...matchedPairs, [selectedLeftPair]: item };
      setMatchedPairs(updated);
      setSelectedLeftPair(null);

      // Check if all pairs matched
      if (Object.keys(updated).length === currentQ.pairs.length) {
        setIsAnswered(true);
        // Verify
        const allCorrect = currentQ.pairs.every((p) => updated[p.left] === p.right);
        setIsCorrect(allCorrect);
        if (allCorrect) {
          sounds.playCorrect();
          setCorrectCount((prev) => prev + 1);
        } else {
          sounds.playError();
        }
      }
    }
  };

  const handleNextQuestion = () => {
    if (currentIndex + 1 < questions.length) {
      setCurrentIndex((prev) => prev + 1);
      setIsAnswered(false);
      setSelectedOption(null);
      setSelectedBool(null);
      setFillBlankSelectedWord(null);
      setMatchedPairs({});
      setSelectedLeftPair(null);
      setTimeRemaining(25);
    } else {
      // Calculate grade & finish
      finishQuiz();
    }
  };

  const finishQuiz = () => {
    const finalCorrect = correctCount + (isCorrect ? 0 : 0); // already updated
    const scorePct = Math.round((correctCount / questions.length) * 100);
    const passed = scorePct >= 70;

    let grade: QuizGrade = "Poor";
    if (scorePct >= 90) grade = "Excellent";
    else if (scorePct >= 70) grade = "Good";
    else if (scorePct >= 50) grade = "Average";

    const baseCoins = passed ? 60 : 15;
    const bonusMultiplier = scorePct === 100 ? 2 : 1;
    const finalCoins = baseCoins * bonusMultiplier;
    const finalXp = passed ? 100 * bonusMultiplier : 25;

    const result: QuizResult = {
      lessonId,
      totalQuestions: questions.length,
      correctAnswers: correctCount,
      scorePercentage: scorePct,
      grade,
      passed,
      xpEarned: finalXp,
      coinsEarned: finalCoins,
      timeSpentSeconds: 60,
      timestamp: new Date().toISOString(),
    };

    appActions.recordQuizResult(result);

    if (passed) {
      sounds.playLevelUp();
    } else {
      sounds.playError();
    }

    setQuizFinished(true);
  };

  const scorePct = Math.round((correctCount / questions.length) * 100);
  const passed = scorePct >= 70;

  let grade: QuizGrade = "Poor";
  if (scorePct >= 90) grade = "Excellent";
  else if (scorePct >= 70) grade = "Good";
  else if (scorePct >= 50) grade = "Average";

  return (
    <div className="max-w-3xl mx-auto space-y-6 animate-in fade-in duration-300">
      {/* Top Header */}
      <div className="flex items-center justify-between">
        <div>
          <span className="text-xs font-bold text-indigo-400 uppercase tracking-wider">
            STEP 4: Adaptive AI Assessment
          </span>
          <h1 className="text-2xl font-black text-white">Interactive Knowledge Evaluation</h1>
        </div>

        {!quizFinished && (
          <div className="flex items-center gap-2 rounded-full border border-indigo-500/30 bg-indigo-500/10 px-3.5 py-1 text-xs font-mono font-bold text-indigo-300">
            <Clock className="h-3.5 w-3.5 text-indigo-400" />
            <span>{timeRemaining}s</span>
          </div>
        )}
      </div>

      {/* Quiz Progress Bar */}
      {!quizFinished && (
        <div className="space-y-1.5">
          <div className="flex justify-between text-xs text-slate-400 font-semibold">
            <span>Question {currentIndex + 1} of {questions.length}</span>
            <span>Difficulty: <span className="text-emerald-400 font-bold uppercase">{currentQ.difficulty}</span></span>
          </div>
          <div className="h-2 w-full rounded-full bg-slate-800 overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-indigo-500 to-emerald-400 transition-all duration-300"
              style={{ width: `${((currentIndex + 1) / questions.length) * 100}%` }}
            />
          </div>
        </div>
      )}

      {/* Active Question Box */}
      {!quizFinished ? (
        <div className="glass-card rounded-3xl p-6 md:p-8 border border-white/10 space-y-6">
          {/* Question Prompt */}
          <div>
            <div className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
              Format: {currentQ.type.replace("_", " ")}
            </div>
            <h2 className="text-lg md:text-xl font-bold text-white leading-relaxed">
              {currentQ.prompt}
            </h2>
          </div>

          {/* Question Type 1: Multiple Choice */}
          {currentQ.type === "multiple_choice" && (
            <div className="space-y-3">
              {currentQ.options.map((option, idx) => {
                const isSelected = selectedOption === idx;
                const isThisCorrect = idx === currentQ.correctIndex;

                let btnStyle = "border-white/10 bg-white/5 hover:border-indigo-500/40 text-slate-200";
                if (isAnswered) {
                  if (isThisCorrect) {
                    btnStyle = "border-emerald-500 bg-emerald-500/20 text-emerald-200 font-bold";
                  } else if (isSelected) {
                    btnStyle = "border-red-500 bg-red-500/20 text-red-200 font-bold";
                  } else {
                    btnStyle = "opacity-40 border-white/5 bg-transparent";
                  }
                }

                return (
                  <button
                    key={idx}
                    disabled={isAnswered}
                    onClick={() => handleSelectMCQ(idx)}
                    className={`flex w-full items-center justify-between rounded-2xl border p-4 text-left text-xs md:text-sm transition-all ${btnStyle}`}
                  >
                    <div className="flex items-center gap-3">
                      <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-white/10 text-xs font-bold text-white">
                        {String.fromCharCode(65 + idx)}
                      </span>
                      <span>{option}</span>
                    </div>

                    {isAnswered && isThisCorrect && (
                      <CheckCircle2 className="h-5 w-5 text-emerald-400" />
                    )}
                    {isAnswered && isSelected && !isThisCorrect && (
                      <XCircle className="h-5 w-5 text-red-400" />
                    )}
                  </button>
                );
              })}
            </div>
          )}

          {/* Question Type 2: True / False */}
          {currentQ.type === "true_false" && (
            <div className="grid grid-cols-2 gap-4">
              {[true, false].map((val) => {
                const label = val ? "True" : "False";
                const isSelected = selectedBool === val;
                const isThisCorrect = val === currentQ.isTrue;

                let btnStyle = "border-white/10 bg-white/5 hover:border-indigo-500/40 text-slate-200";
                if (isAnswered) {
                  if (isThisCorrect) {
                    btnStyle = "border-emerald-500 bg-emerald-500/20 text-emerald-200 font-bold";
                  } else if (isSelected) {
                    btnStyle = "border-red-500 bg-red-500/20 text-red-200 font-bold";
                  } else {
                    btnStyle = "opacity-40 border-white/5 bg-transparent";
                  }
                }

                return (
                  <button
                    key={label}
                    disabled={isAnswered}
                    onClick={() => handleSelectTrueFalse(val)}
                    className={`rounded-2xl border p-6 text-center text-base font-bold transition-all ${btnStyle}`}
                  >
                    {label}
                  </button>
                );
              })}
            </div>
          )}

          {/* Question Type 3: Match Pairs */}
          {currentQ.type === "match_pairs" && (
            <div className="space-y-4">
              <p className="text-xs text-slate-400">
                Click an item on the left, then click its matching pair on the right:
              </p>
              <div className="grid grid-cols-2 gap-4">
                {/* Left column */}
                <div className="space-y-2">
                  {currentQ.pairs.map((p, i) => {
                    const isMatched = !!matchedPairs[p.left];
                    const isSelected = selectedLeftPair === p.left;
                    return (
                      <button
                        key={i}
                        disabled={isAnswered || isMatched}
                        onClick={() => handlePairClick("left", p.left)}
                        className={`w-full rounded-xl p-3 text-left text-xs font-semibold border transition-all ${
                          isMatched
                            ? "border-emerald-500/50 bg-emerald-950/30 text-emerald-300"
                            : isSelected
                            ? "border-indigo-500 bg-indigo-600/30 text-white"
                            : "border-white/10 bg-white/5 hover:border-white/20 text-slate-200"
                        }`}
                      >
                        {p.left}
                      </button>
                    );
                  })}
                </div>

                {/* Right column */}
                <div className="space-y-2">
                  {currentQ.pairs.map((p, i) => {
                    const isMatched = Object.values(matchedPairs).includes(p.right);
                    return (
                      <button
                        key={i}
                        disabled={isAnswered || isMatched}
                        onClick={() => handlePairClick("right", p.right)}
                        className={`w-full rounded-xl p-3 text-left text-xs font-semibold border transition-all ${
                          isMatched
                            ? "border-emerald-500/50 bg-emerald-950/30 text-emerald-300"
                            : "border-white/10 bg-white/5 hover:border-white/20 text-slate-200"
                        }`}
                      >
                        {p.right}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* Question Type 4: Fill in Blanks */}
          {currentQ.type === "fill_blanks" && (
            <div className="space-y-6">
              <div className="rounded-2xl border border-white/10 bg-white/5 p-5 text-sm md:text-base font-semibold text-white leading-relaxed text-center">
                {currentQ.sentenceWithBlank.replace(
                  "___",
                  fillBlankSelectedWord
                    ? `[ ${fillBlankSelectedWord} ]`
                    : "___________"
                )}
              </div>

              <div>
                <div className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                  Select Word From Word Bank:
                </div>
                <div className="flex flex-wrap gap-2.5">
                  {currentQ.wordBank.map((word) => {
                    const isSelected = fillBlankSelectedWord === word;
                    const isThisCorrect = word.toLowerCase() === currentQ.correctWord.toLowerCase();

                    let pillStyle = "border-white/10 bg-white/5 hover:border-indigo-500/40 text-slate-200";
                    if (isAnswered) {
                      if (isThisCorrect) {
                        pillStyle = "border-emerald-500 bg-emerald-500/20 text-emerald-200 font-bold";
                      } else if (isSelected) {
                        pillStyle = "border-red-500 bg-red-500/20 text-red-200 font-bold";
                      } else {
                        pillStyle = "opacity-40 border-white/5 bg-transparent";
                      }
                    }

                    return (
                      <button
                        key={word}
                        disabled={isAnswered}
                        onClick={() => handleSelectFillBlank(word)}
                        className={`rounded-xl border px-4 py-2 text-xs font-bold transition-all ${pillStyle}`}
                      >
                        {word}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* Feedback & Explanation Panel upon Answer */}
          {isAnswered && (
            <div className={`rounded-2xl p-4 border animate-in fade-in duration-200 ${
              isCorrect
                ? "border-emerald-500/30 bg-emerald-950/30 text-emerald-200"
                : "border-red-500/30 bg-red-950/30 text-red-200"
            }`}>
              <div className="flex items-center gap-2 font-bold text-sm mb-1">
                {isCorrect ? (
                  <>
                    <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                    <span>Brilliant! That is correct.</span>
                  </>
                ) : (
                  <>
                    <XCircle className="h-4 w-4 text-red-400" />
                    <span>Not quite right.</span>
                  </>
                )}
              </div>
              <p className="text-xs leading-relaxed opacity-90">
                {currentQ.explanation}
              </p>

              <div className="mt-4 flex justify-end">
                <button
                  onClick={handleNextQuestion}
                  className="flex items-center gap-2 rounded-xl bg-indigo-600 px-5 py-2 text-xs font-bold text-white hover:bg-indigo-500 transition-all hover:scale-105"
                >
                  <span>{currentIndex + 1 < questions.length ? "Next Question" : "View Results"}</span>
                  <ArrowRight className="h-4 w-4" />
                </button>
              </div>
            </div>
          )}
        </div>
      ) : (
        /* Quiz Finished Celebration Screen */
        <div className="glass-card rounded-3xl p-8 border border-white/10 text-center space-y-6">
          <div className="relative mx-auto flex h-24 w-24 items-center justify-center rounded-3xl bg-gradient-to-tr from-indigo-600 to-emerald-500 text-white shadow-xl shadow-indigo-600/30">
            <Trophy className="h-12 w-12 text-yellow-300 animate-bounce" />
          </div>

          <div>
            <div className="inline-flex items-center gap-1.5 rounded-full bg-emerald-500/20 border border-emerald-500/30 px-3.5 py-1 text-xs font-bold text-emerald-300 mb-2">
              <Sparkles className="h-3.5 w-3.5" />
              <span>Assessment Completed</span>
            </div>
            <h2 className="text-3xl font-black text-white">
              Grade: <span className={passed ? "text-emerald-400" : "text-amber-400"}>{grade}</span> ({scorePct}%)
            </h2>
            <p className="text-xs md:text-sm text-slate-300 max-w-md mx-auto mt-2 leading-relaxed">
              {passed
                ? "Outstanding work! You met the minimum 70% threshold and earned your screen time pass."
                : "You were just under the 70% threshold. Try a quick revision or replay the quiz to unlock full rewards."}
            </p>
          </div>

          {/* Reward Badges */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 max-w-lg mx-auto text-left text-xs">
            <div className="glass-card rounded-2xl p-3 border border-white/5">
              <span className="text-[11px] text-slate-400 block">Score</span>
              <span className="font-bold text-white text-base">{correctCount} / {questions.length}</span>
            </div>
            <div className="glass-card rounded-2xl p-3 border border-white/5">
              <span className="text-[11px] text-slate-400 block">Status</span>
              <span className={`font-bold text-base ${passed ? "text-emerald-400" : "text-rose-400"}`}>
                {passed ? "PASSED" : "RETRY"}
              </span>
            </div>
            <div className="glass-card rounded-2xl p-3 border border-white/5">
              <span className="text-[11px] text-slate-400 block">Brain Coins</span>
              <span className="font-bold text-amber-400 text-base">+{passed ? (scorePct === 100 ? 120 : 60) : 15}</span>
            </div>
            <div className="glass-card rounded-2xl p-3 border border-white/5">
              <span className="text-[11px] text-slate-400 block">Pet XP</span>
              <span className="font-bold text-indigo-400 text-base">+{passed ? (scorePct === 100 ? 200 : 100) : 25}</span>
            </div>
          </div>

          {/* Next Steps: Launch Mini-Game or App Unlock */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-4 border-t border-white/10 max-w-md mx-auto">
            <Link
              href="/games"
              className="flex w-full sm:w-auto items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-500 px-6 py-3.5 text-xs font-bold text-white shadow-lg shadow-emerald-600/30 hover:opacity-95 transition-all hover:scale-105"
            >
              <Gamepad2 className="h-4 w-4" />
              <span>Step 5: Play Mini-Game</span>
            </Link>

            <Link
              href="/rewards"
              className="flex w-full sm:w-auto items-center justify-center gap-2 rounded-2xl border border-indigo-500/40 bg-indigo-600/20 px-6 py-3.5 text-xs font-bold text-indigo-200 hover:bg-indigo-600/40 transition-all"
            >
              <LockOpen className="h-4 w-4" />
              <span>Step 7: Unlock Apps</span>
            </Link>
          </div>
        </div>
      )}
    </div>
  );
}
