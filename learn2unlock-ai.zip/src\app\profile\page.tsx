"use client";

import { useAppState } from "@/lib/store";
import { 
  User, 
  Flame, 
  Coins, 
  Zap, 
  Award, 
  Clock, 
  ShieldCheck, 
  CheckCircle2, 
  Calendar,
  Sparkles
} from "lucide-react";
import Link from "next/link";

export default function ProfilePage() {
  const state = useAppState();
  const pet = state.pet;

  const petEmoji = 
    pet.type === "owl" ? "🦉" :
    pet.type === "fox" ? "🦊" : "🤖";

  return (
    <div className="space-y-8 animate-in fade-in duration-300 max-w-4xl">
      {/* Header Profile Card */}
      <div className="glass-card rounded-3xl p-6 md:p-8 border border-white/10 flex flex-col md:flex-row items-center gap-6 text-center md:text-left bg-gradient-to-r from-indigo-950/30 via-slate-900 to-[#0B0F1B]">
        <img
          src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=160&auto=format&fit=crop&q=80"
          alt="Avatar"
          className="h-24 w-24 rounded-full border-4 border-indigo-500/50 object-cover shadow-xl"
        />

        <div className="flex-1 space-y-1">
          <div className="flex flex-wrap items-center justify-center md:justify-start gap-2">
            <h1 className="text-2xl font-black text-white">Alex Vance</h1>
            <span className="rounded-full bg-emerald-500/20 border border-emerald-500/30 px-2.5 py-0.5 text-[11px] font-bold text-emerald-300">
              Rank #4 Global
            </span>
          </div>
          <p className="text-xs text-slate-400">
            Digital Wellbeing Scholar • Joined October 2026
          </p>
          <div className="flex flex-wrap items-center justify-center md:justify-start gap-4 pt-3 text-xs font-semibold">
            <span className="text-orange-400 flex items-center gap-1">
              <Flame className="h-4 w-4 fill-orange-400" />
              {state.streak} Days Streak
            </span>
            <span className="text-amber-400 flex items-center gap-1">
              <Coins className="h-4 w-4" />
              {state.coins} Brain Coins
            </span>
            <span className="text-indigo-300 flex items-center gap-1">
              <Zap className="h-4 w-4" />
              {state.xp} Total XP
            </span>
          </div>
        </div>

        <Link
          href="/settings"
          className="rounded-xl border border-white/10 bg-white/5 px-4 py-2 text-xs font-bold text-slate-300 hover:bg-white/10 transition-colors"
        >
          Edit Profile
        </Link>
      </div>

      {/* Focus Companion Showcase */}
      <div className="glass-card rounded-3xl p-6 border border-indigo-500/30">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <span className="text-xl">{petEmoji}</span>
            <h3 className="font-bold text-white text-base">Active Companion: {pet.name}</h3>
          </div>
          <Link href="/pet" className="text-xs font-bold text-indigo-400 hover:underline">
            View Evolution Tree →
          </Link>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
          <div className="rounded-2xl border border-white/5 bg-white/5 p-3">
            <span className="text-slate-400 block text-[11px]">Level & Stage</span>
            <span className="font-bold text-white text-sm">Level {pet.level} (Stage {pet.stage})</span>
          </div>
          <div className="rounded-2xl border border-white/5 bg-white/5 p-3">
            <span className="text-slate-400 block text-[11px]">Companion Mood</span>
            <span className="font-bold text-emerald-400 text-sm">{pet.mood}</span>
          </div>
          <div className="rounded-2xl border border-white/5 bg-white/5 p-3">
            <span className="text-slate-400 block text-[11px]">Equipped Relic</span>
            <span className="font-bold text-indigo-300 text-sm truncate">{pet.equippedAccessory}</span>
          </div>
          <div className="rounded-2xl border border-white/5 bg-white/5 p-3">
            <span className="text-slate-400 block text-[11px]">Next Evolution</span>
            <span className="font-bold text-amber-400 text-sm">{pet.nextLevelXp - pet.currentXp} XP Needed</span>
          </div>
        </div>
      </div>

      {/* Learning Achievements Showcase */}
      <div className="glass-card rounded-3xl p-6 border border-white/10 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-bold text-white text-base flex items-center gap-2">
            <Award className="h-5 w-5 text-yellow-400" />
            <span>Unlocked Milestone Badges</span>
          </h3>
          <Link href="/achievements" className="text-xs font-bold text-indigo-400 hover:underline">
            View All Achievements →
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {state.achievements.filter((a) => a.unlocked).map((ach) => (
            <div key={ach.id} className="flex items-center gap-3 rounded-2xl border border-white/5 bg-white/5 p-3">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-yellow-500/20 text-yellow-400">
                <Award className="h-5 w-5" />
              </div>
              <div>
                <div className="font-bold text-white text-xs">{ach.title}</div>
                <div className="text-[11px] text-slate-400">{ach.description}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
