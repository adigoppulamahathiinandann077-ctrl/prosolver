"use client";

import { useAppState, appActions } from "@/lib/store";
import { sounds } from "@/lib/soundEffects";
import { 
  Award, 
  Sparkles, 
  Flame, 
  Coins, 
  Zap, 
  Clock, 
  ShieldAlert, 
  Unlock, 
  Lock,
  CheckCircle2
} from "lucide-react";

export default function AchievementsPage() {
  const state = useAppState();

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case "Flame": return <Flame className="h-6 w-6 text-orange-400" />;
      case "Award": return <Award className="h-6 w-6 text-yellow-400" />;
      case "ShieldAlert": return <ShieldAlert className="h-6 w-6 text-red-400" />;
      case "Unlock": return <Unlock className="h-6 w-6 text-emerald-400" />;
      case "Clock": return <Clock className="h-6 w-6 text-indigo-400" />;
      default: return <Sparkles className="h-6 w-6 text-indigo-400" />;
    }
  };

  const unlockedCount = state.achievements.filter((a) => a.unlocked).length;

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-yellow-400 text-xs font-bold uppercase tracking-wider mb-1">
            <Award className="h-4 w-4" />
            <span>Core Feature 5: Gamified Milestone Showcase</span>
          </div>
          <h1 className="text-3xl font-black text-white tracking-tight">Achievements</h1>
          <p className="text-sm text-slate-400 mt-1">
            Unlock achievements through learning habits and screen time defense to earn badges and massive coin bonuses.
          </p>
        </div>

        <div className="rounded-2xl border border-yellow-500/30 bg-yellow-500/10 px-5 py-3 text-right">
          <div className="text-[10px] font-bold uppercase tracking-wider text-yellow-400">Total Unlocked</div>
          <div className="text-xl font-black text-white">
            {unlockedCount} / {state.achievements.length} Badges
          </div>
        </div>
      </div>

      {/* Achievements Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {state.achievements.map((ach) => {
          const isUnlocked = ach.unlocked;
          const progressPct = Math.min(100, Math.round((ach.progress / ach.maxProgress) * 100));

          return (
            <div
              key={ach.id}
              className={`glass-card rounded-3xl p-6 border transition-all flex flex-col justify-between ${
                isUnlocked
                  ? "border-yellow-500/40 bg-gradient-to-br from-yellow-950/20 via-slate-900 to-[#0B0F1B] shadow-lg shadow-yellow-950/20"
                  : "border-white/10 bg-white/5 opacity-70"
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-4">
                  <div className={`flex h-12 w-12 items-center justify-center rounded-2xl border ${
                    isUnlocked
                      ? "border-yellow-500/50 bg-yellow-500/20 shadow-md"
                      : "border-white/10 bg-white/5"
                  }`}>
                    {isUnlocked ? getIcon(ach.icon) : <Lock className="h-6 w-6 text-slate-500" />}
                  </div>

                  <span className={`rounded-full px-2.5 py-0.5 text-[10px] font-bold ${
                    isUnlocked
                      ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
                      : "bg-slate-800 text-slate-400"
                  }`}>
                    {isUnlocked ? "COMPLETED" : "LOCKED"}
                  </span>
                </div>

                <h3 className="font-bold text-white text-base mb-1.5">{ach.title}</h3>
                <p className="text-xs text-slate-300 leading-relaxed mb-4">
                  {ach.description}
                </p>
              </div>

              {/* Progress Bar & Rewards */}
              <div className="space-y-3 pt-4 border-t border-white/5">
                <div>
                  <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                    <span>Progress</span>
                    <span className="font-mono text-white font-semibold">
                      {ach.progress} / {ach.maxProgress}
                    </span>
                  </div>
                  <div className="h-1.5 w-full rounded-full bg-slate-800 overflow-hidden">
                    <div 
                      className={`h-full transition-all duration-500 ${
                        isUnlocked ? "bg-emerald-400" : "bg-indigo-500"
                      }`}
                      style={{ width: `${progressPct}%` }}
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs font-semibold text-slate-400 pt-1">
                  <span className="text-amber-400 flex items-center gap-1">
                    <Coins className="h-3.5 w-3.5" />
                    +{ach.rewardCoins} Coins
                  </span>
                  <span className="text-indigo-400 flex items-center gap-1">
                    <Zap className="h-3.5 w-3.5" />
                    +{ach.rewardXp} XP
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
