export type Category = 
  | "Technology"
  | "Programming"
  | "Artificial Intelligence"
  | "Productivity"
  | "Finance"
  | "Business"
  | "Language Learning"
  | "Science"
  | "Engineering"
  | "Career Development";

export interface Lesson {
  id: string;
  trackId: string;
  title: string;
  category: Category;
  durationMinutes: number;
  description: string;
  videoUrl?: string;
  xpReward: number;
  coinsReward: number;
  summary: string;
  keyPoints: string[];
  aiNotes: string[];
  revisionCards: { front: string; back: string }[];
  difficulty: "Beginner" | "Intermediate" | "Advanced";
  completed?: boolean;
}

export interface Track {
  id: string;
  title: string;
  category: Category;
  description: string;
  icon: string;
  gradient: string;
  totalLessons: number;
  completedLessons: number;
  lessons: Lesson[];
}

export type QuestionType = "multiple_choice" | "true_false" | "match_pairs" | "fill_blanks";

export interface BaseQuestion {
  id: string;
  lessonId: string;
  type: QuestionType;
  prompt: string;
  explanation: string;
  difficulty: "easy" | "medium" | "hard";
}

export interface MultipleChoiceQuestion extends BaseQuestion {
  type: "multiple_choice";
  options: string[];
  correctIndex: number;
}

export interface TrueFalseQuestion extends BaseQuestion {
  type: "true_false";
  isTrue: boolean;
}

export interface MatchPairsQuestion extends BaseQuestion {
  type: "match_pairs";
  pairs: { left: string; right: string }[];
}

export interface FillBlanksQuestion extends BaseQuestion {
  type: "fill_blanks";
  sentenceWithBlank: string; // e.g. "Next.js uses ___ for optimized client-side routing."
  correctWord: string;
  wordBank: string[];
}

export type QuizQuestion = 
  | MultipleChoiceQuestion 
  | TrueFalseQuestion 
  | MatchPairsQuestion 
  | FillBlanksQuestion;

export type QuizGrade = "Poor" | "Average" | "Good" | "Excellent";

export interface QuizResult {
  lessonId: string;
  totalQuestions: number;
  correctAnswers: number;
  scorePercentage: number;
  grade: QuizGrade;
  passed: boolean; // >= 70%
  xpEarned: number;
  coinsEarned: number;
  timeSpentSeconds: number;
  timestamp: string;
}

export type PetType = "owl" | "fox" | "robot";

export interface PetEvolutionStage {
  stage: number; // 1, 2, 3, 4
  name: string;
  title: string;
  minLevel: number;
  visualIcon: string;
  description: string;
  specialPerk: string;
}

export interface FocusPet {
  type: PetType;
  name: string;
  level: number;
  currentXp: number;
  nextLevelXp: number;
  energy: number; // 0 - 100
  happiness: number; // 0 - 100
  stage: number; // 1 to 4
  mood: "Ecstatic" | "Energized" | "Content" | "Tired" | "Sleeping";
  equippedAccessory?: string;
  lastFedTimestamp: string;
}

export interface BlockedApp {
  id: string;
  name: string;
  icon: string;
  color: string;
  category: "Social" | "Entertainment" | "Gaming" | "Shorts";
  isBlocked: boolean;
  unlockedUntil: number | null; // epoch timestamp in ms, or null if locked
  totalBlocksCount: number;
  timeSavedMinutes: number;
}

export interface DailyMission {
  id: string;
  title: string;
  target: number;
  current: number;
  rewardCoins: number;
  rewardXp: number;
  completed: boolean;
  claimed: boolean;
  icon: string;
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  category: "streaks" | "learning" | "quizzes" | "games" | "mastery";
  icon: string;
  rewardCoins: number;
  rewardXp: number;
  unlocked: boolean;
  progress: number;
  maxProgress: number;
  unlockedAt?: string;
}

export interface SkillNode {
  id: string;
  title: string;
  trackId: string;
  description: string;
  level: number;
  tier: number; // Row in the tree
  dependencies: string[]; // Node IDs required before unlocking
  status: "locked" | "available" | "completed";
  starsEarned: number; // 0 to 3
  icon: string;
}

export interface LeaderboardUser {
  id: string;
  rank: number;
  name: string;
  avatar: string;
  petType: PetType;
  petStage: number;
  xp: number;
  coins: number;
  streak: number;
  lessonsCompleted: number;
  isCurrentUser?: boolean;
}

export interface ProductivityDayStats {
  day: string;
  hoursSaved: number;
  lessonsDone: number;
  focusScore: number;
  blocksCount: number;
}
