import { Track, Lesson, QuizQuestion, FocusPet, BlockedApp, DailyMission, Achievement, SkillNode, LeaderboardUser, ProductivityDayStats } from "@/types";

export const INITIAL_PET: FocusPet = {
  type: "owl",
  name: "Archie the Cyber Owl",
  level: 4,
  currentXp: 380,
  nextLevelXp: 500,
  energy: 88,
  happiness: 92,
  stage: 2, // Cyber Apprentice
  mood: "Energized",
  equippedAccessory: "Holographic Monocle",
  lastFedTimestamp: new Date().toISOString(),
};

export const BLOCKED_APPS_DEFAULT: BlockedApp[] = [
  {
    id: "instagram",
    name: "Instagram",
    icon: "Instagram",
    color: "#E1306C",
    category: "Social",
    isBlocked: true,
    unlockedUntil: null,
    totalBlocksCount: 42,
    timeSavedMinutes: 380,
  },
  {
    id: "tiktok",
    name: "TikTok",
    icon: "Video",
    color: "#00F2FE",
    category: "Shorts",
    isBlocked: true,
    unlockedUntil: null,
    totalBlocksCount: 65,
    timeSavedMinutes: 520,
  },
  {
    id: "youtube-shorts",
    name: "YouTube Shorts",
    icon: "Youtube",
    color: "#FF0000",
    category: "Shorts",
    isBlocked: true,
    unlockedUntil: null,
    totalBlocksCount: 31,
    timeSavedMinutes: 240,
  },
  {
    id: "netflix",
    name: "Netflix",
    icon: "Film",
    color: "#E50914",
    category: "Entertainment",
    isBlocked: true,
    unlockedUntil: null,
    totalBlocksCount: 14,
    timeSavedMinutes: 420,
  },
  {
    id: "facebook",
    name: "Facebook",
    icon: "Facebook",
    color: "#1877F2",
    category: "Social",
    isBlocked: true,
    unlockedUntil: null,
    totalBlocksCount: 19,
    timeSavedMinutes: 150,
  },
  {
    id: "gaming",
    name: "Gaming Apps",
    icon: "Gamepad2",
    color: "#8B5CF6",
    category: "Gaming",
    isBlocked: true,
    unlockedUntil: null,
    totalBlocksCount: 28,
    timeSavedMinutes: 310,
  },
];

export const INITIAL_TRACKS: Track[] = [
  {
    id: "track-ai",
    title: "Artificial Intelligence Foundations",
    category: "Artificial Intelligence",
    description: "Master Large Language Models, Transformer architectures, and modern prompt engineering in bite-sized chunks.",
    icon: "Cpu",
    gradient: "from-blue-600 to-indigo-800",
    totalLessons: 4,
    completedLessons: 2,
    lessons: [
      {
        id: "ai-1",
        trackId: "track-ai",
        title: "How Transformer Neural Networks Work",
        category: "Artificial Intelligence",
        durationMinutes: 3,
        description: "Demystify Self-Attention and how modern generative AI models process natural language simultaneously.",
        xpReward: 50,
        coinsReward: 35,
        difficulty: "Beginner",
        completed: true,
        summary: "Transformers process words in parallel through multi-head self-attention mechanisms, capturing long-range contextual relationships far better than older sequential RNNs.",
        keyPoints: [
          "Self-attention calculates token similarity scores across the entire sequence at once.",
          "Positional encodings inject token order without requiring sequential computation loops.",
          "Multi-head attention lets models attend to syntax, semantics, and style concurrently.",
          "Feed-forward layers and layer normalization stabilize deep transformer backbones."
        ],
        aiNotes: [
          "The revolutionary paper 'Attention Is All You Need' was published by Google researchers in 2017.",
          "Unlike Recurrent Neural Networks (RNNs) which forgot earlier tokens, Transformers maintain direct mathematical paths between all words.",
          "Key formula: Attention(Q, K, V) = softmax(Q * K^T / sqrt(d_k)) * V."
        ],
        revisionCards: [
          { front: "What does Q, K, and V stand for in Self-Attention?", back: "Queries, Keys, and Values (inspired by database retrieval systems)." },
          { front: "Why do Transformers scale better on GPUs than RNNs?", back: "They process all tokens concurrently rather than one by one in time steps." },
          { front: "What prevents attention scores from vanishing or exploding?", back: "Dividing by the square root of the key dimension (sqrt(d_k))." }
        ]
      },
      {
        id: "ai-2",
        trackId: "track-ai",
        title: "Prompt Engineering & Few-Shot In-Context Learning",
        category: "Artificial Intelligence",
        durationMinutes: 4,
        description: "Learn how to steer LLMs with zero-shot, few-shot prompting, chain-of-thought, and system framing.",
        xpReward: 60,
        coinsReward: 40,
        difficulty: "Intermediate",
        completed: true,
        summary: "Prompt engineering is the art and science of formulating optimal inputs that trigger high-probability generative trajectories in language models.",
        keyPoints: [
          "Zero-shot asks directly without examples; Few-shot provides 2-5 clear input-output demonstrations.",
          "Chain-of-Thought (CoT) prompts step-by-step reasoning, drastically reducing arithmetic and logic hallucinations.",
          "Role and persona conditioning primes the model's vocabulary and latent domain representations.",
          "Structured output formatting (JSON schemas, XML delimiters) prevents unstructured drift."
        ],
        aiNotes: [
          "Giving an explicit thought step ('Think step by step before outputting') generates intermediate reasoning tokens that act as scratchpad memory.",
          "System instructions anchor behavior across turns better than user messages.",
          "Hallucination rate drops by up to 60% when grounding with retrieval (RAG)."
        ],
        revisionCards: [
          { front: "What is Chain-of-Thought prompting?", back: "Instructing the model to write out reasoning steps before giving the final answer." },
          { front: "What is Few-Shot prompting?", back: "Providing a few target examples in the prompt to condition the model's output pattern." }
        ]
      },
      {
        id: "ai-3",
        trackId: "track-ai",
        title: "RAG: Retrieval-Augmented Generation Architecture",
        category: "Artificial Intelligence",
        durationMinutes: 4,
        description: "How vector embeddings, vector databases, and semantic similarity eliminate LLM hallucinations.",
        xpReward: 75,
        coinsReward: 50,
        difficulty: "Intermediate",
        completed: false,
        summary: "RAG connects LLMs to external dynamic knowledge bases using high-dimensional vector embeddings, cosine similarity search, and dynamic context injection.",
        keyPoints: [
          "Embedding models map text chunks into 768 to 3072-dimensional semantic vector spaces.",
          "Vector indexes (HNSW, IVFFlat) perform approximate nearest neighbor search in milliseconds.",
          "Retrieved document chunks are injected directly into the LLM context prompt as grounded facts.",
          "Re-ranking algorithms order search results to maximize context relevance."
        ],
        aiNotes: [
          "RAG costs orders of magnitude less than fine-tuning while keeping company data private.",
          "Chunking strategy (chunk size and overlap) is the #1 lever for retrieval quality.",
          "Hybrid search combines dense vector similarity with sparse BM25 keyword matching."
        ],
        revisionCards: [
          { front: "What is Cosine Similarity?", back: "A metric measuring the angle between two vectors, indicating semantic closeness from -1 to 1." },
          { front: "Why is RAG preferred over fine-tuning for private knowledge?", back: "Immediate updates without retraining, lower compute cost, and provable source citations." }
        ]
      },
      {
        id: "ai-4",
        trackId: "track-ai",
        title: "Autonomous AI Agents & Tool Calling",
        category: "Artificial Intelligence",
        durationMinutes: 5,
        description: "Explore the ReAct framework, function calling, planning loops, and multi-agent coordination.",
        xpReward: 90,
        coinsReward: 60,
        difficulty: "Advanced",
        completed: false,
        summary: "Autonomous agents combine LLM reasoning with tool execution, memory buffers, and recursive planning loops to solve multi-step real-world problems.",
        keyPoints: [
          "ReAct loop alternates between Reasoning (Thought) and Action (Tool Call + Observation).",
          "Tool schemas define typed arguments using JSON Schema that models emit reliably.",
          "Episodic memory and working memory allow agents to preserve state across complex tasks.",
          "Guardrails and reflection steps verify tool outputs before irreversible actions occur."
        ],
        aiNotes: [
          "Agents transform LLMs from passive text predictors into interactive problem-solving engines.",
          "Subagent delegation distributes large workloads into specialized worker roles."
        ],
        revisionCards: [
          { front: "What does ReAct stand for in AI agents?", back: "Reasoning and Acting loop." },
          { front: "How do LLMs communicate with tools?", back: "By emitting structured JSON arguments matching a predefined function schema." }
        ]
      }
    ]
  },
  {
    id: "track-prog",
    title: "High-Performance Programming & Architecture",
    category: "Programming",
    description: "Modern JavaScript, TypeScript generics, async patterns, and scalable frontend engineering.",
    icon: "Code2",
    gradient: "from-emerald-600 to-teal-800",
    totalLessons: 3,
    completedLessons: 1,
    lessons: [
      {
        id: "prog-1",
        trackId: "track-prog",
        title: "TypeScript Generics & Advanced Type Gymnastics",
        category: "Programming",
        durationMinutes: 4,
        description: "Unlock conditional types, keyof, infer, and utility types for bulletproof codebases.",
        xpReward: 60,
        coinsReward: 40,
        difficulty: "Intermediate",
        completed: true,
        summary: "TypeScript generics enable reusable, strictly typed functions and components that dynamically adapt to callers without sacrificing type safety.",
        keyPoints: [
          "Generic type variables (e.g. `<T>`) parameterize data structures across calls.",
          "`keyof` extracts object keys as a union of string literals.",
          "Conditional types (`T extends U ? X : Y`) compute types based on relational tests.",
          "The `infer` keyword extracts nested types from existing function signatures or promises."
        ],
        aiNotes: [
          "Generics disappear completely at compile time; they cost zero runtime overhead.",
          "Use constraints (`<T extends Record<string, unknown>>`) to guarantee properties exist."
        ],
        revisionCards: [
          { front: "What does `ReturnType<T>` do in TypeScript?", back: "Extracts the return type of a function type T using conditional types and `infer`." },
          { front: "What is a generic constraint?", back: "Restricting a generic type parameter using `extends`, e.g. `<T extends { id: string }>`." }
        ]
      },
      {
        id: "prog-2",
        trackId: "track-prog",
        title: "The JavaScript Event Loop, Microtasks & Macrotasks",
        category: "Programming",
        durationMinutes: 3,
        description: "Master call stacks, web APIs, Promise microtask queues, and requestAnimationFrame.",
        xpReward: 55,
        coinsReward: 35,
        difficulty: "Intermediate",
        completed: false,
        summary: "JavaScript's single-threaded runtime relies on the event loop to prioritize execution between synchronous stack calls, Promise microtasks, and timer macrotasks.",
        keyPoints: [
          "The Call Stack executes synchronous JavaScript frames until completely empty.",
          "Microtasks (Promises, queueMicrotask) execute immediately after the stack empties before any rendering.",
          "Macrotasks (setTimeout, setInterval, I/O) execute one by one after microtask queues drain.",
          "requestAnimationFrame runs right before browser repainting for 60fps smoothness."
        ],
        aiNotes: [
          "A runaway microtask loop (e.g., recursive Promise resolution) completely freezes the browser window.",
          "Node.js has process.nextTick which has higher priority than standard microtasks."
        ],
        revisionCards: [
          { front: "Which runs first: setTimeout(fn, 0) or Promise.resolve().then(fn)?", back: "Promise.resolve().then(fn), because microtasks run before macrotasks." },
          { front: "What happens if a microtask keeps queuing another microtask?", back: "The call stack never allows rendering or macrotasks, leading to thread starvation." }
        ]
      },
      {
        id: "prog-3",
        trackId: "track-prog",
        title: "React 19 Server Components & Concurrent Rendering",
        category: "Programming",
        durationMinutes: 5,
        description: "Understand React Server Components (RSC), hydration boundaries, and streaming SSR.",
        xpReward: 80,
        coinsReward: 50,
        difficulty: "Advanced",
        completed: false,
        summary: "React Server Components run exclusively on the server, sending pre-rendered virtual DOM trees directly to the client without adding to client JavaScript bundle sizes.",
        keyPoints: [
          "RSC has zero impact on client bundle size and direct secure access to server databases.",
          "Client Components (`'use client'`) handle interactive state, hooks, and browser events.",
          "Streaming SSR transmits HTML chunks via HTTP streaming as data resolves.",
          "`Suspense` boundaries allow progressive loading without blank page flickers."
        ],
        aiNotes: [
          "Data fetching in RSC does not need useEffect or client-side caching libraries.",
          "Server Actions allow type-safe mutations with automatic revalidation."
        ],
        revisionCards: [
          { front: "Can React Server Components use `useState` or `useEffect`?", back: "No. Server components execute only on the server and cannot hold client lifecycle state." },
          { front: "What does the `'use client'` directive actually mean?", back: "It marks the boundary where the component and its children are bundled for client-side execution." }
        ]
      }
    ]
  },
  {
    id: "track-prod",
    title: "Deep Work & Dopamine Mastery",
    category: "Productivity",
    description: "Reverse screen addiction, rewire dopamine pathways, and achieve effortless deep focus.",
    icon: "Zap",
    gradient: "from-amber-500 to-orange-700",
    totalLessons: 3,
    completedLessons: 2,
    lessons: [
      {
        id: "prod-1",
        trackId: "track-prod",
        title: "The Neurobiology of Screen Addiction",
        category: "Productivity",
        durationMinutes: 3,
        description: "How variable reward schedules in social media hijack your nucleus accumbens and prefrontal cortex.",
        xpReward: 50,
        coinsReward: 35,
        difficulty: "Beginner",
        completed: true,
        summary: "Short-form video apps exploit intermittent variable rewards—the exact mechanism found in slot machines—to keep dopamine levels fluctuating in anticipation rather than satisfaction.",
        keyPoints: [
          "Dopamine is the neurotransmitter of anticipation, desire, and seeking, not pleasure itself.",
          "Variable ratio schedules create the most compulsive, addiction-resistant behavioral loops.",
          "Prolonged hyper-stimulation down-regulates D2 dopamine receptors, causing boredom and brain fog.",
          "Friction-based interventions (like Learn2Unlock's learning gate) interrupt autopilot scrolling habits."
        ],
        aiNotes: [
          "The average smartphone user touches their phone over 2,600 times a day.",
          "Introducing a 3-minute cognitive barrier resets impulsive dopamine craving by 78%."
        ],
        revisionCards: [
          { front: "What psychological schedule powers TikTok and Instagram Reels?", back: "Variable ratio reinforcement schedule (unpredictable rewards like a slot machine)." },
          { front: "What is dopamine's true biological function?", back: "Anticipation of reward and motivation to seek, rather than the feeling of enjoyment." }
        ]
      },
      {
        id: "prod-2",
        trackId: "track-prod",
        title: "Deep Work & The 90-Minute Ultradian Rhythm",
        category: "Productivity",
        durationMinutes: 4,
        description: "Align your calendar with human biological cycles for effortless 4-hour cognitive output.",
        xpReward: 65,
        coinsReward: 45,
        difficulty: "Intermediate",
        completed: true,
        summary: "Human attention naturally peaks and dips in 90-minute ultradian cycles. Structuring high-cognition deep work in sync with this cycle eliminates mental fatigue.",
        keyPoints: [
          "Ultradian rhythms regulate our autonomic nervous system throughout the wakeful day.",
          "The ideal focus block is 75-90 minutes of distraction-free single-tasking.",
          "A mandatory 15-20 minute physiological break restores glucose and neural reserves.",
          "Attention residue: context switching to email or social media reduces IQ by up to 10 points for 20 minutes."
        ],
        aiNotes: [
          "Cal Newport's 'Deep Work' framework proves high-value creation requires zero context switching.",
          "Multitasking is a myth; the brain rapidly toggles between tasks at enormous cognitive cost."
        ],
        revisionCards: [
          { front: "What is 'Attention Residue'?", back: "The cognitive lag when switching tasks, where part of your focus remains stuck on the previous task." },
          { front: "How long is a natural human ultradian focus cycle?", back: "Approximately 90 minutes, followed by a 15-20 minute recovery phase." }
        ]
      },
      {
        id: "prod-3",
        trackId: "track-prod",
        title: "Friction Engineering: Designing Your Environment",
        category: "Productivity",
        durationMinutes: 3,
        description: "How increasing 20 seconds of friction kills bad habits while decreasing friction builds empires.",
        xpReward: 55,
        coinsReward: 35,
        difficulty: "Beginner",
        completed: false,
        summary: "Willpower is a depleting biological battery. Environmental friction—making distracting apps hard to access and learning instant—is the true secret to lifelong focus.",
        keyPoints: [
          "The 20-Second Rule: Adding even a slight 20-second delay to a habit cuts compliance by over 80%.",
          "Default bias: Humans overwhelmingly choose the path of least resistance.",
          "Commitment devices: Pre-committing to learning gates eliminates decision fatigue.",
          "Dopamine fasting & replacement: Replacing mindless scrolling with active micro-learning."
        ],
        aiNotes: [
          "Learn2Unlock AI acts as an automated environmental commitment device.",
          "Behavior = Motivation + Ability + Prompt (BJ Fogg's Behavior Model)."
        ],
        revisionCards: [
          { front: "What is BJ Fogg's Behavior formula?", back: "B = MAP (Behavior happens when Motivation, Ability, and Prompt converge)." },
          { front: "What is a commitment device?", back: "A choice made in the present that locks you into a desired future behavior." }
        ]
      }
    ]
  },
  {
    id: "track-fin",
    title: "Financial Mastery & Compound Wealth",
    category: "Finance",
    description: "The mechanics of compound interest, index investing, unit economics, and building financial freedom.",
    icon: "TrendingUp",
    gradient: "from-amber-600 to-yellow-700",
    totalLessons: 3,
    completedLessons: 0,
    lessons: [
      {
        id: "fin-1",
        trackId: "track-fin",
        title: "The Math of Exponential Compound Interest",
        category: "Finance",
        durationMinutes: 3,
        description: "Why Albert Einstein called compound interest the eighth wonder of the world.",
        xpReward: 50,
        coinsReward: 35,
        difficulty: "Beginner",
        completed: false,
        summary: "Compound interest calculates return on both your initial principal and previously accumulated interest, transforming linear savings into hockey-stick exponential wealth over time.",
        keyPoints: [
          "Formula: A = P * (1 + r/n)^(nt), where time (t) is in the exponent.",
          "The Rule of 72: Divide 72 by annual interest rate to find years required to double your money.",
          "Starting 10 years earlier yields up to 3x more wealth than doubling your monthly contributions later.",
          "Inflation acts as negative compound interest on uninvested cash."
        ],
        aiNotes: [
          "At an 8% average return, your money doubles approximately every 9 years (72 / 8 = 9).",
          "Warren Buffett made over 99% of his net worth after his 50th birthday purely due to compound duration."
        ],
        revisionCards: [
          { front: "What is the Rule of 72?", back: "A shortcut to estimate how many years it takes for an investment to double: 72 divided by the interest rate." },
          { front: "Why is time more powerful than contribution amount in compound growth?", back: "Because time operates in the mathematical exponent." }
        ]
      },
      {
        id: "fin-2",
        trackId: "track-fin",
        title: "Index Funds & Modern Portfolio Theory",
        category: "Finance",
        durationMinutes: 4,
        description: "Why broad-market passive index funds outperform 95% of Wall Street hedge fund managers.",
        xpReward: 65,
        coinsReward: 45,
        difficulty: "Intermediate",
        completed: false,
        summary: "Jack Bogle revolutionized global investing by creating the index fund. Low expense ratios, automatic rebalancing, and total market diversification beat active stock pickers over 15-year horizons.",
        keyPoints: [
          "Active management fees (1-2%) consume over 40% of potential 30-year retirement nest eggs.",
          "Total market index funds (like S&P 500 or VTI) capture the aggregate productivity of human innovation.",
          "Dollar-cost averaging (DCA) removes emotional market timing mistakes.",
          "Efficient Market Hypothesis (EMH): Current asset prices reflect all publicly available information."
        ],
        aiNotes: [
          "Warren Buffett's famous 10-year bet: An S&P 500 index fund crushed five prestigious hedge funds.",
          "Expense ratio of 0.03% vs 1.5% represents hundreds of thousands of dollars saved over a lifetime."
        ],
        revisionCards: [
          { front: "What is Dollar-Cost Averaging (DCA)?", back: "Investing a fixed dollar amount at regular intervals regardless of market ups or downs." },
          { front: "Who invented the first index fund for retail investors?", back: "John C. Bogle, founder of Vanguard." }
        ]
      },
      {
        id: "fin-3",
        trackId: "track-fin",
        title: "Unit Economics: LTV, CAC & Cash Conversion Cycle",
        category: "Finance",
        durationMinutes: 4,
        description: "How world-class tech startups analyze profitability before scaling.",
        xpReward: 70,
        coinsReward: 50,
        difficulty: "Advanced",
        completed: false,
        summary: "Every viable software business depends on healthy unit economics: customer lifetime value (LTV) must be at least 3x the customer acquisition cost (CAC), with a payback period under 12 months.",
        keyPoints: [
          "LTV = (Average Revenue Per User * Gross Margin) / Churn Rate.",
          "CAC = Total Sales & Marketing Spend / Number of New Customers Acquired.",
          "Healthy SaaS benchmark: LTV / CAC ratio of 3.0 or higher.",
          "Negative Working Capital: Getting paid by customers upfront before paying suppliers fuels viral bootstrapping."
        ],
        aiNotes: [
          "High churn kills LTV faster than increasing prices can salvage it.",
          "CAC payback period measures how many months it takes for a customer's gross profit to repay their acquisition cost."
        ],
        revisionCards: [
          { front: "What is considered a healthy LTV:CAC ratio for modern SaaS companies?", back: "3:1 or higher." },
          { front: "How is CAC Payback Period calculated?", back: "CAC divided by (Average Monthly Recurring Revenue per account * Gross Margin %)." }
        ]
      }
    ]
  }
];

export const QUIZ_QUESTIONS: Record<string, QuizQuestion[]> = {
  "ai-1": [
    {
      id: "q-ai1-1",
      lessonId: "ai-1",
      type: "multiple_choice",
      prompt: "What mathematical mechanism allows Transformers to evaluate relationships between all words concurrently?",
      options: [
        "Self-Attention Mechanism",
        "Convolutional Strided Pooling",
        "Sequential Recurrent Memory Cells",
        "Gradient Boosting Regressor"
      ],
      correctIndex: 0,
      difficulty: "easy",
      explanation: "Self-attention computes token-to-token similarity dot products across the entire sequence in parallel."
    },
    {
      id: "q-ai1-2",
      lessonId: "ai-1",
      type: "true_false",
      prompt: "True or False: Transformers process text strictly word-by-word in sequence like human speech.",
      isTrue: false,
      difficulty: "easy",
      explanation: "False! Transformers process all tokens in parallel using matrix multiplications on GPUs, which is why positional encodings are required."
    },
    {
      id: "q-ai1-3",
      lessonId: "ai-1",
      type: "match_pairs",
      prompt: "Match each Self-Attention vector with its role in the attention formula:",
      pairs: [
        { left: "Query (Q)", right: "What the current token is searching for" },
        { left: "Key (K)", right: "The label or identifier matched against" },
        { left: "Value (V)", right: "The actual semantic information retrieved" }
      ],
      difficulty: "medium",
      explanation: "Query matches against Keys to produce weights that scale the Values."
    },
    {
      id: "q-ai1-4",
      lessonId: "ai-1",
      type: "fill_blanks",
      prompt: "Complete the statement about Transformer scalability:",
      sentenceWithBlank: "Positional encodings inject token order without requiring ___ computation loops.",
      correctWord: "sequential",
      wordBank: ["sequential", "random", "heuristic", "quantum"],
      difficulty: "medium",
      explanation: "Positional encodings preserve order information without needing sequential recurrent loops."
    }
  ],
  "ai-2": [
    {
      id: "q-ai2-1",
      lessonId: "ai-2",
      type: "multiple_choice",
      prompt: "Which prompt engineering technique drastically reduces hallucinations in multi-step math and logic tasks?",
      options: [
        "Chain-of-Thought (CoT) Prompting",
        "Maximizing temperature to 2.0",
        "Repeating the query 10 times",
        "Removing system messages"
      ],
      correctIndex: 0,
      difficulty: "easy",
      explanation: "Chain-of-thought prompts the model to generate intermediate reasoning tokens, acting as a cognitive scratchpad."
    },
    {
      id: "q-ai2-2",
      lessonId: "ai-2",
      type: "true_false",
      prompt: "True or False: In Few-Shot prompting, the model weights are permanently updated with each example provided.",
      isTrue: false,
      difficulty: "medium",
      explanation: "False! Few-shot prompting is in-context learning. The model weights remain frozen; only the context window is conditioned."
    },
    {
      id: "q-ai2-3",
      lessonId: "ai-2",
      type: "fill_blanks",
      prompt: "Complete the definition of Zero-Shot prompting:",
      sentenceWithBlank: "In zero-shot prompting, the model receives instructions without any prior ___ demonstrations.",
      correctWord: "example",
      wordBank: ["example", "token", "vector", "binary"],
      difficulty: "easy",
      explanation: "Zero-shot poses the prompt directly with zero task examples."
    }
  ],
  "prod-1": [
    {
      id: "q-prod1-1",
      lessonId: "prod-1",
      type: "multiple_choice",
      prompt: "Which psychological reinforcement schedule makes apps like TikTok and Instagram as addictive as casino slot machines?",
      options: [
        "Variable Ratio Reinforcement Schedule",
        "Fixed Interval Schedule",
        "Linear Deterministic Feedback",
        "Negative Punishment Reinforcement"
      ],
      correctIndex: 0,
      difficulty: "easy",
      explanation: "Variable ratio reinforcement delivers unpredictable rewards at random intervals, maximizing compulsive craving."
    },
    {
      id: "q-prod1-2",
      lessonId: "prod-1",
      type: "true_false",
      prompt: "True or False: Dopamine is primarily released during satisfaction after achieving a goal, not during anticipation.",
      isTrue: false,
      difficulty: "medium",
      explanation: "False! Dopamine surges in anticipation and seeking. It is the molecule of motivation, not sustained contentment."
    },
    {
      id: "q-prod1-3",
      lessonId: "prod-1",
      type: "fill_blanks",
      prompt: "Complete the statement regarding cognitive barriers:",
      sentenceWithBlank: "Introducing a 3-minute cognitive barrier resets impulsive dopamine ___ by over 75%.",
      correctWord: "craving",
      wordBank: ["craving", "digestion", "memory", "respiration"],
      difficulty: "easy",
      explanation: "Friction interrupts the automated subconscious craving loop."
    }
  ]
};

export const INITIAL_DAILY_MISSIONS: DailyMission[] = [
  {
    id: "mission-1",
    title: "Complete 2 Micro-Lessons",
    target: 2,
    current: 1,
    rewardCoins: 50,
    rewardXp: 100,
    completed: false,
    claimed: false,
    icon: "BookOpen"
  },
  {
    id: "mission-2",
    title: "Score 85%+ on any AI Quiz",
    target: 1,
    current: 1,
    rewardCoins: 60,
    rewardXp: 120,
    completed: true,
    claimed: false,
    icon: "CheckCircle2"
  },
  {
    id: "mission-3",
    title: "Survive 60s in Knowledge Runner",
    target: 60,
    current: 45,
    rewardCoins: 40,
    rewardXp: 80,
    completed: false,
    claimed: false,
    icon: "Gamepad2"
  },
  {
    id: "mission-4",
    title: "Defeat 1 AI Boss in Combat",
    target: 1,
    current: 0,
    rewardCoins: 100,
    rewardXp: 200,
    completed: false,
    claimed: false,
    icon: "Sword"
  }
];

export const INITIAL_ACHIEVEMENTS: Achievement[] = [
  {
    id: "ach-first-lesson",
    title: "First Step to Freedom",
    description: "Complete your very first micro-lesson to bypass a screen distraction.",
    category: "learning",
    icon: "Sparkles",
    rewardCoins: 50,
    rewardXp: 100,
    unlocked: true,
    progress: 1,
    maxProgress: 1,
    unlockedAt: "2026-10-25"
  },
  {
    id: "ach-streak-7",
    title: "Week of Willpower",
    description: "Maintain an unbroken 7-day learning streak.",
    category: "streaks",
    icon: "Flame",
    rewardCoins: 150,
    rewardXp: 300,
    unlocked: true,
    progress: 7,
    maxProgress: 7,
    unlockedAt: "2026-10-27"
  },
  {
    id: "ach-quiz-master",
    title: "Adaptive Quiz Master",
    description: "Score 100% on 5 consecutive AI quizzes without failing.",
    category: "quizzes",
    icon: "Award",
    rewardCoins: 200,
    rewardXp: 400,
    unlocked: false,
    progress: 3,
    maxProgress: 5
  },
  {
    id: "ach-boss-slayer",
    title: "Dopamine Dragon Slayer",
    description: "Defeat the Glitch Lord in an AI Boss Battle.",
    category: "games",
    icon: "ShieldAlert",
    rewardCoins: 250,
    rewardXp: 500,
    unlocked: false,
    progress: 0,
    maxProgress: 1
  },
  {
    id: "ach-app-conqueror",
    title: "App Conqueror",
    description: "Unlock distracting apps 25 times purely through completed learning sessions.",
    category: "mastery",
    icon: "Unlock",
    rewardCoins: 300,
    rewardXp: 600,
    unlocked: false,
    progress: 18,
    maxProgress: 25
  },
  {
    id: "ach-hours-saved",
    title: "Time Alchemist",
    description: "Save over 20 cumulative hours of unproductive screen time.",
    category: "mastery",
    icon: "Clock",
    rewardCoins: 500,
    rewardXp: 1000,
    unlocked: false,
    progress: 14.5,
    maxProgress: 20
  }
];

export const INITIAL_SKILL_NODES: SkillNode[] = [
  {
    id: "node-ai-1",
    title: "Transformer Architecture",
    trackId: "track-ai",
    description: "Self-attention matrix computation and positional embeddings.",
    level: 1,
    tier: 1,
    dependencies: [],
    status: "completed",
    starsEarned: 3,
    icon: "Brain"
  },
  {
    id: "node-ai-2",
    title: "Prompt Engineering",
    trackId: "track-ai",
    description: "Few-shot in-context learning and chain-of-thought.",
    level: 2,
    tier: 2,
    dependencies: ["node-ai-1"],
    status: "completed",
    starsEarned: 3,
    icon: "Terminal"
  },
  {
    id: "node-ai-3",
    title: "Vector Search & RAG",
    trackId: "track-ai",
    description: "Embeddings, cosine distance, and vector retrieval pipelines.",
    level: 3,
    tier: 3,
    dependencies: ["node-ai-2"],
    status: "available",
    starsEarned: 0,
    icon: "Database"
  },
  {
    id: "node-ai-4",
    title: "Autonomous Agents",
    trackId: "track-ai",
    description: "ReAct loops, function calling schemas, and memory stores.",
    level: 4,
    tier: 4,
    dependencies: ["node-ai-3"],
    status: "locked",
    starsEarned: 0,
    icon: "Bot"
  },
  // Productivity branch
  {
    id: "node-prod-1",
    title: "Dopamine Rewiring",
    trackId: "track-prod",
    description: "Neurobiology of craving and variable reward schedules.",
    level: 1,
    tier: 1,
    dependencies: [],
    status: "completed",
    starsEarned: 3,
    icon: "Zap"
  },
  {
    id: "node-prod-2",
    title: "Ultradian Cycles",
    trackId: "track-prod",
    description: "90-minute focus rhythms and eliminating attention residue.",
    level: 2,
    tier: 2,
    dependencies: ["node-prod-1"],
    status: "completed",
    starsEarned: 2,
    icon: "Clock"
  },
  {
    id: "node-prod-3",
    title: "Environmental Friction",
    trackId: "track-prod",
    description: "20-second barriers and commitment devices.",
    level: 3,
    tier: 3,
    dependencies: ["node-prod-2"],
    status: "available",
    starsEarned: 0,
    icon: "Sliders"
  },
  // Finance branch
  {
    id: "node-fin-1",
    title: "Exponential Compounding",
    trackId: "track-fin",
    description: "Compound growth curves and the Rule of 72.",
    level: 1,
    tier: 1,
    dependencies: [],
    status: "available",
    starsEarned: 0,
    icon: "TrendingUp"
  },
  {
    id: "node-fin-2",
    title: "Index Diversification",
    trackId: "track-fin",
    description: "Passive investing and eliminating active manager drag.",
    level: 2,
    tier: 2,
    dependencies: ["node-fin-1"],
    status: "locked",
    starsEarned: 0,
    icon: "PieChart"
  }
];

export const INITIAL_LEADERBOARD: LeaderboardUser[] = [
  {
    id: "user-1",
    rank: 1,
    name: "Elena Rostova",
    avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80",
    petType: "owl",
    petStage: 4,
    xp: 4820,
    coins: 3120,
    streak: 34,
    lessonsCompleted: 86
  },
  {
    id: "user-2",
    rank: 2,
    name: "Kaito Tanaka",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80",
    petType: "fox",
    petStage: 3,
    xp: 4210,
    coins: 2840,
    streak: 28,
    lessonsCompleted: 74
  },
  {
    id: "user-3",
    rank: 3,
    name: "Marcus Sterling",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&auto=format&fit=crop&q=80",
    petType: "robot",
    petStage: 3,
    xp: 3890,
    coins: 2450,
    streak: 21,
    lessonsCompleted: 68
  },
  {
    id: "current-user",
    rank: 4,
    name: "You (Champion)",
    avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=120&auto=format&fit=crop&q=80",
    petType: "owl",
    petStage: 2,
    xp: 3150,
    coins: 480,
    streak: 7,
    lessonsCompleted: 24,
    isCurrentUser: true
  },
  {
    id: "user-5",
    rank: 5,
    name: "Aisha Al-Mansoor",
    avatar: "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=120&auto=format&fit=crop&q=80",
    petType: "fox",
    petStage: 2,
    xp: 2980,
    coins: 1950,
    streak: 15,
    lessonsCompleted: 52
  },
  {
    id: "user-6",
    rank: 6,
    name: "Liam O'Connor",
    avatar: "https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=120&auto=format&fit=crop&q=80",
    petType: "robot",
    petStage: 2,
    xp: 2740,
    coins: 1720,
    streak: 12,
    lessonsCompleted: 48
  }
];

export const PRODUCTIVITY_WEEK_STATS: ProductivityDayStats[] = [
  { day: "Mon", hoursSaved: 2.1, lessonsDone: 3, focusScore: 82, blocksCount: 14 },
  { day: "Tue", hoursSaved: 1.8, lessonsDone: 2, focusScore: 78, blocksCount: 11 },
  { day: "Wed", hoursSaved: 2.6, lessonsDone: 4, focusScore: 91, blocksCount: 18 },
  { day: "Thu", hoursSaved: 2.2, lessonsDone: 3, focusScore: 86, blocksCount: 15 },
  { day: "Fri", hoursSaved: 3.1, lessonsDone: 5, focusScore: 95, blocksCount: 22 },
  { day: "Sat", hoursSaved: 1.4, lessonsDone: 2, focusScore: 75, blocksCount: 9 },
  { day: "Sun", hoursSaved: 1.3, lessonsDone: 2, focusScore: 74, blocksCount: 8 },
];
