"use client";

import { useState, useEffect } from "react";
import { useAppState, appActions } from "@/lib/store";
import { sounds } from "@/lib/soundEffects";
import { 
  Gift, 
  Coins, 
  Clock, 
  LockOpen, 
  Lock, 
  Flame, 
  Sparkles, 
  ShieldCheck, 
  AlertTriangle,
  History,
  Check
} from "lucide-react";

export default function RewardsShopPage() {
  const state = useAppState();
  const [now, setNow] = useState(Date.now());

  useEffect(() => {
    const timer = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(timer);
  }, []);

  const UNLOCK_PASSES = [
    {
      id: "pass-30m",
      title: "30-Minute Screen Pass",
      description: "Unlocks 1 distracting app for 30 uninterrupted minutes of leisure.",
      cost: 50,
      durationMinutes: 30,
      badge: "Most Popular",
      color: "from-indigo-600 to-indigo-800",
    },
    {
      id: "pass-60m",
      title: "60-Minute Extended Pass",
      description: "Unlocks 1 distracting app for 1 hour. Ideal for movie or gaming sessions.",
      cost: 90,
      durationMinutes: 60,
      badge: "Save 10 Coins",
      color: "from-emerald-600 to-teal-800",
    },
    {
      id: "pass-freeze",
      title: "Streak Freeze Shield",
      description: "Protects your unbroken streak if you miss your micro-lesson tomorrow.",
      cost: 150,
      durationMinutes: 0,
      isShield: true,
      badge: "Protection",
      color: "from-amber-600 to-orange-800",
    },
  ];

  const handleBuyPass = (pass: typeof UNLOCK_PASSES[0], targetAppId: string) => {
    if (state.coins < pass.cost) {
      alert(`You need ${pass.cost} Brain Coins. You currently have ${state.coins} coins.`);
      sounds.playError();
      return;
    }

    if (pass.isShield) {
      appActions.addCoins(-pass.cost);
      sounds.playUnlock();
      alert("Streak Freeze Shield activated! Your streak is secured for the next 24 hours.");
      return;
    }

    const success = appActions.unlockApp(targetAppId, pass.durationMinutes, pass.cost);
    if (success) {
      alert(`🎉 Pass activated! ${targetAppId} is unlocked for ${pass.durationMinutes} minutes. Enjoy your earned screen time!`);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-amber-400 text-xs font-bold uppercase tracking-wider mb-1">
            <Gift className="h-4 w-4" />
            <span>Steps 6 & 7: Brain Coin Economy & App Access</span>
          </div>
          <h1 className="text-3xl font-black text-white tracking-tight">Rewards & Unlock Center</h1>
          <p className="text-sm text-slate-400 mt-1">
            Spend your hard-earned Brain Coins to unlock screen time passes or purchase focus shields.
          </p>
        </div>

        {/* Current Balance Display */}
        <div className="flex items-center gap-3 rounded-2xl border border-amber-500/40 bg-amber-500/10 p-3 px-5 text-amber-300">
          <Coins className="h-6 w-6 text-amber-400" />
          <div>
            <div className="text-[10px] font-bold uppercase tracking-wider text-amber-400/80">Available Balance</div>
            <div className="text-xl font-black text-white">{state.coins} Brain Coins</div>
          </div>
        </div>
      </div>

      {/* Currently Unlocked Apps Status */}
      <div className="glass-card rounded-3xl p-6 border border-white/10">
        <h2 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
          <LockOpen className="h-5 w-5 text-emerald-400" />
          <span>Active Screen Time Sessions</span>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {state.blockedApps.map((app) => {
            const isUnlocked = app.unlockedUntil && app.unlockedUntil > now;
            const remainingMs = Math.max(0, (app.unlockedUntil || 0) - now);
            const remainingMin = Math.floor(remainingMs / 60000);
            const remainingSec = Math.floor((remainingMs % 60000) / 1000);

            return (
              <div
                key={app.id}
                className={`rounded-2xl border p-4 transition-all ${
                  isUnlocked
                    ? "border-emerald-500/50 bg-emerald-950/20 shadow-lg shadow-emerald-950/50"
                    : "border-white/5 bg-white/5 opacity-60"
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="font-bold text-white text-sm">{app.name}</span>
                  {isUnlocked ? (
                    <span className="rounded-full bg-emerald-500/20 border border-emerald-500/40 px-2 py-0.5 text-[10px] font-bold text-emerald-300 flex items-center gap-1">
                      <LockOpen className="h-3 w-3" />
                      <span>UNLOCKED</span>
                    </span>
                  ) : (
                    <span className="text-[10px] font-bold text-slate-500 flex items-center gap-1">
                      <Lock className="h-3 w-3" />
                      <span>LOCKED</span>
                    </span>
                  )}
                </div>

                {isUnlocked ? (
                  <div className="space-y-1 mt-2">
                    <div className="flex justify-between text-xs font-mono">
                      <span className="text-slate-400">Time Remaining:</span>
                      <span className="font-bold text-emerald-400">
                        {remainingMin}m {remainingSec.toString().padStart(2, "0")}s
                      </span>
                    </div>
                    <div className="h-1.5 w-full rounded-full bg-slate-800 overflow-hidden">
                      <div className="h-full bg-emerald-400 animate-pulse w-full" />
                    </div>
                  </div>
                ) : (
                  <p className="text-xs text-slate-400 mt-2">
                    Blocked. Redeem a 30m or 60m pass below to open.
                  </p>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Redeemable Screen Passes Catalog */}
      <div>
        <h2 className="text-xl font-bold text-white mb-4">Redeem Screen Time Passes</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {UNLOCK_PASSES.map((pass) => (
            <div
              key={pass.id}
              className="glass-card rounded-3xl p-6 border border-white/10 flex flex-col justify-between hover:border-amber-500/40 transition-all hover:scale-[1.01]"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="rounded-full bg-amber-500/20 border border-amber-500/30 px-2.5 py-0.5 text-[10px] font-bold text-amber-300">
                    {pass.badge}
                  </span>
                  <div className="flex items-center gap-1 text-sm font-black text-amber-400">
                    <Coins className="h-4 w-4" />
                    <span>{pass.cost} Coins</span>
                  </div>
                </div>

                <h3 className="text-lg font-bold text-white mb-1.5">{pass.title}</h3>
                <p className="text-xs text-slate-300 leading-relaxed mb-6">
                  {pass.description}
                </p>
              </div>

              {/* Pass Target Selector & Buy Button */}
              <div className="space-y-3 pt-4 border-t border-white/10">
                {!pass.isShield ? (
                  <div>
                    <label className="text-[11px] font-semibold text-slate-400 block mb-1.5">
                      Select App To Unlock:
                    </label>
                    <select
                      id={`select-${pass.id}`}
                      defaultValue="instagram"
                      className="w-full rounded-xl border border-white/10 bg-slate-900 px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
                    >
                      {state.blockedApps.map((a) => (
                        <option key={a.id} value={a.id}>
                          {a.name}
                        </option>
                      ))}
                    </select>
                  </div>
                ) : null}

                <button
                  onClick={() => {
                    const selectEl = document.getElementById(`select-${pass.id}`) as HTMLSelectElement | null;
                    const targetApp = selectEl ? selectEl.value : "instagram";
                    handleBuyPass(pass, targetApp);
                  }}
                  disabled={state.coins < pass.cost}
                  className={`w-full rounded-xl py-3 text-xs font-bold flex items-center justify-center gap-2 transition-all ${
                    state.coins >= pass.cost
                      ? "bg-gradient-to-r from-amber-500 to-orange-500 text-black hover:opacity-95 shadow-lg shadow-amber-500/20"
                      : "bg-white/10 text-slate-500 cursor-not-allowed"
                  }`}
                >
                  <Coins className="h-4 w-4" />
                  <span>Redeem Pass ({pass.cost} Coins)</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
