"use client";

import { useState } from "react";
import { useAppState, appActions } from "@/lib/store";
import { sounds } from "@/lib/soundEffects";
import { 
  ShieldCheck, 
  Users, 
  Clock, 
  Cpu, 
  Sparkles, 
  PlusCircle, 
  CheckCircle2, 
  Database,
  Sliders,
  Send
} from "lucide-react";

export default function AdminDashboardPage() {
  const state = useAppState();

  const [promptTopic, setPromptTopic] = useState("");
  const [selectedDifficulty, setSelectedDifficulty] = useState("Intermediate");
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedOutput, setGeneratedOutput] = useState<any | null>(null);

  const handleGenerateContent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!promptTopic.trim()) return;

    setIsGenerating(true);
    sounds.playClick();

    setTimeout(() => {
      setIsGenerating(false);
      sounds.playCorrect();
      setGeneratedOutput({
        title: `${promptTopic}: Accelerated Mastery`,
        category: "Artificial Intelligence",
        durationMinutes: 3,
        summary: `Dynamic AI synthesis on ${promptTopic}. Key cognitive retrieval practice indicates rapid structural retention within 3 minutes of high-focus interaction.`,
        quiz: [
          `What core principle governs ${promptTopic}?`,
          `True/False: ${promptTopic} requires sequential blocking.`,
          `Match key parameters for optimal ${promptTopic} deployment.`
        ]
      });
    }, 1200);
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 text-indigo-400 text-xs font-bold uppercase tracking-wider mb-1">
          <ShieldCheck className="h-4 w-4" />
          <span>Platform Telemetry & Creator Studio</span>
        </div>
        <h1 className="text-3xl font-black text-white tracking-tight">Admin & Studio Operations</h1>
        <p className="text-sm text-slate-400 mt-1">
          Monitor global platform statistics, manage distraction policies, and use AI to generate new micro-lessons and quizzes.
        </p>
      </div>

      {/* Global Telemetry Strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="glass-card rounded-3xl p-5 border border-white/10">
          <div className="flex items-center gap-2 text-indigo-400 text-xs font-bold mb-1">
            <Users className="h-4 w-4" />
            <span>Active Scholars</span>
          </div>
          <div className="text-2xl font-black text-white">48,219</div>
          <p className="text-[11px] text-emerald-400 mt-1">+14% this month</p>
        </div>

        <div className="glass-card rounded-3xl p-5 border border-white/10">
          <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold mb-1">
            <Clock className="h-4 w-4" />
            <span>Total Hours Reclaimed</span>
          </div>
          <div className="text-2xl font-black text-white">124,850h</div>
          <p className="text-[11px] text-slate-400 mt-1">Across 12 countries</p>
        </div>

        <div className="glass-card rounded-3xl p-5 border border-white/10">
          <div className="flex items-center gap-2 text-rose-400 text-xs font-bold mb-1">
            <Cpu className="h-4 w-4" />
            <span>Blocks Executed Today</span>
          </div>
          <div className="text-2xl font-black text-white">312,940</div>
          <p className="text-[11px] text-rose-300 mt-1">99.98% interception uptime</p>
        </div>

        <div className="glass-card rounded-3xl p-5 border border-white/10">
          <div className="flex items-center gap-2 text-amber-400 text-xs font-bold mb-1">
            <Database className="h-4 w-4" />
            <span>Quiz Pass Threshold</span>
          </div>
          <div className="text-2xl font-black text-white">70% Req</div>
          <p className="text-[11px] text-amber-300 mt-1">88.5% avg pass rate</p>
        </div>
      </div>

      {/* AI Curriculum Generator Studio */}
      <div className="glass-card rounded-3xl p-6 md:p-8 border border-indigo-500/30 bg-gradient-to-br from-indigo-950/20 via-slate-900 to-[#0B0F1B] space-y-6">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-indigo-500/20 text-indigo-400">
            <Sparkles className="h-5 w-5" />
          </div>
          <div>
            <h2 className="text-lg font-black text-white">AI Micro-Curriculum Generator</h2>
            <p className="text-xs text-slate-400">
              Input any topic to generate a 3-minute lesson, AI notes, and a 4-part adaptive quiz automatically.
            </p>
          </div>
        </div>

        <form onSubmit={handleGenerateContent} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <input
              type="text"
              value={promptTopic}
              onChange={(e) => setPromptTopic(e.target.value)}
              placeholder="e.g. Quantum Computing, Kubernetes, React Server Actions..."
              className="md:col-span-2 rounded-2xl border border-white/10 bg-white/5 p-3.5 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-indigo-500"
            />
            <select
              value={selectedDifficulty}
              onChange={(e) => setSelectedDifficulty(e.target.value)}
              className="rounded-2xl border border-white/10 bg-slate-900 p-3.5 text-xs text-white focus:outline-none focus:border-indigo-500"
            >
              <option value="Beginner">Beginner</option>
              <option value="Intermediate">Intermediate</option>
              <option value="Advanced">Advanced</option>
            </select>
          </div>

          <button
            type="submit"
            disabled={isGenerating || !promptTopic.trim()}
            className="flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-indigo-600 to-emerald-500 px-6 py-3 text-xs font-bold text-white shadow-lg shadow-indigo-600/30 hover:opacity-95 transition-all disabled:opacity-50"
          >
            {isGenerating ? (
              <span className="flex items-center gap-2">
                <span className="h-3 w-3 rounded-full border-2 border-white border-t-transparent animate-spin" />
                Synthesizing Curriculum...
              </span>
            ) : (
              <>
                <Send className="h-3.5 w-3.5" />
                <span>Generate Curriculum & Quiz</span>
              </>
            )}
          </button>
        </form>

        {/* Generated Lesson Preview */}
        {generatedOutput && (
          <div className="rounded-2xl border border-emerald-500/30 bg-emerald-950/20 p-5 space-y-3 animate-in fade-in">
            <div className="flex items-center justify-between text-xs font-bold text-emerald-400">
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="h-4 w-4" />
                <span>Curriculum Synthesized Successfully!</span>
              </span>
              <span className="text-[11px] text-slate-400">{generatedOutput.durationMinutes} min read</span>
            </div>

            <h3 className="text-base font-bold text-white">{generatedOutput.title}</h3>
            <p className="text-xs text-slate-300 leading-relaxed">{generatedOutput.summary}</p>

            <div className="pt-2 border-t border-white/10">
              <div className="text-[11px] font-bold uppercase text-slate-400 mb-1">
                Generated Adaptive Quiz Questions:
              </div>
              <ul className="text-xs text-slate-300 space-y-1 list-disc list-inside">
                {generatedOutput.quiz.map((q: string, i: number) => (
                  <li key={i}>{q}</li>
                ))}
              </ul>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
